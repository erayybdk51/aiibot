import sqlite3
import pandas as pd
import json
import os
import logging
from datetime import datetime

class DatabaseManager:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.db_path = os.path.join(base_dir, 'data', 'trading.db')
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        self.setup_logging()
        self.create_tables()

    def setup_logging(self):
        log_dir = os.path.join(self.base_dir, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('database_manager')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(os.path.join(log_dir, 'database.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        
    def create_tables(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Market veri tablosu
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS market_data (
                        timestamp INTEGER,
                        symbol TEXT,
                        open REAL,
                        high REAL,
                        low REAL,
                        close REAL,
                        volume REAL,
                        close_time INTEGER,
                        quote_volume REAL,
                        trades INTEGER,
                        taker_base REAL,
                        taker_base_vol REAL,
                        timeframe TEXT,
                        PRIMARY KEY (timestamp, symbol, timeframe)
                    )
                """)
                
                # İşlemler tablosu
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS trades (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        symbol TEXT,
                        side TEXT,
                        quantity REAL,
                        entry_price REAL,
                        exit_price REAL,
                        entry_time TIMESTAMP,
                        exit_time TIMESTAMP,
                        stop_loss REAL,
                        take_profit REAL,
                        status TEXT,
                        profit_loss REAL,
                        risk_level REAL
                    )
                """)
                
                # Model performans tablosu
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS model_performance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        model_name TEXT,
                        accuracy REAL,
                        loss REAL,
                        training_time INTEGER,
                        timestamp TIMESTAMP,
                        params TEXT
                    )
                """)
                
                # Strateji performans tablosu
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS strategy_performance (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        strategy_name TEXT,
                        symbol TEXT,
                        timeframe TEXT,
                        win_rate REAL,
                        profit_factor REAL,
                        total_trades INTEGER,
                        timestamp TIMESTAMP
                    )
                """)
                
                self.logger.info("Database tables created successfully")
        except Exception as e:
            self.logger.error(f"Error creating tables: {str(e)}")

    def save_market_data(self, df, symbol, timeframe):
        try:
            df['symbol'] = symbol
            df['timeframe'] = timeframe
            
            with sqlite3.connect(self.db_path) as conn:
                df.to_sql('market_data', conn, if_exists='append', index=False)
                self.logger.info(f"Saved market data for {symbol} {timeframe}")
                
        except Exception as e:
            self.logger.error(f"Error saving market data: {str(e)}")

    def load_market_data(self, symbol, timeframe, limit=None):
        try:
            query = """
                SELECT * FROM market_data 
                WHERE symbol = ? AND timeframe = ?
                ORDER BY timestamp DESC
            """
            
            if limit:
                query += f" LIMIT {limit}"
                
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=[symbol, timeframe])
                return df.sort_values('timestamp')
                
        except Exception as e:
            self.logger.error(f"Error loading market data: {str(e)}")
            return pd.DataFrame()

    def save_trade(self, trade_data):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO trades (
                        symbol, side, quantity, entry_price, stop_loss, 
                        take_profit, entry_time, status, risk_level
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    trade_data['symbol'],
                    trade_data['side'],
                    trade_data['quantity'],
                    trade_data['entry_price'],
                    trade_data['stop_loss'],
                    trade_data['take_profit'],
                    trade_data['entry_time'],
                    'OPEN',
                    trade_data.get('risk_level', 0)
                ))
                return cursor.lastrowid
                
        except Exception as e:
            self.logger.error(f"Error saving trade: {str(e)}")
            return None

    def update_trade(self, trade_id, trade_data):
        try:
            with sqlite3.connect(self.db_path) as conn:
                updates = []
                params = []
                
                if 'exit_price' in trade_data:
                    updates.append("exit_price = ?")
                    params.append(trade_data['exit_price'])
                    
                if 'exit_time' in trade_data:
                    updates.append("exit_time = ?")
                    params.append(trade_data['exit_time'])
                    
                if 'status' in trade_data:
                    updates.append("status = ?")
                    params.append(trade_data['status'])
                    
                if 'profit_loss' in trade_data:
                    updates.append("profit_loss = ?")
                    params.append(trade_data['profit_loss'])
                    
                if updates:
                    params.append(trade_id)
                    query = f"UPDATE trades SET {', '.join(updates)} WHERE id = ?"
                    conn.execute(query, params)
                    self.logger.info(f"Updated trade {trade_id}")
                    
        except Exception as e:
            self.logger.error(f"Error updating trade: {str(e)}")

    def get_open_trades(self, symbol=None):
        try:
            query = "SELECT * FROM trades WHERE status = 'OPEN'"
            params = []
            
            if symbol:
                query += " AND symbol = ?"
                params.append(symbol)
                
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=params)
                return df.to_dict('records')
                
        except Exception as e:
            self.logger.error(f"Error getting open trades: {str(e)}")
            return []

    def get_trade_history(self, symbol=None, start_time=None, end_time=None):
        try:
            query = "SELECT * FROM trades WHERE status = 'CLOSED'"
            params = []
            
            if symbol:
                query += " AND symbol = ?"
                params.append(symbol)
                
            if start_time:
                query += " AND exit_time >= ?"
                params.append(start_time)
                
            if end_time:
                query += " AND exit_time <= ?"
                params.append(end_time)
                
            query += " ORDER BY exit_time DESC"
            
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=params)
                return df.to_dict('records')
                
        except Exception as e:
            self.logger.error(f"Error getting trade history: {str(e)}")
            return []

    def save_model_performance(self, model_data):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO model_performance (
                        model_name, accuracy, loss, training_time,
                        timestamp, params
                    ) VALUES (?, ?, ?, ?, ?, ?)
                """, (
                    model_data['model_name'],
                    model_data['accuracy'],
                    model_data['loss'],
                    model_data['training_time'],
                    datetime.now(),
                    json.dumps(model_data.get('params', {}))
                ))
                self.logger.info(f"Saved performance for model {model_data['model_name']}")
                return cursor.lastrowid
                
        except Exception as e:
            self.logger.error(f"Error saving model performance: {str(e)}")
            return None

    def save_strategy_performance(self, strategy_data):
        try:
            with sqlite3.connect(self.db_path) as conn:
                cursor = conn.cursor()
                cursor.execute("""
                    INSERT INTO strategy_performance (
                        strategy_name, symbol, timeframe, win_rate,
                        profit_factor, total_trades, timestamp
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """, (
                    strategy_data['strategy_name'],
                    strategy_data['symbol'],
                    strategy_data['timeframe'],
                    strategy_data['win_rate'],
                    strategy_data['profit_factor'],
                    strategy_data['total_trades'],
                    datetime.now()
                ))
                self.logger.info(f"Saved performance for strategy {strategy_data['strategy_name']}")
                return cursor.lastrowid
                
        except Exception as e:
            self.logger.error(f"Error saving strategy performance: {str(e)}")
            return None

    def get_model_performance_history(self, model_name):
        try:
            query = """
                SELECT * FROM model_performance 
                WHERE model_name = ? 
                ORDER BY timestamp DESC
            """
            
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=[model_name])
                return df.to_dict('records')
                
        except Exception as e:
            self.logger.error(f"Error getting model performance history: {str(e)}")
            return []

    def get_strategy_performance_history(self, strategy_name=None, symbol=None):
        try:
            query = "SELECT * FROM strategy_performance"
            params = []
            
            if strategy_name:
                query += " WHERE strategy_name = ?"
                params.append(strategy_name)
                
            if symbol:
                query += " AND symbol = ?" if strategy_name else " WHERE symbol = ?"
                params.append(symbol)
                
            query += " ORDER BY timestamp DESC"
            
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=params)
                return df.to_dict('records')
                
        except Exception as e:
            self.logger.error(f"Error getting strategy performance history: {str(e)}")
            return []

    def cleanup_old_data(self, days_to_keep=30):
        try:
            cutoff_date = datetime.now() - timedelta(days=days_to_keep)
            
            with sqlite3.connect(self.db_path) as conn:
                # Market verilerini temizle
                conn.execute("""
                    DELETE FROM market_data 
                    WHERE timestamp < ?
                """, (cutoff_date.timestamp() * 1000,))
                
                # Kapalı işlemleri temizle
                conn.execute("""
                    DELETE FROM trades 
                    WHERE status = 'CLOSED' AND exit_time < ?
                """, (cutoff_date,))
                
                # Eski performans metriklerini temizle
                conn.execute("""
                    DELETE FROM model_performance 
                    WHERE timestamp < ?
                """, (cutoff_date,))
                
                conn.execute("""
                    DELETE FROM strategy_performance 
                    WHERE timestamp < ?
                """, (cutoff_date,))
                
                self.logger.info(f"Cleaned up data older than {days_to_keep} days")
                
        except Exception as e:
            self.logger.error(f"Error cleaning up old data: {str(e)}")

    def backup_database(self, backup_dir=None):
        try:
            if backup_dir is None:
                backup_dir = os.path.join(self.base_dir, 'backups')
            
            os.makedirs(backup_dir, exist_ok=True)
            
            backup_path = os.path.join(
                backup_dir,
                f"trading_db_backup_{datetime.now().strftime('%Y%m%d_%H%M%S')}.db"
            )
            
            with sqlite3.connect(self.db_path) as src, sqlite3.connect(backup_path) as dst:
                src.backup(dst)
                
            self.logger.info(f"Database backed up to {backup_path}")
            return backup_path
            
        except Exception as e:
            self.logger.error(f"Error backing up database: {str(e)}")
            return None

    def optimize_database(self):
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("VACUUM")
                conn.execute("ANALYZE")
                self.logger.info("Database optimized")
                
        except Exception as e:
            self.logger.error(f"Error optimizing database: {str(e)}")
