import logging
import time
import threading
from datetime import datetime
import queue
import pandas as pd
from binance_interface import BinanceInterface
from data_manager import DataManager
from strategy_manager import StrategyManager
from risk_manager import RiskManager
from performance_analyzer import PerformanceAnalyzer
from terminal_handler import TerminalHandler
from database_manager import DatabaseManager

class IntegratedTradingSystem:
    def __init__(self, config):
        self.setup_logging()
        self.logger.info("Initializing Integrated Trading System...")
        
        self.config = config
        self.initialize_components()
        self.setup_queues()
        self.running = False
        self.threads = {}
        
    def setup_logging(self):
        self.logger = logging.getLogger('trading_system')
        self.logger.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        
        # File Handler
        fh = logging.FileHandler('logs/trading_system.log')
        fh.setFormatter(formatter)
        self.logger.addHandler(fh)
        
    def initialize_components(self):
        try:
            self.terminal = TerminalHandler()
            self.db_manager = DatabaseManager()
            self.exchange = BinanceInterface(self.config['api_key'], self.config['api_secret'])
            self.data_manager = DataManager(self.config['base_dir'])
            self.strategy_manager = StrategyManager()
            self.risk_manager = RiskManager(
                initial_capital=self.config['initial_capital'],
                risk_per_trade=self.config['risk_per_trade']
            )
            self.performance_analyzer = PerformanceAnalyzer()
            
            self.logger.info("All components initialized successfully")
            
        except Exception as e:
            self.logger.error(f"Error initializing components: {str(e)}")
            raise
            
    def setup_queues(self):
        self.market_data_queue = queue.Queue()
        self.signal_queue = queue.Queue()
        self.order_queue = queue.Queue()
        self.log_queue = queue.Queue()
        
    def start(self):
        try:
            if self.running:
                self.logger.warning("System is already running")
                return
                
            self.running = True
            self.logger.info("Starting trading system...")
            
            # Start all threads
            self.threads['market_data'] = threading.Thread(target=self._market_data_loop)
            self.threads['signal_processing'] = threading.Thread(target=self._signal_processing_loop)
            self.threads['order_execution'] = threading.Thread(target=self._order_execution_loop)
            self.threads['performance_monitoring'] = threading.Thread(target=self._performance_monitoring_loop)
            
            for name, thread in self.threads.items():
                thread.daemon = True
                thread.start()
                self.logger.info(f"Started {name} thread")
                
            self.terminal.log_info("Trading system started successfully")
            
        except Exception as e:
            self.logger.error(f"Error starting trading system: {str(e)}")
            self.running = False
            raise
            
    def stop(self):
        try:
            self.logger.info("Stopping trading system...")
            self.running = False
            
            # Wait for all threads to complete
            for name, thread in self.threads.items():
                thread.join(timeout=10)
                self.logger.info(f"Stopped {name} thread")
                
            self.terminal.log_info("Trading system stopped successfully")
            
        except Exception as e:
            self.logger.error(f"Error stopping trading system: {str(e)}")
            raise
            
    def _market_data_loop(self):
        while self.running:
            try:
                for symbol in self.config['symbols']:
                    # Fetch market data
                    market_data = self.exchange.get_market_data(symbol, self.config['timeframe'])
                    
                    if market_data is not None:
                        # Save to database
                        self.db_manager.save_market_data(market_data)
                        
                        # Update data manager
                        self.data_manager.save_market_data(market_data, symbol, self.config['timeframe'])
                        
                        # Put in queue for signal processing
                        self.market_data_queue.put({
                            'symbol': symbol,
                            'data': market_data,
                            'timestamp': datetime.now()
                        })
                        
                time.sleep(self.config['market_data_interval'])
                
            except Exception as e:
                self.logger.error(f"Error in market data loop: {str(e)}")
                self.terminal.log_error(f"Market data error: {str(e)}")
                time.sleep(5)  # Error cooldown
                
    def _signal_processing_loop(self):
        while self.running:
            try:
                if not self.market_data_queue.empty():
                    market_data = self.market_data_queue.get()
                    
                    # Calculate indicators
                    df_indicators = self.strategy_manager.calculate_indicators(market_data['data'])
                    
                    if not df_indicators.empty:
                        # Generate trading signals
                        signals = self.strategy_manager.generate_signals(df_indicators)
                        
                        if signals:
                            # Validate signals with risk management
                            validated_signals = self.risk_manager.validate_signals(signals, market_data)
                            
                            if validated_signals:
                                self.signal_queue.put({
                                    'symbol': market_data['symbol'],
                                    'signals': validated_signals,
                                    'timestamp': datetime.now()
                                })
                                
                time.sleep(0.1)  # Prevent CPU overload
                
            except Exception as e:
                self.logger.error(f"Error in signal processing loop: {str(e)}")
                self.terminal.log_error(f"Signal processing error: {str(e)}")
                time.sleep(5)
                
    def _order_execution_loop(self):
        while self.running:
            try:
                if not self.signal_queue.empty():
                    signal_data = self.signal_queue.get()
                    
                    # Check if we should enter a trade
                    if self._check_entry_opportunities(signal_data):
                        # Execute the trade
                        order = self._execute_trade(signal_data)
                        
                        if order:
                            # Save order to database
                            self.db_manager.save_order(order)
                            
                            # Update performance metrics
                            self.performance_analyzer.update_metrics(order)
                            
                            # Log the trade
                            self.terminal.log_trade(order)
                            
                time.sleep(0.1)
                
            except Exception as e:
                self.logger.error(f"Error in order execution loop: {str(e)}")
                self.terminal.log_error(f"Order execution error: {str(e)}")
                time.sleep(5)
                
    def _performance_monitoring_loop(self):
        while self.running:
            try:
                # Get latest performance metrics
                performance = self.performance_analyzer.get_performance_summary()
                
                # Update terminal display
                self.terminal.update_terminal(
                    market_data=self._get_latest_market_data(),
                    signals=self._get_latest_signals(),
                    performance=performance
                )
                
                # Save performance data
                self.db_manager.save_performance_data(performance)
                
                # Check for risk limits
                self.risk_manager.check_risk_limits(performance)
                
                time.sleep(self.config['performance_update_interval'])
                
            except Exception as e:
                self.logger.error(f"Error in performance monitoring loop: {str(e)}")
                self.terminal.log_error(f"Performance monitoring error: {str(e)}")
                time.sleep(5)
                
    def _check_entry_opportunities(self, signal_data):
        try:
            signals = signal_data['signals']
            symbol = signal_data['symbol']
            
            # Get current positions
            positions = self.exchange.get_positions()
            
            # Check if we already have a position for this symbol
            current_position = next((pos for pos in positions if pos['symbol'] == symbol), None)
            
            if current_position:
                return False  # Already in a position
                
            # Check signal strength
            if signals['signal'] in ['BUY', 'SELL'] and signals['strength'] >= self.config['min_signal_strength']:
                # Validate with risk manager
                if self.risk_manager.validate_trade(symbol, signals):
                    return True
                    
            return False
            
        except Exception as e:
            self.logger.error(f"Error checking entry opportunities: {str(e)}")
            return False
            
    def _execute_trade(self, signal_data):
        try:
            symbol = signal_data['symbol']
            signals = signal_data['signals']
            
            # Calculate position size
            price = self.exchange.get_current_price(symbol)
            stop_loss, take_profit = self.strategy_manager.get_stop_loss_take_profit(
                price,
                signals.get('ATR', price * 0.01),
                signals['signal'] == 'BUY'
            )
            
            position_size = self.risk_manager.get_position_size(price, stop_loss)
            
            if position_size > 0:
                # Place the order
                order = self.exchange.place_order(
                    symbol=symbol,
                    side=signals['signal'],
                    quantity=position_size,
                    price=price,
                    stop_loss=stop_loss,
                    take_profit=take_profit
                )
                
                if order:
                    return {
                        'symbol': symbol,
                        'action': signals['signal'],
                        'quantity': position_size,
                        'price': price,
                        'stop_loss': stop_loss,
                        'take_profit': take_profit,
                        'timestamp': datetime.now()
                    }
                    
            return None
            
        except Exception as e:
            self.logger.error(f"Error executing trade: {str(e)}")
            return None
            
    def _get_latest_market_data(self):
        try:
            market_data = {}
            for symbol in self.config['symbols']:
                data = self.exchange.get_current_price(symbol)
                if data:
                    market_data[symbol] = {
                        'price': data,
                        'change': self.exchange.get_24h_change(symbol),
                        'volume': self.exchange.get_24h_volume(symbol)
                    }
            return market_data
            
        except Exception as e:
            self.logger.error(f"Error getting latest market data: {str(e)}")
            return {}
            
    def _get_latest_signals(self):
        try:
            signals = {}
            while not self.signal_queue.empty():
                signal_data = self.signal_queue.get()
                signals[signal_data['symbol']] = signal_data['signals']
            return signals
            
        except Exception as e:
            self.logger.error(f"Error getting latest signals: {str(e)}")
            return {}