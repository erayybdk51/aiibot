import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input
from tensorflow.keras.optimizers import Adam
import numpy as np
import os
import logging

class ModelInitializer:
    def __init__(self, models_dir):
        """
        Model başlatıcı sınıfı
        
        Parametreler:
            models_dir (str): Model dosyalarının kaydedileceği dizin
        """
        self.models_dir = models_dir
        os.makedirs(models_dir, exist_ok=True)
        
    def initialize_models(self):
        """Tüm modelleri başlat ve yapılandır"""
        models = {
            'price_predictor': self._create_price_predictor(),
            'risk_analyzer': self._create_risk_analyzer(),
            'trend_classifier': self._create_trend_classifier()
        }
        
        self._save_models(models)
        return models
        
    def _create_price_predictor(self):
        """
        Fiyat tahmin modeli oluştur
        
        LSTM tabanlı derin öğrenme modeli
        Giriş: 60 zaman adımı x 5 özellik
        Çıkış: Bir sonraki kapanış fiyatı tahmini
        """
        model = Sequential()
        
        # Giriş katmanı
        model.add(Input(shape=(60, 5)))
        
        # LSTM katmanları
        model.add(LSTM(128, return_sequences=True))
        model.add(Dropout(0.2))
        model.add(LSTM(64))
        model.add(Dropout(0.2))
        
        # Yoğun katmanlar
        model.add(Dense(32, activation='relu'))
        model.add(Dense(1))
        
        # Model derle
        model.compile(
            optimizer=Adam(learning_rate=0.001),
            loss='mse',
            metrics=['mae']  # Ortalama mutlak hata
        )
        
        logging.info("Fiyat tahmin modeli oluşturuldu")
        return model
        
    def _create_risk_analyzer(self):
        """
        Risk analiz modeli oluştur
        
        Dense tabanlı sınıflandırma modeli
        Giriş: 10 özellik
        Çıkış: Risk skoru (0-1 arası)
        """
        model = Sequential([
            Input(shape=(10,)),
            Dense(64, activation='relu'),
            Dropout(0.2),
            Dense(32, activation='relu'),
            Dense(16, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(
            optimizer='adam',
            loss='binary_crossentropy',
            metrics=['accuracy']
        )
        
        logging.info("Risk analiz modeli oluşturuldu")
        return model
        
    def _create_trend_classifier(self):
        """
        Trend sınıflandırma modeli oluştur
        
        Dense tabanlı çok sınıflı sınıflandırma modeli
        Giriş: 15 özellik
        Çıkış: Trend sınıfı olasılıkları (Yükseliş, Düşüş, Yatay)
        """
        model = Sequential([
            Input(shape=(15,)),
            Dense(32, activation='relu'),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(3, activation='softmax')
        ])
        
        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )
        
        logging.info("Trend sınıflandırma modeli oluşturuldu")
        return model
        
    def _save_models(self, models):
        """
        Modelleri kaydet
        
        Parametreler:
            models (dict): Kaydedilecek modeller sözlüğü
        """
        try:
            for name, model in models.items():
                model_path = os.path.join(self.models_dir, f"{name}.h5")
                model.save(model_path)
                logging.info(f"{name} modeli kaydedildi: {model_path}")
                
        except Exception as e:
            logging.error(f"Model kaydetme hatası: {str(e)}")
            
    def train_initial_models(self, training_data):
        """
        Modelleri başlangıç verisiyle eğit
        
        Parametreler:
            training_data (dict): Eğitim verileri ve etiketleri
        """
        try:
            if not training_data or 'X' not in training_data or 'y' not in training_data:
                raise ValueError("Geçerli eğitim verisi bulunamadı")
                
            X_train, y_train = training_data['X'], training_data['y']
            
            if len(X_train) == 0 or len(y_train) == 0:
                raise ValueError("Boş eğitim verisi")
                
            models = self.initialize_models()
            
            # Fiyat tahmin modelini eğit
            logging.info("Fiyat tahmin modeli eğitiliyor...")
            history = models['price_predictor'].fit(
                X_train, y_train,
                epochs=10,
                batch_size=32,
                validation_split=0.2,
                verbose=1
            )
            
            # Eğitim metriklerini kaydet
            logging.info(f"Eğitim kaybı: {history.history['loss'][-1]:.4f}")
            if 'val_loss' in history.history:
                logging.info(f"Doğrulama kaybı: {history.history['val_loss'][-1]:.4f}")
            
            # Modelleri kaydet
            self._save_models(models)
            logging.info("Başlangıç eğitimi tamamlandı")
            
            return models
            
        except Exception as e:
            logging.error(f"Model eğitim hatası: {str(e)}")
            return None