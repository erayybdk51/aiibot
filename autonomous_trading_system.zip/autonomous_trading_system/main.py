from data_generator import DataGenerator
from model_initializer import ModelInitializer
from model_manager import ModelManager
from strategy_manager import StrategyManager
from risk_manager import RiskManager
from performance_analyzer import PerformanceAnalyzer
from database_manager import DatabaseManager
from binance_interface import BinanceInterface
from terminal_handler import TerminalHandler
import logging
import threading
import time
import os
import sys
from datetime import datetime

class AutonomousTrader:
    def __init__(self):
        # Trading parametreleri
        self.trading_pairs = ['BTCUSDT', 'ETHUSDT']  # Trading yapılacak çiftler
        self.timeframes = ['1m', '5m', '15m']  # Analiz edilecek zaman dilimleri
        self.running = True

        # API anahtarları
        self.API_KEY = 'Hmdo1ZpfIazZ8m48Kj3tpk29RRUeNLtW0EaO6XYJF1jukPljiz3enAU44ovgNhJl'
        self.API_SECRET = 'pNrqNvwyHbTtADcjmCdYe0pGLjjjZjndqy7CxnAuUIvhgY5iqV5ntF6UZfpjDkNQ'
        
        # Temel dizin yapılandırması
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.setup_directories()
        self.setup_logging()

        # Terminal handler'ı başlat 
        self.terminal = TerminalHandler()
        self.terminal.add_status_message("Sistem başlatılıyor...")
        
        # Alt sistemleri başlat
        self.initialize_system()
        self.initialize_subsystems()

    def setup_logging(self):
        """Logging sistemini yapılandır"""
        log_file = os.path.join(self.base_dir, 'logs', 'trading.log')
        
        # Logs dizininin varlığını kontrol et ve oluştur
        log_dir = os.path.dirname(log_file)
        if not os.path.exists(log_dir):
            os.makedirs(log_dir)

        # Basic config ayarla
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        # Logger'ı sınıf değişkeni olarak sakla
        self.logger = logging.getLogger('trading_system')
        
        # Console handler ekle
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
        console_handler.setFormatter(formatter)
        self.logger.addHandler(console_handler)

    def setup_directories(self):
        """Dizin yapısını oluştur"""
        directories = [
            'data/market_data',
            'data/processed',
            'data/training_history',
            'data/performance',
            'models/checkpoints',
            'models/states',
            'logs',
            'analysis',
            'reports',
            'backtest'
        ]
        for directory in directories:
            path = os.path.join(self.base_dir, directory)
            os.makedirs(path, exist_ok=True)

    def initialize_system(self):
        """Başlangıç verisi ve modellerini yükle"""
        self.terminal.add_status_message("Başlangıç verisi indiriliyor...")
        
        # Veri jeneratörü
        self.data_generator = DataGenerator(self.API_KEY, self.API_SECRET)
        
        # Her sembol için veri indir
        all_data = {}
        for symbol in self.trading_pairs:
            symbol_data = self.data_generator.download_multi_timeframe_data(symbol, self.timeframes)
            all_data[symbol] = symbol_data
        
        # Veritabanına kaydet
        self.db_manager = DatabaseManager(self.base_dir)
        for symbol, timeframe_data in all_data.items():
            for timeframe, df in timeframe_data.items():
                if df is not None:
                    self.db_manager.save_market_data(df, symbol, timeframe)
                    
        self.terminal.add_status_message("Başlangıç verileri kaydedildi")
        
        # Model başlatıcı
        self.terminal.add_status_message("Modeller başlatılıyor...")
        model_initializer = ModelInitializer(os.path.join(self.base_dir, 'models'))
        
        # Eğitim verisi hazırla
        training_data = self.data_generator.generate_training_data(
            all_data['BTCUSDT']['1m']  # Ana sembol ve timeframe
        )
        
        # Modelleri başlat ve eğit
        self.models = model_initializer.train_initial_models({
            'X': training_data[0],
            'y': training_data[1]
        })
        
        self.terminal.add_status_message("Modeller eğitildi")

    def initialize_subsystems(self):
        """Alt sistemleri başlat"""
        self.binance = BinanceInterface(self.API_KEY, self.API_SECRET)
        self.model_manager = ModelManager(self.base_dir)
        self.strategy_manager = StrategyManager()
        self.risk_manager = RiskManager(initial_balance=1000)
        self.performance_analyzer = PerformanceAnalyzer(self.base_dir)

    def start(self):
        """Trading sistemini başlat"""
        try:
            self.logger.info('Autonomous Trading System başlatılıyor...')
            self.terminal.add_status_message('Sistem başlatıldı ve çalışıyor...')
            
            # Alt threadleri başlat
            threads = [
                threading.Thread(target=self._market_data_loop),
                threading.Thread(target=self._analysis_loop),
                threading.Thread(target=self._model_update_loop),
                threading.Thread(target=self._performance_monitoring_loop),
                threading.Thread(target=self._terminal_update_loop)  # Terminal güncellemeleri için
            ]
            
            for thread in threads:
                thread.daemon = True
                thread.start()
            
            # Ana döngü
            while self.running:
                self._main_trading_loop()
                time.sleep(1)
                
        except Exception as e:
            self.logger.error(f'Sistem hatası: {e}')
            self.shutdown()

    def _market_data_loop(self):
        """Piyasa verilerini topla"""
        while self.running:
            try:
                for pair in self.trading_pairs:
                    for timeframe in self.timeframes:
                        # Verileri çek
                        data = self.binance.get_historical_klines(
                            pair, timeframe, limit=100
                        )
                        
                        if data is not None:
                            # Veritabanına kaydet
                            self.db_manager.save_market_data(data, pair, timeframe)
                            self.terminal.add_status_message(f"{pair} {timeframe} verisi güncellendi")
                            
                time.sleep(60)  # Her dakika güncelle
                
            except Exception as e:
                self.logger.error(f'Veri toplama hatası: {e}')
                self.terminal.add_status_message(f"Veri toplama hatası: {e}")
                time.sleep(5)

    def _analysis_loop(self):
        """Sürekli piyasa analizi"""
        while self.running:
            try:
                for pair in self.trading_pairs:
                    # Her zaman dilimi için analiz yap
                    analysis_results = {}
                    for timeframe in self.timeframes:
                        # Verileri al
                        data = self.db_manager.load_market_data(pair, timeframe)
                        
                        if data is not None:
                            # İndikatörleri hesapla
                            data_with_indicators = self.strategy_manager.calculate_indicators(data)
                            
                            # Sinyalleri üret
                            signals = self.strategy_manager.generate_signals(data_with_indicators)
                            
                            analysis_results[timeframe] = {
                                'data': data_with_indicators,
                                'signals': signals
                            }
                            
                    # Trading sinyali üret
                    if analysis_results:
                        self._process_analysis_results(pair, analysis_results)
                        
                time.sleep(15)  # 15 saniyede bir analiz
                
            except Exception as e:
                self.logger.error(f'Analiz hatası: {e}')
                self.terminal.add_status_message(f"Analiz hatası: {e}")
                time.sleep(5)

    def _model_update_loop(self):
        """Model güncelleme döngüsü"""
        while self.running:
            try:
                # Her sembol için modeli güncelle
                for pair in self.trading_pairs:
                    # Son verileri al
                    data = self.db_manager.load_market_data(
                        pair, '1m', limit=10000  # Son 10000 veri
                    )
                    
                    if data is not None:
                        # Verileri hazırla
                        training_data = self.data_generator.generate_training_data(data)
                        
                        # Modeli güncelle
                        self.model_manager.update_models(training_data)
                        self.terminal.add_status_message(f"{pair} modeli güncellendi")
                        
                time.sleep(3600)  # Saatte bir güncelle
                
            except Exception as e:
                self.logger.error(f'Model güncelleme hatası: {e}')
                time.sleep(60)

    def _performance_monitoring_loop(self):
        """Performans izleme döngüsü"""
        while self.running:
            try:
                # Performans raporu oluştur
                report = self.performance_analyzer.generate_report()
                
                if report:
                    self.terminal.add_status_message(
                        f"Performans Güncellendi - "
                        f"İşlem: {report['summary']['total_trades']}, "
                        f"Kazanç: {report['summary']['win_rate']:.2f}%, "
                        f"P/L: ${report['summary']['net_profit']:.2f}"
                    )
                    
                time.sleep(300)  # 5 dakikada bir güncelle
                
            except Exception as e:
                self.logger.error(f'Performans izleme hatası: {e}')
                time.sleep(30)

    def _terminal_update_loop(self):
        """Terminal görüntüsünü güncelle"""
        while self.running:
            try:
                # Terminal verilerini hazırla
                terminal_data = {
                    'signals': self._get_current_signals(),
                    'positions': self._get_open_positions(),
                    'daily_performance': self._get_daily_performance(),
                    'monthly_performance': self._get_monthly_performance()
                }
                
                # Terminal görüntüsünü güncelle
                self.terminal.update_display(terminal_data)
                time.sleep(1)
                
            except Exception as e:
                self.logger.error(f'Terminal güncelleme hatası: {e}')
                time.sleep(5)

    def _main_trading_loop(self):
        """Ana trading döngüsü"""
        try:
            # Her sembol için işlem kontrolü
            for pair in self.trading_pairs:
                # Mevcut fiyatı al
                current_price = self.binance.get_current_price(pair)
                
                if current_price:
                    # Açık işlemleri kontrol et
                    trades = self.db_manager.get_open_trades(pair)
                    for trade in trades:
                        # Stop loss ve take profit kontrolü
                        self._check_trade_exit(trade, current_price)
                        
                    # Yeni işlem fırsatı kontrolü
                    if self.risk_manager.can_open_new_position(pair):
                        self._check_entry_opportunities(pair, current_price)
                        
                time.sleep(1)  # Her sembol arası 1 saniye bekle
                
        except Exception as e:
            self.logger.error(f'Trading döngüsü hatası: {e}')
            self.terminal.add_status_message(f"Trading hatası: {e}")

    def _check_trade_exit(self, trade, current_price):
        """İşlem çıkış koşullarını kontrol et"""
        if trade['stop_loss'] >= current_price or current_price >= trade['take_profit']:
            self._close_trade(trade, current_price, 'sl_tp_hit')

    def _check_entry_opportunities(self, pair, current_price):
        """Giriş fırsatlarını kontrol et"""
        try:
            # Son verileri al
            data = self.db_manager.load_market_data(pair, '1m', limit=100)
            if data is not None:
                # İndikatörleri hesapla
                indicators = self.strategy_manager.calculate_indicators(data)
                # Sinyal üret
                signal = self.strategy_manager.generate_signals(indicators)
                
                # Sinyal değerlendir
                if signal['signal'] in ['BUY', 'SELL']:
                    risk_params = self.risk_manager.calculate_risk_parameters(
                        pair, signal['strength']
                    )
                    
                    if risk_params['can_trade']:
                        self._execute_trade(pair, signal['signal'], risk_params)
                        
        except Exception as e:
            self.logger.error(f'Giriş fırsatı kontrolü hatası: {e}')

    def _execute_trade(self, pair, side, risk_params):
        """İşlemi gerçekleştir"""
        try:
            # İşlem büyüklüğünü hesapla
            quantity = self.risk_manager.calculate_position_size(
                self.binance.get_current_price(pair)
            )
            
            # Stop loss ve take profit hesapla
            atr = self.strategy_manager.calculate_indicators(
                self.db_manager.load_market_data(pair, '1m', limit=100)
            )['ATR'].iloc[-1]
            
            stop_loss, take_profit = self.strategy_manager.get_stop_loss_take_profit(
                self.binance.get_current_price(pair), atr, side == 'BUY'
            )
            # İşlemi gerçekleştir
            order = self.binance.create_order(
                symbol=pair,
                side=side,
                quantity=quantity
            )
            
            if order:
                # İşlemi kaydet
                trade_data = {
                    'symbol': pair,
                    'side': side,
                    'quantity': quantity,
                    'entry_price': float(order['price']),
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'entry_time': datetime.now(),
                    'risk_level': risk_params['risk_level'],
                    'profit_loss': 0
                }
                
                self.db_manager.save_trade(trade_data)
                self.terminal.add_status_message(
                    f"Yeni İşlem: {pair} {side} "
                    f"(Giriş: ${float(order['price']):.2f}, "
                    f"SL: ${stop_loss:.2f}, "
                    f"TP: ${take_profit:.2f})"
                )
                
        except Exception as e:
            self.logger.error(f'İşlem gerçekleştirme hatası: {e}')
            self.terminal.add_status_message(f"İşlem hatası: {e}")

    def _close_trade(self, trade, current_price, reason):
        """İşlemi kapat"""
        try:
            # İşlemi kapat
            exit_price = current_price
            profit_loss = (exit_price - trade['entry_price']) * trade['quantity']
            
            # İşlem verilerini güncelle
            trade_data = {
                'exit_price': exit_price,
                'exit_time': datetime.now(),
                'reason': reason,
                'profit_loss': profit_loss
            }
            
            self.db_manager.update_trade(trade, trade_data)
            
            # Cari bakiyeyi güncelle
            self.risk_manager.update_balance(profit_loss)
            
            self.terminal.add_status_message(
                f"İşlem Sonuç: {trade['symbol']} "
                f"P/L: ${profit_loss:.2f} "
                f"({reason})"
            )
            
        except Exception as e:
            self.logger.error(f'İşlem kapama hatası: {e}')
            
    def _get_current_signals(self):
        """Mevcut trading sinyallerini al"""
        signals = []
        for pair in self.trading_pairs:
            for timeframe in self.timeframes:
                data = self.db_manager.load_market_data(pair, timeframe, limit=100)
                if data is not None:
                    indicators = self.strategy_manager.calculate_indicators(data)
                    signal = self.strategy_manager.generate_signals(indicators)
                    
                    signals.append({
                        'pair': pair,
                        'timeframe': timeframe,
                        'signal': signal.get('signal', ''),
                        'strength': signal.get('strength', 0),
                        'action': signal.get('action', ''),
                        'indicators': {
                            'atr': indicators.get('ATR', 0),
                            'rsi': indicators.get('RSI', 0),
                            'macd': indicators.get('MACD', 0)
                        }
                    })
        return signals

    def _process_signals(self, signals):
        """İşlem sinyallerini işle"""
        for signal in signals:
            signal.update({
                'indicators': {
                    'atr': indicators.get('ATR', 0),
                    'rsi': indicators.get('RSI', 0),
                    'macd': indicators.get('MACD', 0)
                }
            })
        return signals

    def _get_open_positions(self):
        """Açık pozisyonları al"""
        positions = []
        open_trades = self.db_manager.get_open_trades()
        
        for trade in open_trades:
            current_price = self.binance.get_current_price(trade['symbol'])
            if current_price:
                pl_usd = (current_price - trade['entry_price']) * trade['quantity']
                pl_pct = (pl_usd / (trade['entry_price'] * trade['quantity'])) * 100
                
                positions.append({
                    'id': trade['id'],
                    'pair': trade['symbol'],
                    'type': trade['side'],
                    'entry': f"${trade['entry_price']:.2f}",
                    'current': f"${current_price:.2f}",
                    'pl_usd': f"${pl_usd:.2f}",
                    'pl_pct': f"{pl_pct:.2f}%",
                    'sl': f"${trade['stop_loss']:.2f}",
                    'tp': f"${trade['take_profit']:.2f}",
                    'duration': self._format_duration(datetime.now() - trade['entry_time'])
                })
        return positions

    def _format_duration(self, duration):
        """Süreyi formatla"""
        total_minutes = int(duration.total_seconds() / 60)
        hours = total_minutes // 60
        minutes = total_minutes % 60
        return f"{hours}h{minutes}m"

    def _get_daily_performance(self):
        """Günlük performans verilerini al"""
        return self.performance_analyzer.get_daily_performance()

    def _get_monthly_performance(self):
        """Aylık performans verilerini al"""
        return self.performance_analyzer.get_monthly_performance()

    def _process_analysis_results(self, pair, analysis_results):
        """Analiz sonuçlarını değerlendir ve işlem sinyali üret"""
        try:
            composite_signal = self.strategy_manager.calculate_composite_signal(
                analysis_results['1m']['signals']
            )
            
            if abs(composite_signal) > 0.8:
                side = 'BUY' if composite_signal > 0 else 'SELL'
                risk_params = self.risk_manager.calculate_risk_parameters(
                    pair, abs(composite_signal)
                )
                
                if risk_params['can_trade']:
                    self._execute_trade(pair, side, risk_params)
                    
        except Exception as e:
            self.logger.error(f'Analiz sonucu işleme hatası: {e}')

    def shutdown(self):
        """Sistemi güvenli bir şekilde kapat"""
        self.terminal.add_status_message("Sistem kapatılıyor...")
        self.running = False
        
        for pair in self.trading_pairs:
            trades = self.db_manager.get_open_trades(pair)
            for trade in trades:
                current_price = self.binance.get_current_price(pair)
                if current_price:
                    self._close_trade(trade, current_price, 'system_shutdown')
        
        time.sleep(2)
        print('Sistem güvenli bir şekilde kapatıldı.')
        self.logger.info('Sistem güvenli bir şekilde kapatıldı.')

if __name__ == "__main__":
    trader = AutonomousTrader()
    try:
        trader.start()
    except KeyboardInterrupt:
        trader.shutdown()