import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import os
import json

class PerformanceAnalyzer:
    def __init__(self, base_dir=None):
        self.base_dir = base_dir
        self.setup_logging()
        self.performance_metrics = {}
        self.daily_stats = pd.DataFrame()
        self.monthly_stats = pd.DataFrame()
        
    def setup_logging(self):
        log_dir = os.path.join(self.base_dir, 'logs') if self.base_dir else 'logs'
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('performance_analyzer')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(os.path.join(log_dir, 'performance.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        
    def get_daily_performance(self, symbol=None):
        """Günlük performans metriklerini getir"""
        try:
            if self.daily_stats.empty:
                return {}
            if symbol:
                return self.daily_stats[self.daily_stats['symbol'] == symbol].to_dict('records')
            return self.daily_stats.to_dict('records')
        except Exception as e:
            self.logger.error(f"Daily performance error: {str(e)}")
            return {}
            
    def generate_report(self):
        """Kapsamlı performans raporu oluştur"""
        try:
            current_time = datetime.now()
            report = {
                'timestamp': current_time,
                'overall_metrics': self.performance_metrics,
                'daily_stats': self.get_daily_performance(),
                'monthly_stats': self.monthly_stats.to_dict('records') if not self.monthly_stats.empty else [],
                'current_drawdown': self.calculate_current_drawdown(),
                'risk_metrics': self.calculate_risk_metrics(),
                'trends': self.analyze_performance_trends()
            }
            
            # Raporu dosyaya kaydet
            if self.base_dir:
                report_dir = os.path.join(self.base_dir, 'reports')
                os.makedirs(report_dir, exist_ok=True)
                report_file = os.path.join(report_dir, f'performance_report_{current_time.strftime("%Y%m%d_%H%M%S")}.json')
                
                with open(report_file, 'w') as f:
                    json.dump(report, f, default=str, indent=4)
                    
            return report
        except Exception as e:
            self.logger.error(f"Report generation error: {str(e)}")
            return {}
            
    def calculate_performance_metrics(self, trades):
        """Temel performans metriklerini hesapla"""
        try:
            if not trades:
                return {}
                
            trades_df = pd.DataFrame(trades)
            trades_df['entry_time'] = pd.to_datetime(trades_df['entry_time'])
            trades_df['exit_time'] = pd.to_datetime(trades_df['exit_time'])
            trades_df['duration'] = trades_df['exit_time'] - trades_df['entry_time']
            
            # Temel metrikler
            total_trades = len(trades)
            winning_trades = len(trades_df[trades_df['profit_loss'] > 0])
            losing_trades = len(trades_df[trades_df['profit_loss'] < 0])
            
            win_rate = winning_trades / total_trades if total_trades > 0 else 0
            
            # Kar/zarar metrikleri
            total_profit = trades_df['profit_loss'].sum()
            avg_profit = trades_df[trades_df['profit_loss'] > 0]['profit_loss'].mean()
            avg_loss = trades_df[trades_df['profit_loss'] < 0]['profit_loss'].mean()
            
            profit_factor = abs(trades_df[trades_df['profit_loss'] > 0]['profit_loss'].sum() / 
                             trades_df[trades_df['profit_loss'] < 0]['profit_loss'].sum()) if losing_trades > 0 else float('inf')
                              
            # Risk metrikleri
            max_drawdown = self.calculate_max_drawdown(trades_df)
            sharpe_ratio = self.calculate_sharpe_ratio(trades_df)
            
            # Zaman metrikleri
            avg_duration = trades_df['duration'].mean()
            
            metrics = {
                'total_trades': total_trades,
                'winning_trades': winning_trades,
                'losing_trades': losing_trades,
                'win_rate': win_rate,
                'total_profit': total_profit,
                'average_profit': avg_profit,
                'average_loss': avg_loss,
                'profit_factor': profit_factor,
                'max_drawdown': max_drawdown,
                'sharpe_ratio': sharpe_ratio,
                'average_duration': avg_duration,
                'last_updated': datetime.now()
            }
            
            self.performance_metrics = metrics
            return metrics
            
        except Exception as e:
            self.logger.error(f"Performance metrics calculation error: {str(e)}")
            return {}
            
    def calculate_max_drawdown(self, trades_df):
        """Maksimum drawdown hesapla"""
        try:
            if trades_df.empty:
                return 0
                
            cumulative = trades_df['profit_loss'].cumsum()
            rolling_max = cumulative.expanding().max()
            drawdowns = cumulative - rolling_max
            max_drawdown = drawdowns.min()
            
            return abs(max_drawdown) if not pd.isna(max_drawdown) else 0
            
        except Exception as e:
            self.logger.error(f"Max drawdown calculation error: {str(e)}")
            return 0
            
    def calculate_sharpe_ratio(self, trades_df, risk_free_rate=0.02, periods_per_year=252):
        """Sharpe oranı hesapla"""
        try:
            if trades_df.empty:
                return 0
                
            daily_returns = trades_df.groupby(trades_df['exit_time'].dt.date)['profit_loss'].sum()
            if len(daily_returns) < 2:
                return 0
                
            returns_std = daily_returns.std()
            if returns_std == 0:
                return 0
                
            excess_returns = daily_returns.mean() - (risk_free_rate / periods_per_year)
            sharpe = np.sqrt(periods_per_year) * excess_returns / returns_std
            
            return float(sharpe)
            
        except Exception as e:
            self.logger.error(f"Sharpe ratio calculation error: {str(e)}")
            return 0
            
    def calculate_daily_stats(self, trades):
        """Günlük istatistikler hesapla"""
        try:
            if not trades:
                return pd.DataFrame()
                
            trades_df = pd.DataFrame(trades)
            trades_df['exit_time'] = pd.to_datetime(trades_df['exit_time'])
            
            daily_stats = trades_df.groupby(trades_df['exit_time'].dt.date).agg({
                'profit_loss': ['count', 'sum', 'mean', 'std'],
                'symbol': 'first',
                'quantity': 'sum'
            }).round(8)
            
            daily_stats.columns = ['trade_count', 'total_profit', 'avg_profit', 'profit_std', 'symbol', 'volume']
            
            # Win rate hesapla
            wins_per_day = trades_df[trades_df['profit_loss'] > 0].groupby(
                trades_df['exit_time'].dt.date
            ).size()
            
            daily_stats['win_rate'] = (wins_per_day / daily_stats['trade_count']).round(4)
            
            self.daily_stats = daily_stats
            return daily_stats
            
        except Exception as e:
            self.logger.error(f"Daily stats calculation error: {str(e)}")
            return pd.DataFrame()
            
    def calculate_monthly_stats(self, trades):
        """Aylık istatistikler hesapla"""
        try:
            if not trades:
                return pd.DataFrame()
                
            trades_df = pd.DataFrame(trades)
            trades_df['exit_time'] = pd.to_datetime(trades_df['exit_time'])
            
            monthly_stats = trades_df.groupby(trades_df['exit_time'].dt.to_period('M')).agg({
                'profit_loss': ['count', 'sum', 'mean', 'std'],
                'symbol': 'first',
                'quantity': 'sum'
            }).round(8)
            
            monthly_stats.columns = ['trade_count', 'total_profit', 'avg_profit', 'profit_std', 'symbol', 'volume']
            
            # Win rate hesapla
            wins_per_month = trades_df[trades_df['profit_loss'] > 0].groupby(
                trades_df['exit_time'].dt.to_period('M')
            ).size()
            
            monthly_stats['win_rate'] = (wins_per_month / monthly_stats['trade_count']).round(4)
            
            self.monthly_stats = monthly_stats
            return monthly_stats
            
        except Exception as e:
            self.logger.error(f"Monthly stats calculation error: {str(e)}")
            return pd.DataFrame()
            
    def calculate_risk_metrics(self):
        """Risk metriklerini hesapla"""
        try:
            metrics = {
                'current_drawdown': self.performance_metrics.get('current_drawdown', 0),
                'max_drawdown': self.performance_metrics.get('max_drawdown', 0),
                'sharpe_ratio': self.performance_metrics.get('sharpe_ratio', 0),
                'volatility': self.calculate_returns_volatility(),
                'var_95': self.calculate_value_at_risk(0.95),
                'var_99': self.calculate_value_at_risk(0.99)
            }
            return metrics
        except Exception as e:
            self.logger.error(f"Risk metrics calculation error: {str(e)}")
            return {}
            
    def calculate_current_drawdown(self):
        """Mevcut drawdown hesapla"""
        try:
            if self.daily_stats.empty:
                return 0
                
            equity_curve = self.daily_stats['total_profit'].cumsum()
            peak = equity_curve.expanding().max()
            drawdown = (equity_curve - peak) / peak
            current_drawdown = drawdown.iloc[-1]
            
            return abs(float(current_drawdown)) if not pd.isna(current_drawdown) else 0
            
        except Exception as e:
            self.logger.error(f"Current drawdown calculation error: {str(e)}")
            return 0
            
    def calculate_returns_volatility(self, window=30):
        """Return volatilitesi hesapla"""
        try:
            if self.daily_stats.empty:
                return 0
                
            returns = self.daily_stats['total_profit'].pct_change()
            volatility = returns.std() * np.sqrt(252)  # Yıllık volatilite
            
            return float(volatility) if not pd.isna(volatility) else 0
            
        except Exception as e:
            self.logger.error(f"Returns volatility calculation error: {str(e)}")
            return 0
            
    def calculate_value_at_risk(self, confidence_level):
        """Value at Risk hesapla"""
        try:
            if self.daily_stats.empty:
                return 0
                
            returns = self.daily_stats['total_profit'].values
            var = np.percentile(returns, (1 - confidence_level) * 100)
            
            return abs(float(var)) if not pd.isna(var) else 0
            
        except Exception as e:
            self.logger.error(f"VaR calculation error: {str(e)}")
            return 0
            
    def analyze_performance_trends(self, window=30):
        """Performans trendlerini analiz et"""
        try:
            if self.daily_stats.empty:
                return {}
                
            trends = {
                'profit_trend': self._calculate_trend(self.daily_stats['total_profit'], window),
                'win_rate_trend': self._calculate_trend(self.daily_stats['win_rate'], window),
                'volume_trend': self._calculate_trend(self.daily_stats['volume'], window)
            }
            
            return trends
            
        except Exception as e:
            self.logger.error(f"Performance trends analysis error: {str(e)}")
            return {}
            
    def _calculate_trend(self, series, window):
        """Trend hesaplama yardımcı fonksiyonu"""
        try:
            if len(series) < window:
                return 0
                
            rolling_mean = series.rolling(window=window).mean()
            current = rolling_mean.iloc[-1]
            previous = rolling_mean.iloc[-window]
            
            if previous == 0:
                return 0
                
            trend = ((current - previous) / previous) * 100
            return float(trend) if not pd.isna(trend) else 0
            
        except Exception as e:
            self.logger.error(f"Trend calculation error: {str(e)}")
            return 0