import os
import sys
from datetime import datetime
import time
from collections import deque
import threading
import logging

class TerminalHandler:
    def __init__(self):
        self.status_messages = deque(maxlen=4)
        self.start_time = datetime.now()
        self.system_status = "Aktif"
        self.api_status = "Bağlı"
        self.server_load = 20
        self.data_delay = 110
        self.setup_logging()

    def setup_logging(self):
        log_dir = 'logs'
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('terminal_handler')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(os.path.join(log_dir, 'terminal.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)

    def clear_screen(self):
        """Terminal ekranını temizle"""
        os.system('cls' if os.name == 'nt' else 'clear')

    def add_status_message(self, message):
        """Durum mesajı ekle"""
        try:
            timestamp = datetime.now().strftime("%H:%M:%S")
            self.status_messages.append(f"[{timestamp}] {message}")
            self.logger.info(message)
        except Exception as e:
            self.logger.error(f"Status message error: {str(e)}")

    def format_duration(self, duration):
        """Süre formatla"""
        try:
            hours = duration.seconds // 3600
            minutes = (duration.seconds % 3600) // 60
            seconds = duration.seconds % 60
            return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        except Exception as e:
            self.logger.error(f"Duration formatting error: {str(e)}")
            return "00:00:00"

    def render_header(self):
        """Başlık bölümünü oluştur"""
        try:
            runtime = self.format_duration(datetime.now() - self.start_time)
            header = []
            header.append("===================== GELİŞMİŞ TRADER TERMİNALİ =====================")
            header.append(f"Durum: {self.system_status} | Çalışma Süresi: {runtime}")
            header.append(f"API Durumu: {self.api_status} | Sunucu Yükü: %{self.server_load} | Gecikme: {self.data_delay}ms")
            header.append("================================================================")
            return "\n".join(header)
        except Exception as e:
            self.logger.error(f"Header rendering error: {str(e)}")
            return "ERROR: Header could not be rendered"

    def render_status_section(self):
        """Durum bölümünü oluştur"""
        try:
            status = []
            status.append("------------------- MEVCUT DURUM -------------------")
            for msg in self.status_messages:
                status.append(msg)
            status.append("--------------------------------------------------")
            return "\n".join(status)
        except Exception as e:
            self.logger.error(f"Status section rendering error: {str(e)}")
            return "ERROR: Status section could not be rendered"

    def render_signals(self, signals):
        """Sinyal bölümünü oluştur"""
        try:
            signal_text = []
            signal_text.append("-------------------- SİNYALLER --------------------")
            signal_text.append("Pair    | Süre | Sinyal | Güç | İşlem | ATR | RSI | MACD")
            signal_text.append("-------------------------------------------------")
            
            for signal in signals:
                signal_text.append(
                    f"{signal['pair']:<8}|"
                    f"{signal['timeframe']:<6}|"
                    f"{signal['signal']:<8}|"
                    f"{signal['strength']:<5.2f}|"
                    f"{signal['action']:<7}|"
                    f"{signal['indicators']['atr']:<5.2f}|"
                    f"{signal['indicators']['rsi']:<5.1f}|"
                    f"{signal['indicators']['macd']:<6.2f}"
                )
            
            signal_text.append("-------------------------------------------------")
            return "\n".join(signal_text)
        except Exception as e:
            self.logger.error(f"Signals rendering error: {str(e)}")
            return "ERROR: Signals section could not be rendered"

    def render_open_positions(self, positions):
        """Açık pozisyonlar bölümünü oluştur"""
        try:
            pos_text = []
            pos_text.append("----------------------- AÇIK İŞLEMLER -----------------------")
            pos_text.append("ID  | Pair | Tip | Giriş | Mevcut | P/L($) | P/L(%) | S/L | T/P | Süre")
            pos_text.append("------------------------------------------------------------")
            
            for pos in positions:
                pos_text.append(
                    f"{pos['id']:<4}|"
                    f"{pos['pair']:<6}|"
                    f"{pos['type']:<5}|"
                    f"{pos['entry']:<7}|"
                    f"{pos['current']:<8}|"
                    f"{pos['pl_usd']:<8}|"
                    f"{pos['pl_pct']:<8}|"
                    f"{pos['sl']:<5}|"
                    f"{pos['tp']:<5}|"
                    f"{pos['duration']}"
                )
            
            pos_text.append("------------------------------------------------------------")
            return "\n".join(pos_text)
        except Exception as e:
            self.logger.error(f"Positions rendering error: {str(e)}")
            return "ERROR: Open positions section could not be rendered"

    def render_performance(self, daily_perf, monthly_perf):
        """Performans bölümünü oluştur"""
        try:
            perf_text = []
            perf_text.append("----------------------- PERFORMANS -----------------------")
            perf_text.append("Günlük:")
            perf_text.extend(self._format_daily_performance(daily_perf))
            perf_text.append("\nAylık:")
            perf_text.extend(self._format_monthly_performance(monthly_perf))
            perf_text.append("--------------------------------------------------------")
            return "\n".join(perf_text)
        except Exception as e:
            self.logger.error(f"Performance rendering error: {str(e)}")
            return "ERROR: Performance section could not be rendered"

    def _format_daily_performance(self, perf):
        """Günlük performans formatla"""
        try:
            daily = []
            for pair in perf.get('pairs', []):
                daily.append(
                    f"{pair['pair']}: "
                    f"KZ: {pair['pl']:.2f}$ "
                    f"(%{pair['pl_pct']:.1f})"
                )
            return daily
        except Exception as e:
            self.logger.error(f"Daily performance formatting error: {str(e)}")
            return ["ERROR: Daily performance format error"]

    def _format_monthly_performance(self, perf):
        """Aylık performans formatla"""
        try:
            monthly = []
            for pair in perf.get('pairs', []):
                monthly.append(
                    f"{pair['pair']}: "
                    f"Toplam: {pair['total_pl']:.2f}$ | "
                    f"Ort: {pair['avg_daily']:.2f}$ | "
                    f"İşlem: {pair['trades']} | "
                    f"Başarı: %{pair['win_rate']:.1f}"
                )
            return monthly
        except Exception as e:
            self.logger.error(f"Monthly performance formatting error: {str(e)}")
            return ["ERROR: Monthly performance format error"]

    def render_controls(self):
        """Kontrol bölümünü oluştur"""
        try:
            controls = []
            controls.append("------------------------ KONTROLLER ------------------------")
            controls.append("[1] Durdur   [2] İşlemler   [3] Rapor    [4] Model Güncelle")
            controls.append("[5] Kapat    [6] Test       [7] Risk     [8] Ayarlar")
            controls.append("--------------------------------------------------------")
            return "\n".join(controls)
        except Exception as e:
            self.logger.error(f"Controls rendering error: {str(e)}")
            return "ERROR: Controls section could not be rendered"

    def update_display(self, data):
        """Terminal görüntüsünü güncelle"""
        try:
            self.clear_screen()
            
            display = [
                self.render_header(),
                self.render_status_section(),
                self.render_signals(data.get('signals', [])),
                self.render_open_positions(data.get('positions', [])),
                self.render_performance(
                    data.get('daily_performance', {}),
                    data.get('monthly_performance', {})
                ),
                self.render_controls()
            ]

            print("\n".join(display))
            sys.stdout.flush()
        except Exception as e:
            self.logger.error(f"Display update error: {str(e)}")

    def log_trade(self, trade_info):
        """İşlem logla"""
        try:
            msg = (
                f"İşlem: {trade_info['symbol']} "
                f"{trade_info['side']} "
                f"Fiyat: {trade_info['price']:.8f} "
                f"Miktar: {trade_info['quantity']:.8f}"
            )
            self.add_status_message(msg)
        except Exception as e:
            self.logger.error(f"Trade logging error: {str(e)}")

    def log_error(self, error_msg):
        """Hata logla"""
        try:
            self.add_status_message(f"HATA: {error_msg}")
        except Exception as e:
            self.logger.error(f"Error logging error: {str(e)}")

    def log_info(self, info_msg):
        """Bilgi logla"""
        try:
            self.add_status_message(info_msg)
        except Exception as e:
            self.logger.error(f"Info logging error: {str(e)}")

    def log_warning(self, warning_msg):
        """Uyarı logla"""
        try:
            self.add_status_message(f"UYARI: {warning_msg}")
        except Exception as e:
            self.logger.error(f"Warning logging error: {str(e)}")

    def log_success(self, success_msg):
        """Başarı mesajı logla"""
        try:
            self.add_status_message(f"BAŞARILI: {success_msg}")
        except Exception as e:
            self.logger.error(f"Success logging error: {str(e)}")

    def update_system_status(self, status):
        """Sistem durumunu güncelle"""
        try:
            self.system_status = status
            self.logger.info(f"System status updated to: {status}")
        except Exception as e:
            self.logger.error(f"System status update error: {str(e)}")

    def update_api_status(self, status):
        """API durumunu güncelle"""
        try:
            self.api_status = status
            self.logger.info(f"API status updated to: {status}")
        except Exception as e:
            self.logger.error(f"API status update error: {str(e)}")

    def update_server_metrics(self, load, delay):
        """Sunucu metriklerini güncelle"""
        try:
            self.server_load = load
            self.data_delay = delay
            self.logger.info(f"Server metrics updated - Load: {load}%, Delay: {delay}ms")
        except Exception as e:
            self.logger.error(f"Server metrics update error: {str(e)}")
