import pandas as pd
import numpy as np
import talib
from datetime import datetime, timedelta
import logging

class MarketAnalyzer:
    def __init__(self):
        self.setup_logging()
        self.current_market_state = {
            'trend': None,
            'support_levels': [],
            'resistance_levels': [],
            'volatility': None
        }
        
    def setup_logging(self):
        self.logger = logging.getLogger('market_analyzer')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler('logs/market.log')
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)

    def analyze_market(self, df):
        """Piyasa analizi yap"""
        try:
            if df.empty:
                return {}
                
            analysis = {
                'market_state': self._analyze_market_state(df),
                'market_health': self._analyze_market_health(df),
                'entry_points': self._find_entry_points(df),
                'risk_metrics': self._calculate_risk_metrics(df)
            }
            
            # Mevcut piyasa durumunu güncelle
            self.current_market_state.update(analysis['market_state'])
            
            return analysis
            
        except Exception as e:
            self.logger.error(f"Market analysis error: {str(e)}")
            return {}
            
    def _analyze_market_state(self, df):
        """Piyasa durumunu analiz et"""
        try:
            # Trend analizi
            sma20 = df['close'].rolling(window=20).mean()
            sma50 = df['close'].rolling(window=50).mean()
            
            current_price = df['close'].iloc[-1]
            
            if current_price > sma20.iloc[-1] > sma50.iloc[-1]:
                trend = 'UP'
            elif current_price < sma20.iloc[-1] < sma50.iloc[-1]:
                trend = 'DOWN'
            else:
                trend = 'SIDEWAYS'
                
            # Momentum
            rsi = talib.RSI(df['close'])
            macd, signal, hist = talib.MACD(df['close'])
            
            # Volatilite
            atr = talib.ATR(df['high'], df['low'], df['close'])
            
            # Hacim profili
            volume_sma = df['volume'].rolling(window=20).mean()
            if df['volume'].iloc[-1] > volume_sma.iloc[-1]:
                volume_profile = 'INCREASING'
            else:
                volume_profile = 'DECREASING'
                
            return {
                'trend': trend,
                'momentum': {
                    'rsi': rsi.iloc[-1],
                    'macd': macd.iloc[-1],
                    'macd_signal': signal.iloc[-1]
                },
                'volatility': atr.iloc[-1],
                'volume_profile': volume_profile
            }
            
        except Exception as e:
            self.logger.error(f"Market state analysis error: {str(e)}")
            return {}
            
    def _analyze_market_health(self, df):
        """Piyasa sağlığını analiz et"""
        try:
            rsi = talib.RSI(df['close'])
            current_rsi = rsi.iloc[-1]
            
            if current_rsi > 70:
                overbought_oversold = 'OVERBOUGHT'
            elif current_rsi < 30:
                overbought_oversold = 'OVERSOLD'
            else:
                overbought_oversold = 'NEUTRAL'
                
            # Volatilite durumu
            atr = talib.ATR(df['high'], df['low'], df['close'])
            atr_sma = atr.rolling(window=20).mean()
            
            if atr.iloc[-1] > atr_sma.iloc[-1] * 1.5:
                volatility_state = 'HIGH'
            elif atr.iloc[-1] < atr_sma.iloc[-1] * 0.5:
                volatility_state = 'LOW'
            else:
                volatility_state = 'NORMAL'
                
            return {
                'overbought_oversold': overbought_oversold,
                'volatility_state': volatility_state
            }
            
        except Exception as e:
            self.logger.error(f"Market health analysis error: {str(e)}")
            return {}
            
    def _find_entry_points(self, df):
        """Giriş noktalarını bul"""
        try:
            # Support ve resistance seviyeleri
            pivot_points = self._calculate_pivot_points(df)
            
            # Fibonacci seviyeleri
            fib_levels = self._calculate_fibonacci_levels(df)
            
            # Bollinger Bands
            upper, middle, lower = talib.BBANDS(df['close'])
            
            return {
                'support_levels': [
                    pivot_points['s1'],
                    pivot_points['s2'],
                    lower.iloc[-1]
                ],
                'resistance_levels': [
                    pivot_points['r1'],
                    pivot_points['r2'],
                    upper.iloc[-1]
                ]
            }
            
        except Exception as e:
            self.logger.error(f"Entry points analysis error: {str(e)}")
            return {}
            
    def _calculate_risk_metrics(self, df):
        """Risk metriklerini hesapla"""
        try:
            # Volatilite
            returns = df['close'].pct_change()
            volatility = returns.std() * np.sqrt(252)  # Yıllık volatilite
            
            # Drawdown
            rolling_max = df['close'].rolling(window=252, min_periods=1).max()
            drawdown = df['close'] / rolling_max - 1
            max_drawdown = drawdown.min()
            
            # VaR (Value at Risk)
            var_95 = returns.quantile(0.05)
            
            return {
                'volatility': volatility,
                'max_drawdown': max_drawdown,
                'value_at_risk_95': var_95
            }
            
        except Exception as e:
            self.logger.error(f"Risk metrics calculation error: {str(e)}")
            return {}
            
    def check_trading_conditions(self, analysis_results):
        """İşlem koşullarını kontrol et"""
        if not analysis_results:
            return False, "Analiz sonuçları boş"
            
        # Volatilite kontrolü
        if analysis_results['market_state']['volatility'] > self.volatility_threshold:
            return False, "Yüksek volatilite"
            
        # Hacim kontrolü
        if analysis_results['market_state']['volume_profile'] == 'DECREASING':
            return False, "Düşük hacim"
            
        # Piyasa sağlığı kontrolü
        health = analysis_results['market_health']
        if health['overbought_oversold'] == 'OVERBOUGHT' and analysis_results['market_state']['trend'] == 'UP':
            return False, "Aşırı alım bölgesi"
        if health['overbought_oversold'] == 'OVERSOLD' and analysis_results['market_state']['trend'] == 'DOWN':
            return False, "Aşırı satım bölgesi"
            
        return True, "İşlem koşulları uygun"
        
    def calculate_entry_points(self, current_price, analysis_results):
        """Giriş noktalarını hesapla"""
        support_levels = self.current_market_state['support_levels']
        resistance_levels = self.current_market_state['resistance_levels']
        
        entry_points = {
            'long': [],
            'short': []
        }
        
        # Long giriş noktaları
        if analysis_results['market_state']['trend'] == 'UP':
            for support in support_levels:
                if support < current_price * 1.02:  # %2 tolerans
                    entry_points['long'].append(support)
                    
        # Short giriş noktaları
        elif analysis_results['market_state']['trend'] == 'DOWN':
            for resistance in resistance_levels:
                if resistance > current_price * 0.98:  # %2 tolerans
                    entry_points['short'].append(resistance)
                    
        return entry_points
        
    def identify_key_levels(self, df):
        """Önemli fiyat seviyelerini belirle"""
        pivot = self._calculate_pivot_points(df)
        fib_levels = self._calculate_fibonacci_levels(df)
        
        return {
            'pivot_points': pivot,
            'fibonacci_levels': fib_levels
        }
        
    def _calculate_pivot_points(self, df):
        """Pivot noktalarını hesapla"""
        last_day = df.iloc[-1]
        
        pivot = (last_day['high'] + last_day['low'] + last_day['close']) / 3
        r1 = 2 * pivot - last_day['low']
        r2 = pivot + (last_day['high'] - last_day['low'])
        s1 = 2 * pivot - last_day['high']
        s2 = pivot - (last_day['high'] - last_day['low'])
        
        return {
            'pivot': pivot,
            'r1': r1,
            'r2': r2,
            's1': s1,
            's2': s2
        }
        
    def _calculate_fibonacci_levels(self, df, period=20):
        """Fibonacci seviyelerini hesapla"""
        high = df['high'].rolling(window=period).max().iloc[-1]
        low = df['low'].rolling(window=period).min().iloc[-1]
        diff = high - low
        
        levels = {
            '0.236': low + diff * 0.236,
            '0.382': low + diff * 0.382,
            '0.5': low + diff * 0.5,
            '0.618': low + diff * 0.618,
            '0.786': low + diff * 0.786
        }
        
        return levels
        
    def detect_pattern(self, df):
        """Teknik analiz paternlerini tespit et"""
        patterns = {}
        
        # Mum formasyonları
        patterns['doji'] = talib.CDLDOJI(df['open'], df['high'], df['low'], df['close'])
        patterns['engulfing'] = talib.CDLENGULFING(df['open'], df['high'], df['low'], df['close'])
        patterns['hammer'] = talib.CDLHAMMER(df['open'], df['high'], df['low'], df['close'])
        patterns['shooting_star'] = talib.CDLSHOOTINGSTAR(df['open'], df['high'], df['low'], df['close'])
        
        # Pattern sonuçlarını analiz et
        active_patterns = {}
        for pattern_name, pattern_values in patterns.items():
            last_value = pattern_values.iloc[-1]
            if last_value != 0:
                active_patterns[pattern_name] = 'BULLISH' if last_value > 0 else 'BEARISH'
                
        return active_patterns

    def analyze_volume_profile(self, df, price_levels=10):
        """Hacim profili analizi"""
        price_range = df['high'].max() - df['low'].min()
        price_step = price_range / price_levels
        
        volume_profile = {}
        for i in range(price_levels):
            price_low = df['low'].min() + i * price_step
            price_high = price_low + price_step
            
            mask = (df['close'] >= price_low) & (df['close'] < price_high)
            volume = df.loc[mask, 'volume'].sum()
            
            volume_profile[f"Level_{i}"] = {
                'price_range': (price_low, price_high),
                'volume': volume
            }
            
        return volume_profile