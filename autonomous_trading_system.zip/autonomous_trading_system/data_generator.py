from binance.client import Client
import pandas as pd
import numpy as np
import talib
from datetime import datetime, timedelta
import logging
from sklearn.preprocessing import MinMaxScaler
import os

class DataGenerator:
    def __init__(self, api_key, api_secret):
        self.client = Client(api_key, api_secret)
        self.setup_logging()
        self.scalers = {}

    def setup_logging(self):
        log_dir = 'logs'
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('data_generator')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(os.path.join(log_dir, 'data.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)

    def download_initial_data(self, symbol, interval='1m', lookback_days=30):
        try:
            end_time = datetime.now()
            start_time = end_time - timedelta(days=lookback_days)
            
            self.logger.info(f"Downloading initial data: {symbol} - Last {lookback_days} days...")
            
            klines = self.client.get_historical_klines(
                symbol=symbol,
                interval=interval,
                start_str=start_time.strftime("%Y-%m-%d %H:%M:%S"),
                end_str=end_time.strftime("%Y-%m-%d %H:%M:%S")
            )
            
            if not klines:
                raise ValueError(f"No data found for: {symbol} - {interval}")
            
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_volume', 'trades', 'taker_base',
                'taker_quote', 'ignore'
            ])
            
            # Clean and format data
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            df['close_time'] = pd.to_datetime(df['close_time'], unit='ms')
            numeric_columns = ['open', 'high', 'low', 'close', 'volume', 'quote_volume', 
                             'trades', 'taker_base', 'taker_quote']
            df[numeric_columns] = df[numeric_columns].apply(pd.to_numeric)
            
            # Calculate technical indicators
            df = self.calculate_indicators(df)
            
            # Check for NaN values
            if df.isnull().any().any():
                self.logger.warning(f"Found missing values in {symbol} data. Cleaning...")
                df = df.dropna()
            
            self.logger.info(f"Data downloaded successfully. Total records: {len(df)}")
            return df
            
        except Exception as e:
            self.logger.error(f"Data download error ({symbol} - {interval}): {str(e)}")
            return None

    def calculate_indicators(self, df):
        try:
            # RSI
            df['RSI'] = talib.RSI(df['close'], timeperiod=14)
            
            # MACD
            df['MACD'], df['MACD_SIGNAL'], df['MACD_HIST'] = talib.MACD(
                df['close'],
                fastperiod=12,
                slowperiod=26,
                signalperiod=9
            )
            
            # Bollinger Bands
            df['BB_UPPER'], df['BB_MIDDLE'], df['BB_LOWER'] = talib.BBANDS(
                df['close'],
                timeperiod=20,
                nbdevup=2,
                nbdevdn=2
            )
            
            # ATR
            df['ATR'] = talib.ATR(
                df['high'],
                df['low'],
                df['close'],
                timeperiod=14
            )
            
            # Moving Averages
            for period in [9, 21, 50]:
                df[f'EMA_{period}'] = talib.EMA(df['close'], timeperiod=period)
                df[f'SMA_{period}'] = talib.SMA(df['close'], timeperiod=period)
            
            # Stochastic Oscillator
            df['STOCH_K'], df['STOCH_D'] = talib.STOCH(
                df['high'],
                df['low'],
                df['close'],
                fastk_period=14,
                slowk_period=3,
                slowd_period=3
            )
            
            # OBV (On Balance Volume)
            df['OBV'] = talib.OBV(df['close'], df['volume'])
            
            # ADX (Average Directional Index)
            df['ADX'] = talib.ADX(df['high'], df['low'], df['close'], timeperiod=14)
            
            # Additional price and volume metrics
            df['Price_Change'] = df['close'].pct_change()
            df['Volume_Change'] = df['volume'].pct_change()
            df['High_Low_Range'] = (df['high'] - df['low']) / df['low']
            
            return df
            
        except Exception as e:
            self.logger.error(f"Indicator calculation error: {str(e)}")
            return df

    def generate_training_data(self, df, sequence_length=60):
        try:
            if df is None or df.empty:
                raise ValueError("No valid data found")
                
            feature_columns = [
                'open', 'high', 'low', 'close', 'volume',
                'RSI', 'MACD', 'BB_UPPER', 'BB_LOWER', 'ATR',
                'STOCH_K', 'STOCH_D', 'ADX', 'OBV',
                'Price_Change', 'Volume_Change', 'High_Low_Range'
            ]
            
            if df[feature_columns].isnull().any().any():
                df = df.dropna(subset=feature_columns)
                
            if len(df) < sequence_length + 1:
                raise ValueError(f"Insufficient data. Need at least {sequence_length + 1} records")
            
            # Scale features
            if 'price' not in self.scalers:
                self.scalers['price'] = MinMaxScaler()
                self.scalers['volume'] = MinMaxScaler()
                self.scalers['indicators'] = MinMaxScaler()
            
            price_cols = ['open', 'high', 'low', 'close']
            volume_cols = ['volume']
            indicator_cols = [col for col in feature_columns if col not in price_cols + volume_cols]
            
            scaled_prices = self.scalers['price'].fit_transform(df[price_cols])
            scaled_volume = self.scalers['volume'].fit_transform(df[volume_cols])
            scaled_indicators = self.scalers['indicators'].fit_transform(df[indicator_cols])
            
            # Combine scaled data
            scaled_data = np.column_stack((scaled_prices, scaled_volume, scaled_indicators))
            
            X, y = [], []
            for i in range(sequence_length, len(scaled_data)):
                X.append(scaled_data[i-sequence_length:i])
                y.append(scaled_data[i, 3])  # 3 = close price index
                
            X = np.array(X)
            y = np.array(y)
            
            if len(X) == 0 or len(y) == 0:
                raise ValueError("Empty arrays after data preparation")
                
            self.logger.info(f"Training data prepared. X shape: {X.shape}, y shape: {y.shape}")
            return X, y, self.scalers
            
        except Exception as e:
            self.logger.error(f"Training data preparation error: {str(e)}")
            return None, None, None

    def download_multi_timeframe_data(self, symbol, timeframes=['1m', '5m', '15m']):
        try:
            data = {}
            for timeframe in timeframes:
                self.logger.info(f"Downloading {timeframe} data...")
                df = self.download_initial_data(symbol, timeframe)
                if df is not None and not df.empty:
                    data[timeframe] = df
                else:
                    self.logger.warning(f"Could not download or empty data for {timeframe}")
                    
            if not data:
                self.logger.error("Could not download data for any timeframe")
                
            return data
            
        except Exception as e:
            self.logger.error(f"Multi-timeframe data download error: {str(e)}")
            return None

    def prepare_feature_matrix(self, df):
        try:
            features = pd.DataFrame()
            
            # Price-based features
            features['price_change'] = df['close'].pct_change()
            features['high_low_range'] = (df['high'] - df['low']) / df['low']
            features['volume_change'] = df['volume'].pct_change()
            
            # Technical indicators
            features['rsi'] = df['RSI']
            features['macd'] = df['MACD']
            features['macd_hist'] = df['MACD_HIST']
            features['bb_position'] = (df['close'] - df['BB_MIDDLE']) / (df['BB_UPPER'] - df['BB_LOWER'])
            features['atr_ratio'] = df['ATR'] / df['close']
            features['stoch_k'] = df['STOCH_K']
            features['stoch_d'] = df['STOCH_D']
            features['adx'] = df['ADX']
            features['obv_change'] = df['OBV'].pct_change()
            
            # Moving average features
            for period in [9, 21, 50]:
                features[f'ema_{period}_dist'] = (df['close'] - df[f'EMA_{period}']) / df['close']
                features[f'sma_{period}_dist'] = (df['close'] - df[f'SMA_{period}']) / df['close']
            
            # Create target variables
            features['target_price'] = df['close'].shift(-1)
            features['target_return'] = features['target_price'].pct_change()
            
            # Direction target (1: up, 0: down)
            features['target_direction'] = (features['target_return'] > 0).astype(int)
            
            return features.dropna()
            
        except Exception as e:
            self.logger.error(f"Feature matrix preparation error: {str(e)}")
            return pd.DataFrame()

    def get_real_time_data(self, symbol):
        try:
            # Get latest kline
            kline = self.client.get_klines(
                symbol=symbol,
                interval=Client.KLINE_INTERVAL_1MINUTE,
                limit=1
            )
            
            if not kline:
                raise ValueError(f"No real-time data available for {symbol}")
            
            data = {
                'timestamp': datetime.fromtimestamp(kline[0][0] / 1000),
                'open': float(kline[0][1]),
                'high': float(kline[0][2]),
                'low': float(kline[0][3]),
                'close': float(kline[0][4]),
                'volume': float(kline[0][5]),
                'close_time': datetime.fromtimestamp(kline[0][6] / 1000),
                'quote_volume': float(kline[0][7]),
                'trades': int(kline[0][8]),
                'taker_base': float(kline[0][9]),
                'taker_quote': float(kline[0][10])
            }
            
            return data
            
        except Exception as e:
            self.logger.error(f"Real-time data fetch error: {str(e)}")
            return None
