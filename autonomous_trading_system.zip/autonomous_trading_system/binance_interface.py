from binance.client import Client
from binance.exceptions import BinanceAPIException
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
import time
import math
from threading import Lock

class BinanceInterface:
    def __init__(self, api_key, api_secret):
        self.api_key = api_key
        self.api_secret = api_secret
        self.client = Client(api_key, api_secret)
        self.request_lock = Lock()
        
        # Rate limiting
        self.request_weight = 0
        self.last_request_reset = datetime.now()
        self.max_requests_per_minute = 1200
        
    def _handle_rate_limit(self):
        """API rate limiting yönetimi"""
        with self.request_lock:
            current_time = datetime.now()
            # 1 dakika geçtiyse sayacı sıfırla
            if (current_time - self.last_request_reset).total_seconds() >= 60:
                self.request_weight = 0
                self.last_request_reset = current_time
                
            # Rate limit aşıldıysa bekle
            if self.request_weight >= self.max_requests_per_minute:
                sleep_time = 60 - (current_time - self.last_request_reset).total_seconds()
                if sleep_time > 0:
                    time.sleep(sleep_time)
                self.request_weight = 0
                self.last_request_reset = datetime.now()
                
            self.request_weight += 1
            
    def get_historical_klines(self, symbol, interval, start_str=None, limit=1000):
        """Geçmiş kline verilerini çek"""
        try:
            self._handle_rate_limit()
            
            klines = self.client.get_historical_klines(
                symbol=symbol,
                interval=interval,
                start_str=start_str,
                limit=limit
            )
            
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_volume', 'trades', 'taker_base',
                'taker_quote', 'ignore'
            ])
            
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            
            # String değerleri float'a çevir
            for col in ['open', 'high', 'low', 'close', 'volume', 'quote_volume']:
                df[col] = df[col].astype(float)
                
            return df
            
        except BinanceAPIException as e:
            logging.error(f"Binance API hatası (get_historical_klines): {e}")
            return None
        except Exception as e:
            logging.error(f"Veri çekme hatası (get_historical_klines): {e}")
            return None
            
    def get_current_price(self, symbol):
        """Anlık fiyat bilgisi"""
        try:
            self._handle_rate_limit()
            ticker = self.client.get_symbol_ticker(symbol=symbol)
            return float(ticker['price'])
        except Exception as e:
            logging.error(f"Fiyat alma hatası: {e}")
            return None
            
    def get_exchange_info(self, symbol):
        """Symbol için borsa bilgilerini al"""
        try:
            self._handle_rate_limit()
            info = self.client.get_exchange_info()
            
            # Symbol'e ait bilgileri bul
            symbol_info = next(
                (item for item in info['symbols'] if item['symbol'] == symbol),
                None
            )
            
            if symbol_info:
                return {
                    'base_asset': symbol_info['baseAsset'],
                    'quote_asset': symbol_info['quoteAsset'],
                    'min_price': float(next(f for f in symbol_info['filters'] 
                                         if f['filterType'] == 'PRICE_FILTER')['minPrice']),
                    'min_qty': float(next(f for f in symbol_info['filters']
                                        if f['filterType'] == 'LOT_SIZE')['minQty']),
                    'step_size': float(next(f for f in symbol_info['filters']
                                          if f['filterType'] == 'LOT_SIZE')['stepSize'])
                }
            return None
            
        except Exception as e:
            logging.error(f"Exchange info alma hatası: {e}")
            return None
            
    def get_balance(self, asset):
        """Varlık bakiyesini al"""
        try:
            self._handle_rate_limit()
            balance = self.client.get_asset_balance(asset=asset)
            return {
                'free': float(balance['free']),
                'locked': float(balance['locked'])
            }
        except Exception as e:
            logging.error(f"Bakiye alma hatası: {e}")
            return None
            
    def create_order(self, symbol, side, order_type, quantity=None, price=None, stop_price=None):
        """İşlem emri oluştur"""
        try:
            self._handle_rate_limit()
            
            params = {
                'symbol': symbol,
                'side': side,
                'type': order_type
            }
            
            if quantity:
                params['quantity'] = self.round_step_size(quantity, self.get_exchange_info(symbol)['step_size'])
            if price:
                params['price'] = self.round_price(price, self.get_exchange_info(symbol)['min_price'])
            if stop_price:
                params['stopPrice'] = self.round_price(stop_price, self.get_exchange_info(symbol)['min_price'])
                
            order = self.client.create_order(**params)
            logging.info(f"İşlem emri oluşturuldu: {order}")
            return order
            
        except BinanceAPIException as e:
            logging.error(f"İşlem emri hatası: {e}")
            return None
        except Exception as e:
            logging.error(f"İşlem emri oluşturma hatası: {e}")
            return None
            
    def cancel_order(self, symbol, order_id):
        """İşlem emrini iptal et"""
        try:
            self._handle_rate_limit()
            result = self.client.cancel_order(
                symbol=symbol,
                orderId=order_id
            )
            logging.info(f"İşlem emri iptal edildi: {result}")
            return result
        except Exception as e:
            logging.error(f"İşlem iptal hatası: {e}")
            return None
            
    def get_open_orders(self, symbol=None):
        """Açık emirleri getir"""
        try:
            self._handle_rate_limit()
            if symbol:
                orders = self.client.get_open_orders(symbol=symbol)
            else:
                orders = self.client.get_open_orders()
            return orders
        except Exception as e:
            logging.error(f"Açık emir alma hatası: {e}")
            return None
            
    def get_order_status(self, symbol, order_id):
        """Emir durumunu kontrol et"""
        try:
            self._handle_rate_limit()
            order = self.client.get_order(
                symbol=symbol,
                orderId=order_id
            )
            return order
        except Exception as e:
            logging.error(f"Emir durumu alma hatası: {e}")
            return None
            
    def get_account_info(self):
        """Hesap bilgilerini al"""
        try:
            self._handle_rate_limit()
            info = self.client.get_account()
            return {
                'balances': info['balances'],
                'maker_commission': info['makerCommission'],
                'taker_commission': info['takerCommission']
            }
        except Exception as e:
            logging.error(f"Hesap bilgisi alma hatası: {e}")
            return None
            
    def get_recent_trades(self, symbol, limit=500):
        """Son işlemleri al"""
        try:
            self._handle_rate_limit()
            trades = self.client.get_recent_trades(symbol=symbol, limit=limit)
            
            df = pd.DataFrame(trades)
            df['time'] = pd.to_datetime(df['time'], unit='ms')
            df['price'] = df['price'].astype(float)
            df['qty'] = df['qty'].astype(float)
            
            return df
        except Exception as e:
            logging.error(f"Son işlemleri alma hatası: {e}")
            return None
            
    def get_ticker_24h(self, symbol):
        """24 saatlik fiyat değişim bilgileri"""
        try:
            self._handle_rate_limit()
            ticker = self.client.get_ticker(symbol=symbol)
            return {
                'price_change': float(ticker['priceChange']),
                'price_change_percent': float(ticker['priceChangePercent']),
                'weighted_avg_price': float(ticker['weightedAvgPrice']),
                'high_price': float(ticker['highPrice']),
                'low_price': float(ticker['lowPrice']),
                'volume': float(ticker['volume']),
                'quote_volume': float(ticker['quoteVolume'])
            }
        except Exception as e:
            logging.error(f"24h ticker alma hatası: {e}")
            return None
            
    def get_orderbook(self, symbol, limit=100):
        """Emir defteri al"""
        try:
            self._handle_rate_limit()
            depth = self.client.get_order_book(symbol=symbol, limit=limit)
            
            df_bids = pd.DataFrame(depth['bids'], columns=['price', 'quantity'])
            df_asks = pd.DataFrame(depth['asks'], columns=['price', 'quantity'])
            
            df_bids[['price', 'quantity']] = df_bids[['price', 'quantity']].astype(float)
            df_asks[['price', 'quantity']] = df_asks[['price', 'quantity']].astype(float)
            
            return {
                'bids': df_bids,
                'asks': df_asks,
                'last_update': depth['lastUpdateId']
            }
        except Exception as e:
            logging.error(f"Emir defteri alma hatası: {e}")
            return None
            
    def round_step_size(self, quantity, step_size):
        """Miktarı step size'a göre yuvarla"""
        precision = int(round(-math.log(step_size, 10), 0))
        return round(quantity, precision)
        
    def round_price(self, price, tick_size):
        """Fiyatı tick size'a göre yuvarla"""
        precision = int(round(-math.log(tick_size, 10), 0))
        return round(price, precision)