import logging
from datetime import datetime
import os
from binance.exceptions import BinanceAPIException

class TradeExecutor:
    def __init__(self, binance_client, risk_manager, database_manager):
        self.binance = binance_client
        self.risk_manager = risk_manager
        self.db_manager = database_manager
        self.setup_logging()
        
    def setup_logging(self):
        log_dir = 'logs'
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('trade_executor')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(os.path.join(log_dir, 'trades.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)

    def execute_trade(self, trade_signal):
        """
        Trade sinyalini işleme alıp gerçekleştir
        """
        try:
            # Trade parametrelerini hazırla
            symbol = trade_signal['symbol']
            side = trade_signal['side']
            current_price = self.binance.get_current_price(symbol)
            
            if not current_price:
                raise ValueError(f"Could not get current price for {symbol}")

            # Risk parametrelerini hesapla
            risk_params = self.risk_manager.calculate_risk_parameters(symbol, trade_signal['strength'])
            
            if not risk_params['can_trade']:
                self.logger.warning(f"Risk parameters prevent trading for {symbol}")
                return None

            # İşlem büyüklüğünü hesapla
            quantity = self.risk_manager.calculate_position_size(current_price)
            
            if quantity <= 0:
                self.logger.warning("Position size too small")
                return None

            # Stop loss ve take profit hesapla
            stop_loss, take_profit = self.calculate_exit_points(
                current_price, 
                trade_signal['atr'],
                side == 'BUY'
            )

            # Market emri oluştur
            order = self.binance.create_order(
                symbol=symbol,
                side=side,
                order_type='MARKET',
                quantity=quantity
            )

            if not order:
                raise ValueError("Order creation failed")

            # İşlemi veritabanına kaydet
            trade_data = {
                'symbol': symbol,
                'side': side,
                'quantity': quantity,
                'entry_price': float(order['price']),
                'stop_loss': stop_loss,
                'take_profit': take_profit,
                'entry_time': datetime.now(),
                'status': 'OPEN',
                'risk_level': risk_params['risk_level']
            }

            trade_id = self.db_manager.save_trade(trade_data)
            
            if not trade_id:
                raise ValueError("Trade save failed")

            self.logger.info(f"Trade executed successfully: {trade_data}")
            return trade_id

        except BinanceAPIException as e:
            self.logger.error(f"Binance API error during trade execution: {e}")
            return None
        except Exception as e:
            self.logger.error(f"Trade execution error: {e}")
            return None

    def close_trade(self, trade_id, reason='manual'):
        """
        Açık işlemi kapat
        """
        try:
            # İşlem detaylarını al
            trade = self.db_manager.get_open_trades()[0]  # ID'ye göre filtreleme eklenebilir
            
            if not trade:
                raise ValueError(f"No open trade found with ID: {trade_id}")

            # Market emri ile pozisyonu kapat
            close_order = self.binance.create_order(
                symbol=trade['symbol'],
                side='SELL' if trade['side'] == 'BUY' else 'BUY',
                order_type='MARKET',
                quantity=trade['quantity']
            )

            if not close_order:
                raise ValueError("Close order creation failed")

            # İşlem sonuç bilgilerini hesapla
            exit_price = float(close_order['price'])
            profit_loss = (exit_price - trade['entry_price']) * trade['quantity']
            if trade['side'] == 'SELL':
                profit_loss *= -1

            # İşlemi güncelle
            trade_update = {
                'exit_price': exit_price,
                'exit_time': datetime.now(),
                'status': 'CLOSED',
                'profit_loss': profit_loss,
                'close_reason': reason
            }

            self.db_manager.update_trade(trade_id, trade_update)
            
            # Risk yöneticisini güncelle
            self.risk_manager.update_balance(profit_loss)

            self.logger.info(f"Trade closed successfully: {trade_update}")
            return True

        except BinanceAPIException as e:
            self.logger.error(f"Binance API error during trade closure: {e}")
            return False
        except Exception as e:
            self.logger.error(f"Trade closure error: {e}")
            return False

    def calculate_exit_points(self, entry_price, atr, is_long=True):
        """
        Stop loss ve take profit seviyelerini hesapla
        """
        try:
            atr_multiplier = 2
            sl_distance = atr * atr_multiplier
            tp_distance = sl_distance * 2  # 1:2 risk/ödül oranı
            
            if is_long:
                stop_loss = entry_price - sl_distance
                take_profit = entry_price + tp_distance
            else:
                stop_loss = entry_price + sl_distance
                take_profit = entry_price - tp_distance
                
            return stop_loss, take_profit
            
        except Exception as e:
            self.logger.error(f"Exit points calculation error: {e}")
            return entry_price * 0.98, entry_price * 1.02  # Default %2 SL/TP

    def modify_trade(self, trade_id, new_stop_loss=None, new_take_profit=None):
        """
        Mevcut işlemin stop loss/take profit seviyelerini güncelle
        """
        try:
            updates = {}
            if new_stop_loss:
                updates['stop_loss'] = new_stop_loss
            if new_take_profit:
                updates['take_profit'] = new_take_profit

            if updates:
                self.db_manager.update_trade(trade_id, updates)
                self.logger.info(f"Trade {trade_id} modified: {updates}")
                return True
            return False

        except Exception as e:
            self.logger.error(f"Trade modification error: {e}")
            return False

    def check_exit_conditions(self, trade):
        """
        İşlem çıkış koşullarını kontrol et
        """
        try:
            current_price = self.binance.get_current_price(trade['symbol'])
            if not current_price:
                return False, None

            # Stop loss kontrolü
            if trade['side'] == 'BUY':
                if current_price <= trade['stop_loss']:
                    return True, 'stop_loss'
                if current_price >= trade['take_profit']:
                    return True, 'take_profit'
            else:  # SELL
                if current_price >= trade['stop_loss']:
                    return True, 'stop_loss'
                if current_price <= trade['take_profit']:
                    return True, 'take_profit'

            return False, None

        except Exception as e:
            self.logger.error(f"Exit condition check error: {e}")
            return False, None

    def update_trailing_stop(self, trade):
        """
        Trailing stop seviyesini güncelle
        """
        try:
            current_price = self.binance.get_current_price(trade['symbol'])
            if not current_price:
                return False

            if trade['side'] == 'BUY':
                profit_pct = (current_price - trade['entry_price']) / trade['entry_price']
            else:
                profit_pct = (trade['entry_price'] - current_price) / trade['entry_price']

            # Kâr yüzdelerine göre trailing stop seviyeleri
            levels = {
                0.01: 0.005,  # %1 kârda trailing stop %0.5
                0.02: 0.01,   # %2 kârda trailing stop %1
                0.03: 0.015,  # %3 kârda trailing stop %1.5
                0.05: 0.025   # %5 kârda trailing stop %2.5
            }

            for target_pct, stop_pct in levels.items():
                if profit_pct >= target_pct:
                    new_stop = trade['entry_price'] * (1 + (stop_pct if trade['side'] == 'BUY' else -stop_pct))
                    if trade['side'] == 'BUY':
                        if new_stop > trade['stop_loss']:
                            self.modify_trade(trade['id'], new_stop_loss=new_stop)
                    else:
                        if new_stop < trade['stop_loss']:
                            self.modify_trade(trade['id'], new_stop_loss=new_stop)
                    return True

            return False

        except Exception as e:
            self.logger.error(f"Trailing stop update error: {e}")
            return False