import pandas as pd
import numpy as np
import logging
import talib
from datetime import datetime

class StrategyManager:
    def __init__(self):
        self.setup_logging()
        self.setup_indicators()
        self.setup_weights()
        self.risk_reward_ratio = 2.0
        
    def setup_logging(self):
        self.logger = logging.getLogger('strategy_manager')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler('logs/strategy.log')
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        
    def setup_indicators(self):
        self.indicators = {
            'RSI': {'timeperiod': 14},
            'MACD': {'fast': 12, 'slow': 26, 'signal': 9},
            'BB': {'timeperiod': 20, 'stddev': 2},
            'ATR': {'timeperiod': 14},
            'EMA': {'periods': [9, 21, 50]},
            'VWAP': {'window': 24}
        }
        
    def setup_weights(self):
        self.weights = {
            'trend': 0.35,
            'momentum': 0.25,
            'volatility': 0.20,
            'volume': 0.20
        }
        
    def calculate_composite_signal(self, signals):
        try:
            composite = 0
            
            for signal_type, value in signals.items():
                if signal_type in self.weights:
                    composite += value * self.weights[signal_type]
            
            composite = np.clip(composite, -1, 1)
            
            return {
                'value': composite,
                'direction': 'BUY' if composite > 0.2 else 'SELL' if composite < -0.2 else 'HOLD',
                'strength': abs(composite),
                'timestamp': datetime.now()
            }
            
        except Exception as e:
            self.logger.error(f"Composite signal calculation error: {str(e)}")
            return {'value': 0, 'direction': 'HOLD', 'strength': 0, 'timestamp': datetime.now()}
            
    def calculate_indicators(self, df):
        try:
            if df.empty or len(df) < 50:
                self.logger.warning("Insufficient data for indicator calculation")
                return pd.DataFrame()
                
            df = df.copy()
            
            # RSI
            df['RSI'] = talib.RSI(df['close'], timeperiod=self.indicators['RSI']['timeperiod'])
            
            # MACD
            df['MACD'], df['MACD_SIGNAL'], df['MACD_HIST'] = talib.MACD(
                df['close'],
                fastperiod=self.indicators['MACD']['fast'],
                slowperiod=self.indicators['MACD']['slow'],
                signalperiod=self.indicators['MACD']['signal']
            )
            
            # Bollinger Bands
            df['BB_UPPER'], df['BB_MIDDLE'], df['BB_LOWER'] = talib.BBANDS(
                df['close'],
                timeperiod=self.indicators['BB']['timeperiod'],
                nbdevup=self.indicators['BB']['stddev'],
                nbdevdn=self.indicators['BB']['stddev']
            )
            
            # ATR
            df['ATR'] = talib.ATR(
                df['high'],
                df['low'],
                df['close'],
                timeperiod=self.indicators['ATR']['timeperiod']
            )
            
            # EMAs
            for period in self.indicators['EMA']['periods']:
                df[f'EMA_{period}'] = talib.EMA(df['close'], timeperiod=period)
                
            # VWAP
            df['VWAP'] = self.calculate_vwap(df)
            
            return df
            
        except Exception as e:
            self.logger.error(f"Indicator calculation error: {str(e)}")
            return pd.DataFrame()
            
    def calculate_vwap(self, df):
        try:
            df['Typical_Price'] = (df['high'] + df['low'] + df['close']) / 3
            df['VP'] = df['Typical_Price'] * df['volume']
            
            cumulative_vp = df['VP'].rolling(window=self.indicators['VWAP']['window']).sum()
            cumulative_volume = df['volume'].rolling(window=self.indicators['VWAP']['window']).sum()
            
            vwap = cumulative_vp / cumulative_volume
            return vwap.fillna(method='ffill')
            
        except Exception as e:
            self.logger.error(f"VWAP calculation error: {str(e)}")
            return pd.Series(index=df.index)
            
    def generate_signals(self, df):
        try:
            if df.empty:
                return {}
                
            signals = {
                'trend': self._analyze_trend(df),
                'momentum': self._analyze_momentum(df),
                'volatility': self._analyze_volatility(df),
                'volume': self._analyze_volume(df)
            }
            
            composite = self.calculate_composite_signal(signals)
            signals.update(composite)
            
            return signals
            
        except Exception as e:
            self.logger.error(f"Signal generation error: {str(e)}")
            return {}
            
    def _analyze_trend(self, df):
        try:
            ema_short = df['EMA_9'].iloc[-1]
            ema_medium = df['EMA_21'].iloc[-1]
            ema_long = df['EMA_50'].iloc[-1]
            
            trend_score = 0
            
            # Kısa vadeli trend
            if ema_short > ema_medium:
                trend_score += 0.4
            elif ema_short < ema_medium:
                trend_score -= 0.4
                
            # Uzun vadeli trend
            if ema_medium > ema_long:
                trend_score += 0.6
            elif ema_medium < ema_long:
                trend_score -= 0.6
                
            return trend_score
            
        except Exception as e:
            self.logger.error(f"Trend analysis error: {str(e)}")
            return 0
            
    def _analyze_momentum(self, df):
        try:
            rsi = df['RSI'].iloc[-1]
            macd = df['MACD'].iloc[-1]
            macd_signal = df['MACD_SIGNAL'].iloc[-1]
            
            momentum_score = 0
            
            # RSI analizi
            if rsi > 70:
                momentum_score -= 0.6
            elif rsi < 30:
                momentum_score += 0.6
            elif rsi > 60:
                momentum_score -= 0.3
            elif rsi < 40:
                momentum_score += 0.3
                
            # MACD analizi
            if macd > macd_signal:
                momentum_score += 0.4
            else:
                momentum_score -= 0.4
                
            return momentum_score
            
        except Exception as e:
            self.logger.error(f"Momentum analysis error: {str(e)}")
            return 0
            
    def _analyze_volatility(self, df):
        try:
            current_price = df['close'].iloc[-1]
            bb_upper = df['BB_UPPER'].iloc[-1]
            bb_lower = df['BB_LOWER'].iloc[-1]
            bb_middle = df['BB_MIDDLE'].iloc[-1]
            atr = df['ATR'].iloc[-1]
            
            volatility_score = 0
            
            # Bollinger Bant analizi
            bb_width = (bb_upper - bb_lower) / bb_middle
            if bb_width > 0.05:  # Yüksek volatilite
                if current_price > bb_upper:
                    volatility_score -= 0.7
                elif current_price < bb_lower:
                    volatility_score += 0.7
                    
            # ATR analizi
            atr_ratio = atr / current_price
            if atr_ratio > 0.02:  # Yüksek volatilite
                volatility_score *= 0.8  # Riski azalt
                
            return volatility_score
            
        except Exception as e:
            self.logger.error(f"Volatility analysis error: {str(e)}")
            return 0
            
    def _analyze_volume(self, df):
        try:
            current_volume = df['volume'].iloc[-1]
            avg_volume = df['volume'].rolling(window=20).mean().iloc[-1]
            
            volume_score = 0
            
            # Hacim karşılaştırması
            volume_ratio = current_volume / avg_volume
            if volume_ratio > 2:
                volume_score = 0.8
            elif volume_ratio > 1.5:
                volume_score = 0.4
            elif volume_ratio < 0.5:
                volume_score = -0.4
            elif volume_ratio < 0.25:
                volume_score = -0.8
                
            return volume_score
            
        except Exception as e:
            self.logger.error(f"Volume analysis error: {str(e)}")
            return 0
            
    def get_stop_loss_take_profit(self, entry_price, atr, is_long=True):
        try:
            atr_multiplier = 2
            sl_distance = atr * atr_multiplier
            tp_distance = sl_distance * self.risk_reward_ratio
            
            if is_long:
                stop_loss = entry_price - sl_distance
                take_profit = entry_price + tp_distance
            else:
                stop_loss = entry_price + sl_distance
                take_profit = entry_price - tp_distance
                
            return stop_loss, take_profit
            
        except Exception as e:
            self.logger.error(f"SL/TP calculation error: {str(e)}")
            return entry_price * 0.98, entry_price * 1.02 # Default 2% SL/TP
        
    def get_position_size(self, capital, risk_per_trade, entry_price, stop_loss):
        """Calculate position size based on risk management rules"""
        try:
            risk_amount = capital * (risk_per_trade / 100)
            price_risk = abs(entry_price - stop_loss)
            
            if price_risk == 0:
                return 0
                
            position_size = risk_amount / price_risk
            return round(position_size, 8)
            
        except Exception as e:
            self.logger.error(f"Position size calculation error: {str(e)}")
            return 0