import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib
import os
import logging
from datetime import datetime

__all__ = ['ModelManager']

class ModelManager:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.models_dir = os.path.join(base_dir, 'models')
        os.makedirs(self.models_dir, exist_ok=True)
        self.setup_logging()
        self.initialize_models()
        
    def setup_logging(self):
        log_dir = os.path.join(self.base_dir, 'logs')
        os.makedirs(log_dir, exist_ok=True)
        
        self.logger = logging.getLogger('model_manager')
        self.logger.setLevel(logging.INFO)
        handler = logging.FileHandler(os.path.join(log_dir, 'model.log'))
        handler.setFormatter(logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s'))
        self.logger.addHandler(handler)
        
    def initialize_models(self):
        self.models = {}
        self.scalers = {}
        
        self.model_configs = {
            'trend': {
                'n_estimators': 100,
                'max_depth': 10,
                'min_samples_split': 5
            },
            'reversal': {
                'n_estimators': 150,
                'max_depth': 8,
                'min_samples_split': 4
            }
        }
        
        for model_type in self.model_configs.keys():
            model_path = os.path.join(self.models_dir, f'{model_type}_model.joblib')
            scaler_path = os.path.join(self.models_dir, f'{model_type}_scaler.joblib')
            
            if os.path.exists(model_path) and os.path.exists(scaler_path):
                try:
                    self.models[model_type] = joblib.load(model_path)
                    self.scalers[model_type] = joblib.load(scaler_path)
                    self.logger.info(f"Loaded existing {model_type} model")
                except Exception as e:
                    self.logger.error(f"Error loading {model_type} model: {e}")
                    self._create_new_model(model_type)
            else:
                self._create_new_model(model_type)
                
    def _create_new_model(self, model_type):
        self.models[model_type] = RandomForestClassifier(**self.model_configs[model_type])
        self.scalers[model_type] = MinMaxScaler()
        self.logger.info(f"Created new {model_type} model")
        
    def prepare_features(self, df):
        try:
            features = pd.DataFrame()
            
            features['price_momentum'] = df['close'].pct_change()
            features['price_volatility'] = df['close'].rolling(window=20).std()
            features['volume_momentum'] = df['volume'].pct_change()
            features['volume_ma_ratio'] = df['volume'] / df['volume'].rolling(window=20).mean()
            features['rsi'] = df['RSI']
            features['macd'] = df['MACD']
            features['bb_position'] = (df['close'] - df['BB_MIDDLE']) / (df['BB_UPPER'] - df['BB_MIDDLE'])
            
            features['trend_target'] = np.where(df['close'].shift(-1) > df['close'], 1, 0)
            features['reversal_target'] = self._calculate_reversal_target(df)
            
            return features.dropna()
            
        except Exception as e:
            self.logger.error(f"Feature preparation error: {e}")
            return pd.DataFrame()
            
    def _calculate_reversal_target(self, df, threshold=0.02):
        future_return = df['close'].shift(-5).pct_change(5)
        current_trend = df['close'].pct_change(5)
        
        reversal = pd.Series(0, index=df.index)
        reversal[(current_trend < -threshold) & (future_return > threshold)] = 1
        reversal[(current_trend > threshold) & (future_return < -threshold)] = 2
        
        return reversal
        
    def update_models(self, data):
        try:
            if data is None or data.empty:
                raise ValueError("No valid data for model update")
                
            success = True
            for model_type in self.models:
                try:
                    self._train_single_model(model_type, data)
                    self.logger.info(f"{model_type} model updated successfully")
                except Exception as e:
                    self.logger.error(f"Error updating {model_type} model: {str(e)}")
                    success = False
                    
            return success
            
        except Exception as e:
            self.logger.error(f"Model update error: {str(e)}")
            return False
            
    def _train_single_model(self, model_type, data):
        try:
            features = self.prepare_features(data)
            if features.empty:
                raise ValueError("No valid features for training")
                
            feature_cols = [col for col in features.columns if not col.endswith('_target')]
            target_col = f'{model_type}_target'
            
            if target_col not in features.columns:
                raise ValueError(f"Target column {target_col} not found")
                
            X = features[feature_cols]
            y = features[target_col]
            
            X_scaled = self.scalers[model_type].fit_transform(X)
            X_train, X_test, y_train, y_test = train_test_split(X_scaled, y, test_size=0.2)
            
            self.models[model_type].fit(X_train, y_train)
            
            train_score = self.models[model_type].score(X_train, y_train)
            test_score = self.models[model_type].score(X_test, y_test)
            
            self.logger.info(f"{model_type} model - Train: {train_score:.3f}, Test: {test_score:.3f}")
            
            self._save_model(model_type)
            
        except Exception as e:
            self.logger.error(f"Training error for {model_type}: {str(e)}")
            raise
            
    def _save_model(self, model_type):
        try:
            model_path = os.path.join(self.models_dir, f'{model_type}_model.joblib')
            scaler_path = os.path.join(self.models_dir, f'{model_type}_scaler.joblib')
            
            joblib.dump(self.models[model_type], model_path)
            joblib.dump(self.scalers[model_type], scaler_path)
            
        except Exception as e:
            self.logger.error(f"Error saving {model_type} model: {str(e)}")
            
    def predict(self, features_df):
        try:
            if features_df.empty:
                return {}
                
            predictions = {}
            feature_cols = [col for col in features_df.columns if not col.endswith('_target')]
            
            for model_type, model in self.models.items():
                X = features_df[feature_cols].iloc[-1:].copy()
                X_scaled = self.scalers[model_type].transform(X)
                
                pred = model.predict(X_scaled)[0]
                prob = model.predict_proba(X_scaled)[0]
                
                predictions[model_type] = {
                    'prediction': int(pred),
                    'probability': float(max(prob)),
                    'timestamp': datetime.now()
                }
                
            return predictions
            
        except Exception as e:
            self.logger.error(f"Prediction error: {str(e)}")
            return {}