import pandas as pd
import numpy as np
import os
import pickle
from datetime import datetime, timedelta
import glob
import shutil
import re
import json
import logging
from pathlib import Path
from sklearn.preprocessing import MinMaxScaler

class DataManager:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.data_paths = self._setup_data_paths()
        self.setup_logging()
        
    def setup_logging(self):
        """Configure logging settings"""
        log_path = os.path.join(self.base_dir, 'logs', 'data_manager.log')
        os.makedirs(os.path.dirname(log_path), exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(log_path),
                logging.StreamHandler()
            ]
        )
        
    def _setup_data_paths(self):
        """Setup data directory structure"""
        paths = {
            'raw_market_data': os.path.join(self.base_dir, 'data', 'market_data'),
            'processed_data': os.path.join(self.base_dir, 'data', 'processed'),
            'training_history': os.path.join(self.base_dir, 'data', 'training_history'),
            'performance_data': os.path.join(self.base_dir, 'data', 'performance'),
            'models': os.path.join(self.base_dir, 'models')
        }
        
        for path in paths.values():
            os.makedirs(path, exist_ok=True)
            
        return paths
        
    def save_market_data(self, df, symbol, timeframe):
        """Save market data with error handling and validation"""
        if df is None or df.empty:
            logging.warning(f"Empty dataframe received for {symbol}_{timeframe}")
            return
            
        required_columns = ['timestamp', 'open', 'high', 'low', 'close', 'volume', 'taker_base_vol']
        if not all(col in df.columns for col in required_columns):
            missing_cols = [col for col in required_columns if col not in df.columns]
            logging.error(f"Missing required columns: {missing_cols}")
            return
            
        date = datetime.now().strftime('%Y%m%d')
        filename = f"{symbol}_{timeframe}_{date}.parquet"
        filepath = os.path.join(self.data_paths['raw_market_data'], filename)
        
        try:
            if os.path.exists(filepath):
                existing_df = pd.read_parquet(filepath)
                df = pd.concat([existing_df, df])
                df = df.drop_duplicates(subset=['timestamp'])
                
            df = df.sort_values('timestamp')
            df.to_parquet(filepath, engine='pyarrow', compression='snappy')
            logging.info(f"Successfully saved market data: {filename}")
            
        except Exception as e:
            logging.error(f"Error saving market data: {str(e)}", exc_info=True)
            
    def load_historical_data(self, symbol, timeframe, days=30):
        """Load historical data with proper error handling"""
        try:
            pattern = f"{symbol}_{timeframe}_*.parquet"
            files = glob.glob(os.path.join(self.data_paths['raw_market_data'], pattern))
            
            if not files:
                logging.warning(f"No historical data found for {symbol}_{timeframe}")
                return pd.DataFrame()
                
            dfs = []
            start_date = datetime.now() - timedelta(days=days)
            
            for file in files:
                try:
                    file_date = datetime.strptime(file.split('_')[-1].replace('.parquet', ''), '%Y%m%d')
                    if file_date >= start_date:
                        df = pd.read_parquet(file)
                        if not df.empty:
                            dfs.append(df)
                except Exception as e:
                    logging.error(f"Error reading file {file}: {str(e)}")
                    continue
                    
            if not dfs:
                return pd.DataFrame()
                
            combined_df = pd.concat(dfs, ignore_index=True)
            combined_df = combined_df.sort_values('timestamp').drop_duplicates(subset=['timestamp'])
            
            return combined_df
            
        except Exception as e:
            logging.error(f"Error loading historical data: {str(e)}", exc_info=True)
            return pd.DataFrame()
            
    def get_data_for_training(self, symbol, timeframe, days=30):
        """Prepare data for training with proper error handling and validation"""
        df = self.load_historical_data(symbol, timeframe, days)
        
        if df.empty:
            logging.warning("No data available for training")
            return None
            
        try:
            features = ['open', 'high', 'low', 'close', 'volume']
            
            # Validate data
            if not all(feature in df.columns for feature in features):
                missing_features = [f for f in features if f not in df.columns]
                logging.error(f"Missing required features: {missing_features}")
                return None
                
            # Remove any rows with NaN values
            df = df.dropna(subset=features)
            
            if len(df) == 0:
                logging.error("No valid data remaining after cleaning")
                return None
                
            # Scale the features
            scaler = MinMaxScaler()
            scaled_data = scaler.fit_transform(df[features])
            
            df_scaled = pd.DataFrame(
                scaled_data,
                columns=features,
                index=df.index
            )
            
            return {
                'raw_data': df,
                'processed_data': df_scaled,
                'scaler': scaler
            }
            
        except Exception as e:
            logging.error(f"Error preparing training data: {str(e)}", exc_info=True)
            return None
            
    def save_model_state(self, model_name, model_state, metrics):
        """Save model state with validation"""
        try:
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"{model_name}_state_{timestamp}.pkl"
            filepath = os.path.join(self.data_paths['models'], filename)
            
            state_data = {
                'timestamp': timestamp,
                'state': model_state,
                'metrics': metrics
            }
            
            with open(filepath, 'wb') as f:
                pickle.dump(state_data, f)
                
            # Cleanup old model states
            self._cleanup_old_model_states(model_name)
            
            logging.info(f"Successfully saved model state: {filename}")
            
        except Exception as e:
            logging.error(f"Error saving model state: {str(e)}", exc_info=True)
            
    def _cleanup_old_model_states(self, model_name, keep_last_n=5):
        """Keep only the n most recent model states"""
        pattern = f"{model_name}_state_*.pkl"
        files = glob.glob(os.path.join(self.data_paths['models'], pattern))
        
        if len(files) > keep_last_n:
            files.sort(key=os.path.getctime, reverse=True)
            for old_file in files[keep_last_n:]:
                try:
                    os.remove(old_file)
                except Exception as e:
                    logging.error(f"Error removing old model state {old_file}: {str(e)}")
                    
    def load_latest_model_state(self, model_name):
        """Load latest model state with validation"""
        try:
            pattern = f"{model_name}_state_*.pkl"
            files = glob.glob(os.path.join(self.data_paths['models'], pattern))
            
            if not files:
                logging.warning(f"No model state found for {model_name}")
                return None
                
            latest_file = max(files, key=os.path.getctime)
            
            with open(latest_file, 'rb') as f:
                state_data = pickle.load(f)
                
            # Validate state data structure
            required_keys = ['timestamp', 'state', 'metrics']
            if not all(key in state_data for key in required_keys):
                logging.error("Invalid model state structure")
                return None
                
            return state_data
            
        except Exception as e:
            logging.error(f"Error loading model state: {str(e)}", exc_info=True)
            return None
            
    def save_performance_metrics(self, metrics):
        """Save performance metrics with validation"""
        try:
            date = datetime.now().strftime('%Y%m%d')
            filename = f"performance_metrics_{date}.json"
            filepath = os.path.join(self.data_paths['performance_data'], filename)
            
            # Validate metrics
            if not isinstance(metrics, dict):
                logging.error("Invalid metrics format: must be a dictionary")
                return
                
            # Load existing metrics if any
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    existing_metrics = json.load(f)
                metrics.update(existing_metrics)
                
            with open(filepath, 'w') as f:
                json.dump(metrics, f, indent=4)
                
            logging.info(f"Successfully saved performance metrics: {filename}")
            
        except Exception as e:
            logging.error(f"Error saving performance metrics: {str(e)}", exc_info=True)
            
    def get_latest_performance_metrics(self):
        """Get latest performance metrics with validation"""
        try:
            pattern = "performance_metrics_*.json"
            files = glob.glob(os.path.join(self.data_paths['performance_data'], pattern))
            
            if not files:
                return {}
                
            latest_file = max(files, key=os.path.getctime)
            
            with open(latest_file, 'r') as f:
                metrics = json.load(f)
                
            return metrics
            
        except Exception as e:
            logging.error(f"Error loading performance metrics: {str(e)}", exc_info=True)
            return {}