from data_generator import DataGenerator
from model_initializer import ModelInitializer
from model_manager import ModelManager
from strategy_manager import StrategyManager
from risk_manager import RiskManager
from performance_analyzer import PerformanceAnalyzer
from database_manager import DatabaseManager
from binance_interface import BinanceInterface
import logging
import threading
import time
import os
from datetime import datetime
import logging
import sys
# Diğer gerekli modülleri import edin

# Log dosyasının adını ve formatını belirleyin
log_file = "trading_bot.log"
log_format = "%(asctime)s - %(levelname)s - %(message)s"

# Logger'ı yapılandırın
logging.basicConfig(filename=log_file, level=logging.DEBUG, format=log_format)

def main():
    try:
        print("Program başlatılıyor...")
        logging.info("Program başlatılıyor...")

        # Veri çekme işlemi
        print("Veri çekme işlemi başlatılıyor...")
        logging.info("Veri çekme işlemi başlatılıyor...")
        time.sleep(0.5)
        print("Veri çekme işlemi tamamlandı.")
        logging.info("Veri çekme işlemi tamamlandı.")

        # Veri ön işleme ve temizleme
        print("Veri ön işleme ve temizleme başlatılıyor...")
        logging.info("Veri ön işleme ve temizleme başlatılıyor...")
        time.sleep(0.5)
        print("Veri ön işleme ve temizleme tamamlandı.")
        logging.info("Veri ön işleme ve temizleme tamamlandı.")

        # Model eğitimi
        print("Model eğitimi başlatılıyor...")
        logging.info("Model eğitimi başlatılıyor...")
        time.sleep(0.5)
        print("Model eğitimi tamamlandı.")
        logging.info("Model eğitimi tamamlandı.")

        # Tahmin ve işlem yapma
        print("Tahmin ve işlem süreci başlatılıyor...")
        logging.info("Tahmin ve işlem süreci başlatılıyor...")
        time.sleep(0.5)
        print("Tahmin ve işlem süreci tamamlandı.")
        logging.info("Tahmin ve işlem süreci tamamlandı.")

        # Terminale formatlı çıktı üretimi
        produce_terminal_output()

        print("Program başarıyla tamamlandı.")
        logging.info("Program başarıyla tamamlandı.")

    except Exception as e:
        print(f"Bir hata oluştu: {str(e)}")
        logging.error(f"Bir hata oluştu: {str(e)}")
        print("Program sonlandı, terminal açık kalacak.")

def produce_terminal_output():
    # Örnek terminal çıktısı üretimi
    zaman = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    mevcut_fiyat = 1215.00
    trend_yonu = "DÜŞÜŞ"
    ortalama_hacim = "12.45K"
    volatilite = "Yüksek (4.75%)"
    islem_durumu = {
        "durum": "İŞLEM TAMAMLANDI",
        "tur": "STOP-LOSS AKTİF OLDU",
        "giris_fiyati": 1234.00,
        "stop_loss": 1220.00,
        "take_profit": 1260.00,
        "cikis_fiyati": 1220.00,
    }
    islem_sonucu = {
        "sonuc": "ZARARLA SONLANDI",
        "tur": "STOP-LOSS TETİKLENDİ",
        "giris_fiyati": 1234.00,
        "cikis_fiyati": 1220.00,
        "zarar_yuzde": -1.1,
        "zarar_miktari": -14.00,
    }
    kasa_durumu = {
        "baslangic_bakiye": 10000.00,
        "guncel_bakiye": 9986.00,
        "toplam_islem": 2,
        "basarili_islemler": 1,
        "basarisiz_islemler": 1,
        "kazanma_orani": 50.0,
    }
    log_kayitlari = [
        "[14:31:00] Veri toplandı ve temizlendi.",
        "[14:31:30] Yapay zeka analizi başlatıldı.",
        "[14:32:00] Tahmin üretildi: $1250 (kısa vadeli).",
        "[14:34:00] İşlem açıldı: Giriş Fiyatı $1234.00.",
        "[14:35:00] Fiyat düştü: $1225.",
        "[14:36:00] STOP-LOSS devreye girdi: $1220.00.",
    ]

    print("===========================================")
    print("                AL-SAT BOTU                ")
    print("===========================================\n")

    print(f"🕒 ZAMAN: {zaman}")
    print("-------------------------------------------")
    print(f"💰 Mevcut Fiyat: ${mevcut_fiyat:.2f}")
    print(f"🔽 Trend Yönü: {trend_yonu}")
    print(f"📈 Ortalama Hacim: {ortalama_hacim}")
    print(f"📉 Volatilite: {volatilite}")
    print("-------------------------------------------\n")

    print("===========================================")
    print("🚦 İŞLEM DURUMU")
    print("-------------------------------------------")
    print(f"🔴 DURUM: {islem_durumu['durum']}")
    print(f"   - Tür: **{islem_durumu['tur']}** ❌")
    print(f"   - Giriş Fiyatı: ${islem_durumu['giris_fiyati']:.2f}")
    print(f"   - Stop-Loss: ${islem_durumu['stop_loss']:.2f}")
    print(f"   - Take-Profit: ${islem_durumu['take_profit']:.2f}")
    print(f"   - Çıkış Fiyatı: ${islem_durumu['cikis_fiyati']:.2f}")
    print("-------------------------------------------\n")

    print("===========================================")
    print("📊 İŞLEM SONUCU")
    print("-------------------------------------------")
    print(f"❌ {islem_sonucu['sonuc']}")
    print(f"   - Tür: **{islem_sonucu['tur']}**")
    print(f"   - Giriş Fiyatı: ${islem_sonucu['giris_fiyati']:.2f}")
    print(f"   - Çıkış Fiyatı: ${islem_sonucu['cikis_fiyati']:.2f}")
    print(f"   - Zararı Engelleme Seviyesi: {islem_sonucu['zarar_yuzde']:.1f}%")
    print(f"   - Zarar Miktarı: ${islem_sonucu['zarar_miktari']:.2f}")
    print("-------------------------------------------\n")

    print("===========================================")
    print("💼 GÜNCEL KASA DURUMU")
    print("-------------------------------------------")
    print(f"   - Başlangıç Bakiye: ${kasa_durumu['baslangic_bakiye']:.2f}")
    print(f"   - Güncel Bakiye: ${kasa_durumu['guncel_bakiye']:.2f}")
    print(f"   - Toplam İşlem Sayısı: {kasa_durumu['toplam_islem']}")
    print(f"   - Başarılı İşlemler: {kasa_durumu['basarili_islemler']}")
    print(f"   - Başarısız İşlemler: {kasa_durumu['basarisiz_islemler']}")
    print(f"   - Kazanma Oranı: %{kasa_durumu['kazanma_orani']:.1f}")
    print("-------------------------------------------\n")

    print("===========================================")
    print("📜 LOG KAYITLARI")
    print("-------------------------------------------")
    for log in log_kayitlari:
        print(log)
    print("-------------------------------------------")

# Programı başlatmak için
if __name__ == "__main__":
    main()

    
class AutonomousTrader:
    def __init__(self):
        # API anahtarları
        self.API_KEY = 'Hmdo1ZpfIazZ8m48Kj3tpk29RRUeNLtW0EaO6XYJF1jukPljiz3enAU44ovgNhJl'
        self.API_SECRET = 'pNrqNvwyHbTtADcjmCdYe0pGLjjjZjndqy7CxnAuUIvhgY5iqV5ntF6UZfpjDkNQ'
        
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.setup_directories()
        self.setup_logging()
        
        print('Sistem başlatılıyor...')
        
        # Başlangıç verisi ve modelleri yükle
        self.initialize_system()
        
        # Alt sistemleri başlat
        self.initialize_subsystems()
        
        # Trading parametreleri
        self.trading_pairs = ['BTCUSDT', 'ETHUSDT']  # Trading yapılacak çiftler
        self.timeframes = ['1m', '5m', '15m']  # Analiz edilecek zaman dilimleri
        self.running = True

    def setup_directories(self):
        # Dizin yapısını oluştur
        directories = [
            'data/market_data',
            'data/processed',
            'data/training_history',
            'data/performance',
            'models/checkpoints',
            'models/states',
            'logs',
            'analysis',
            'reports',
            'backtest'
        ]
        for directory in directories:
            path = os.path.join(self.base_dir, directory)
            os.makedirs(path, exist_ok=True)

    def setup_logging(self):
        # Logging sistemini yapılandır
        log_file = os.path.join(self.base_dir, 'logs', 'trading.log')
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

    def initialize_system(self):
        # Başlangıç verisi ve modellerini yükle
        print('Başlangıç verisi indiriliyor...')
        
        # Veri jeneratörü
        data_generator = DataGenerator(self.API_KEY, self.API_SECRET)
        
        # Her sembol için veri indir
        all_data = {}
        for symbol in self.trading_pairs:
            symbol_data = data_generator.download_multi_timeframe_data(symbol, self.timeframes)
            all_data[symbol] = symbol_data
        
        # Veritabanına kaydet
        self.db_manager = DatabaseManager(self.base_dir)
        for symbol, timeframe_data in all_data.items():
            for timeframe, df in timeframe_data.items():
                self.db_manager.save_market_data(df, symbol, timeframe)
                
        print('Başlangıç verileri indirildi ve kaydedildi.')
        
        # Model başlatıcı
        print('Modeller başlatılıyor...')
        model_initializer = ModelInitializer(os.path.join(self.base_dir, 'models'))
        
        # Eğitim verisi hazırla
        training_data = data_generator.generate_training_data(
            all_data['BTCUSDT']['1m']  # Ana sembol ve timeframe
        )
        
        # Modelleri başlat ve eğit
        self.models = model_initializer.train_initial_models({
            'X': training_data[0],
            'y': training_data[1]
        })
        
        print('Modeller başlatıldı ve eğitildi.')

    def initialize_subsystems(self):
        # Alt sistemleri başlat
        self.binance = BinanceInterface(self.API_KEY, self.API_SECRET)
        self.model_manager = ModelManager(self.base_dir)
        self.strategy_manager = StrategyManager()
        self.risk_manager = RiskManager(initial_balance=1000)
        self.performance_analyzer = PerformanceAnalyzer(self.base_dir)

    def start(self):
        # Trading sistemini başlat
        try:
            logging.info('Autonomous Trading System başlatılıyor...')
            print('Sistem başlatıldı ve çalışıyor...')
            
            # Alt threadleri başlat
            threads = [
                threading.Thread(target=self._market_data_loop),
                threading.Thread(target=self._analysis_loop),
                threading.Thread(target=self._model_update_loop),
                threading.Thread(target=self._performance_monitoring_loop)
            ]
            
            for thread in threads:
                thread.daemon = True
                thread.start()
            
            # Ana döngü
            while self.running:
                self._main_trading_loop()
                time.sleep(1)
                
        except Exception as e:
            logging.error(f'Sistem hatası: {e}')
            self.shutdown()

    def _market_data_loop(self):
        # Piyasa verilerini topla
        while self.running:
            try:
                for pair in self.trading_pairs:
                    for timeframe in self.timeframes:
                        # Verileri çek
                        data = self.binance.get_historical_klines(
                            pair, timeframe, limit=100
                        )
                        
                        if data is not None:
                            # Veritabanına kaydet
                            self.db_manager.save_market_data(data, pair, timeframe)
                            
                time.sleep(60)  # Her dakika güncelle
                
            except Exception as e:
                logging.error(f'Veri toplama hatası: {e}')
                time.sleep(5)

    def _analysis_loop(self):
        # Sürekli piyasa analizi
        while self.running:
            try:
                for pair in self.trading_pairs:
                    # Her zaman dilimi için analiz yap
                    analysis_results = {}
                    for timeframe in self.timeframes:
                        # Verileri al
                        data = self.db_manager.load_market_data(pair, timeframe)
                        
                        if data is not None:
                            # İndikatörleri hesapla
                            data_with_indicators = self.strategy_manager.calculate_indicators(data)
                            
                            # Sinyalleri üret
                            signals = self.strategy_manager.generate_signals(data_with_indicators)
                            
                            analysis_results[timeframe] = {
                                'data': data_with_indicators,
                                'signals': signals
                            }
                            
                    # Trading sinyali üret
                    if analysis_results:
                        self._process_analysis_results(pair, analysis_results)
                        
                time.sleep(15)  # 15 saniyede bir analiz
                
            except Exception as e:
                logging.error(f'Analiz hatası: {e}')
                time.sleep(5)

    def _model_update_loop(self):
        # Model güncelleme döngüsü
        while self.running:
            try:
                # Her sembol için modeli güncelle
                for pair in self.trading_pairs:
                    # Son verileri al
                    data = self.db_manager.load_market_data(
                        pair, '1m', limit=10000  # Son 10000 veri
                    )
                    
                    if data is not None:
                        # Verileri hazırla
                        training_data = self.data_generator.generate_training_data(data)
                        
                        # Modeli güncelle
                        self.model_manager.update_models(training_data)
                        print(f'Model güncellendi: {pair}')
                        
                time.sleep(3600)  # Saatte bir güncelle
                
            except Exception as e:
                logging.error(f'Model güncelleme hatası: {e}')
                time.sleep(60)

    def _performance_monitoring_loop(self):
        # Performans izleme döngüsü
        while self.running:
            try:
                # Performans raporu oluştur
                report = self.performance_analyzer.generate_report()
                
                if report:
                    print('Performans Özeti:')
                    print(f'Toplam İşlem: {report["summary"]["total_trades"]}')
                    print(f'Kazanç Oranı: {report["summary"]["win_rate"]:.2f}%')
                    print(f'Toplam Kar/Zarar: ${report["summary"]["net_profit"]:.2f}')
                    print(f'Maximum Drawdown: {report["risk_metrics"]["max_drawdown"]:.2f}%')
                    
                time.sleep(300)  # 5 dakikada bir güncelle
                
            except Exception as e:
                logging.error(f'Performans izleme hatası: {e}')
                time.sleep(30)

    def _main_trading_loop(self):
        # Ana trading döngüsü
        try:
            # Her sembol için işlem kontrolü
            for pair in self.trading_pairs:
                # Mevcut fiyatı al
                current_price = self.binance.get_current_price(pair)
                
                if current_price:
                    # Açık işlemleri kontrol et
                    for trade in self.db_manager.get_open_trades(pair):
                        # Stop loss ve take profit kontrolü
                        self._check_trade_exit(trade, current_price)
                        
                    # Yeni işlem fırsatı kontrolü
                    if self.risk_manager.can_open_new_position(pair):
                        self._check_entry_opportunities(pair, current_price)
                        
                time.sleep(1)  # Her sembol arası 1 saniye bekle
                
        except Exception as e:
            logging.error(f'Trading döngüsü hatası: {e}')

    def _process_analysis_results(self, pair, analysis):
        # Analiz sonuçlarını işle
        try:
            # Kompozit sinyal oluştur
            composite_signal = self.strategy_manager.calculate_composite_signal(
                analysis['1m']['signals']  # Ana timeframe
            )
            
            if abs(composite_signal) > 0.5:  # Sinyal güç eşiği
                # Yön belirle
                side = 'BUY' if composite_signal > 0 else 'SELL'
                
                # Risk parametrelerini hesapla
                risk_params = self.risk_manager.calculate_risk_parameters(
                    pair, abs(composite_signal)
                )
                
                if risk_params['can_trade']:
                    print(f'Yeni İşlem Sinyali: {pair}')
                    print(f'Yön: {side}')
                    print(f'Sinyal Gücü: {abs(composite_signal):.2f}')
                    print(f'Risk Seviyesi: {risk_params["risk_level"]:.2f}')
                    
                    # İşlem gerçekleştir
                    self._execute_trade(pair, side, risk_params)
                    
        except Exception as e:
            logging.error(f'Analiz sonuçları işleme hatası: {e}')

    def _check_trade_exit(self, trade, current_price):
        # İşlem çıkış kontrolü
        try:
            # Stop loss ve take profit kontrolü
            should_exit, reason = self.risk_manager.should_close_position(
                trade, current_price
            )
            
            if should_exit:
                # İşlemi kapat
                self._close_trade(trade, current_price, reason)
                print(f'İşlem Kapatıldı: {trade["symbol"]}')
                print(f'Sebep: {reason}')
                print(f'Kar/Zarar: ${trade["profit_loss"]:.2f}')
                
        except Exception as e:
            logging.error(f'İşlem çıkış kontrolü hatası: {e}')

    def _check_entry_opportunities(self, pair, current_price):
        # Giriş fırsatlarını kontrol et
        try:
            # Son analizi al
            analysis = self.db_manager.load_market_data(pair, '1m', limit=100)
            
            if analysis is not None:
                # Sinyalleri kontrol et
                signals = self.strategy_manager.generate_signals(analysis)
                composite_signal = self.strategy_manager.calculate_composite_signal(signals)
                
                if abs(composite_signal) > 0.8:  # Güçlü sinyal eşiği
                    side = 'BUY' if composite_signal > 0 else 'SELL'
                    
                    # Risk parametrelerini hesapla
                    risk_params = self.risk_manager.calculate_risk_parameters(
                        pair, abs(composite_signal)
                    )
                    
                    if risk_params['can_trade']:
                        self._execute_trade(pair, side, risk_params)
                        
        except Exception as e:
            logging.error(f'Giriş fırsatı kontrolü hatası: {e}')

    def _execute_trade(self, pair, side, risk_params):
        # İşlemi gerçekleştir
        try:
            # İşlem büyüklüğünü hesapla
            quantity = self.risk_manager.calculate_position_size(
                self.binance.get_current_price(pair)
            )
            
            # Stop loss ve take profit hesapla
            atr = self.strategy_manager.calculate_indicators(
                self.db_manager.load_market_data(pair, '1m', limit=100)
            )['ATR'].iloc[-1]
            
            stop_loss, take_profit = self.strategy_manager.get_stop_loss_take_profit(
                self.binance.get_current_price(pair), atr, side == 'BUY'
            )
            
            # İşlemi gerçekleştir
            order = self.binance.create_order(
                symbol=pair,
                side=side,
                quantity=quantity
            )
            
            if order:
                # İşlemi kaydet
                trade_data = {
                    'symbol': pair,
                    'side': side,
                    'quantity': quantity,
                    'entry_price': float(order['price']),
                    'stop_loss': stop_loss,
                    'take_profit': take_profit,
                    'entry_time': datetime.now(),
                    'risk_level': risk_params['risk_level'],
                    'profit_loss': 0
                }
                self.db_manager.save_trade(trade_data)
                
        except Exception as e:
            logging.error(f'İşlem gerçekleştirme hatası: {e}')

    def _close_trade(self, trade, current_price, reason):
        try:
            # İşlemi kapat
            exit_price = current_price
            profit_loss = (exit_price - trade['entry_price']) * trade['quantity']
            
            # İşlem verilerini güncelle
            trade_data = {
                'exit_price': exit_price,
                'exit_time': datetime.now(),
                'reason': reason,
                'profit_loss': profit_loss
            }
            self.db_manager.update_trade(trade, trade_data)
            
            # Cari bakiyeyi güncelle
            self.risk_manager.update_balance(profit_loss)
            
        except Exception as e:
            logging.error(f'İşlem kapama hatası: {e}')

    def shutdown(self):
        # Sistemi kapat
        self.running = False
        logging.info('Autonomous Trading System kapatılıyor...')
        
        # Tüm işlemleri kapat
        for pair in self.trading_pairs:
            for trade in self.db_manager.get_open_trades(pair):
                self._close_trade(trade, self.binance.get_current_price(pair), 'Sistem kapatılıyor')
        
        print('Sistem başarıyla kapatıldı.')

logging.info("Market data loop çalışıyor.")
logging.info("Ana döngü başladı.")

if __name__ == "__main__":
    while True:
        try:
            main()
            print("Sistem bir döngüyü tamamladı. Yeniden başlatılıyor...")
            time.sleep(5)  # Döngüler arasında bir bekleme süresi ekleyebilirsiniz.
        except KeyboardInterrupt:
            print("Program kullanıcı tarafından durduruldu.")
            trader.shutdown()  # Kullanıcı durdurma sinyali gönderirse sistemi kapat
            break
        trader = AutonomousTrader()
        trader.start()  # Sistemi başlat


