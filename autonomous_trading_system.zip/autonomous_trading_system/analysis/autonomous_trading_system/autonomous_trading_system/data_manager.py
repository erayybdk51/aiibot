import pandas as pd
import numpy as np
import os
import pickle
from datetime import datetime, timedelta
import glob
import shutil
import re
import json
import logging
from pathlib import Path

class DataManager:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.data_paths = self._setup_data_paths()
        
    def _setup_data_paths(self):
        """Veri dizin yapısını oluştur"""
        paths = {
            'raw_market_data': os.path.join(self.base_dir, 'data', 'market_data'),
            'processed_data': os.path.join(self.base_dir, 'data', 'processed'),
            'training_history': os.path.join(self.base_dir, 'data', 'training_history'),
            'performance_data': os.path.join(self.base_dir, 'data', 'performance'),
            'models': os.path.join(self.base_dir, 'models')
        }
        
        # Dizinleri oluştur
        for path in paths.values():
            os.makedirs(path, exist_ok=True)
            
        return paths
        
    def save_market_data(self, df, symbol, timeframe):
        """Market verisini kaydet"""
        if df is None or df.empty:
            return
            
        date = datetime.now().strftime('%Y%m%d')
        filename = f"{symbol}_{timeframe}_{date}.parquet"
        filepath = os.path.join(self.data_paths['raw_market_data'], filename)
        
        try:
            # Mevcut veri varsa birleştir
            if os.path.exists(filepath):
                existing_df = pd.read_parquet(filepath)
                df = pd.concat([existing_df, df])
                df = df.drop_duplicates(subset=['timestamp'])
                
            df.to_parquet(filepath, engine='pyarrow', compression='snappy')
            logging.info(f"Market verisi kaydedildi: {filename}")
            
        except Exception as e:
            logging.error(f"Veri kaydetme hatası: {e}")
            
    def load_historical_data(self, symbol, timeframe, days=30):
        """Geçmiş verileri yükle"""
        try:
            pattern = f"{symbol}_{timeframe}_*.parquet"
            files = glob.glob(os.path.join(self.data_paths['raw_market_data'], pattern))
            
            if not files:
                return pd.DataFrame()
                
            dfs = []
            start_date = datetime.now() - timedelta(days=days)
            
            for file in files:
                file_date = datetime.strptime(file.split('_')[-1].replace('.parquet', ''), '%Y%m%d')
                if file_date >= start_date:
                    df = pd.read_parquet(file)
                    dfs.append(df)
                    
            if not dfs:
                return pd.DataFrame()
                
            combined_df = pd.concat(dfs, ignore_index=True)
            combined_df = combined_df.sort_values('timestamp').drop_duplicates(subset=['timestamp'])
            
            return combined_df
            
        except Exception as e:
            logging.error(f"Veri yükleme hatası: {e}")
            return pd.DataFrame()
            
    def get_data_for_training(self, symbol, timeframe, days=30):
        """Model eğitimi için veri hazırla"""
        df = self.load_historical_data(symbol, timeframe, days)
        if df.empty:
            return None
            
        # Temel özellikleri hazırla
        features = [
            'open', 'high', 'low', 'close', 'volume'
        ]
        
        # Veriyi normalize et
        scaler = MinMaxScaler()
        df_scaled = pd.DataFrame(
            scaler.fit_transform(df[features]),
            columns=features,
            index=df.index
        )
        
        return {
            'raw_data': df,
            'processed_data': df_scaled,
            'scaler': scaler
        }
        
    def save_model_state(self, model_name, model_state, metrics):
        """Model durumunu kaydet"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        filename = f"{model_name}_state_{timestamp}.pkl"
        filepath = os.path.join(self.data_paths['models'], filename)
        
        state_data = {
            'timestamp': timestamp,
            'state': model_state,
            'metrics': metrics
        }
        
        with open(filepath, 'wb') as f:
            pickle.dump(state_data, f)
            
        logging.info(f"Model durumu kaydedildi: {filename}")
        
    def load_latest_model_state(self, model_name):
        """En son model durumunu yükle"""
        pattern = f"{model_name}_state_*.pkl"
        files = glob.glob(os.path.join(self.data_paths['models'], pattern))
        
        if not files:
            return None
            
        latest_file = max(files, key=os.path.getctime)
        
        try:
            with open(latest_file, 'rb') as f:
                state_data = pickle.load(f)
            return state_data
            
        except Exception as e:
            logging.error(f"Model durumu yükleme hatası: {e}")
            return None
            
    def cleanup_old_files(self, days_to_keep=30):
        """Eski dosyaları arşivle"""
        cutoff_date = datetime.now() - timedelta(days=days_to_keep)
        
        for data_type, path in self.data_paths.items():
            # Arşiv klasörü oluştur
            archive_path = os.path.join(path, 'archive')
            os.makedirs(archive_path, exist_ok=True)
            
            # Dosyaları kontrol et
            for file in os.listdir(path):
                if file == 'archive':
                    continue
                    
                file_path = os.path.join(path, file)
                try:
                    # Dosya tarihini bul
                    date_str = re.search(r'\d{8}', file)
                    if date_str:
                        file_date = datetime.strptime(date_str.group(), '%Y%m%d')
                        if file_date < cutoff_date:
                            # Arşive taşı
                            shutil.move(file_path, os.path.join(archive_path, file))
                            
                except Exception as e:
                    logging.error(f"Dosya arşivleme hatası: {e}")
                    
    def save_performance_metrics(self, metrics):
        """Performans metriklerini kaydet"""
        date = datetime.now().strftime('%Y%m%d')
        filename = f"performance_metrics_{date}.json"
        filepath = os.path.join(self.data_paths['performance_data'], filename)
        
        try:
            # Mevcut metrikleri yükle ve güncelle
            if os.path.exists(filepath):
                with open(filepath, 'r') as f:
                    existing_metrics = json.load(f)
                metrics.update(existing_metrics)
                
            with open(filepath, 'w') as f:
                json.dump(metrics, f, indent=4)
                
            logging.info(f"Performans metrikleri kaydedildi: {filename}")
            
        except Exception as e:
            logging.error(f"Performans metriklerini kaydetme hatası: {e}")
            
    def get_latest_performance_metrics(self):
        """En son performans metriklerini al"""
        pattern = "performance_metrics_*.json"
        files = glob.glob(os.path.join(self.data_paths['performance_data'], pattern))
        
        if not files:
            return {}
            
        latest_file = max(files, key=os.path.getctime)
        
        try:
            with open(latest_file, 'r') as f:
                metrics = json.load(f)
            return metrics
            
        except Exception as e:
            logging.error(f"Performans metrikleri yükleme hatası: {e}")
            return {}