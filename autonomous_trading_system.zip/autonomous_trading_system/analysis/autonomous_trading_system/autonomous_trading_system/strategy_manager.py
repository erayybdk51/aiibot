import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import ta
import logging

class StrategyManager:
    def __init__(self):
        self.indicators = {
            'RSI': {'timeperiod': 14},
            'MACD': {'fast': 12, 'slow': 26, 'signal': 9},
            'BB': {'timeperiod': 20, 'stddev': 2},
            'EMA': {'short': 9, 'medium': 21, 'long': 50},
            'ATR': {'timeperiod': 14}
        }
        
        # İndikatör ağırlıkları
        self.weights = {
            'trend': 0.4,
            'momentum': 0.3,
            'volatility': 0.2,
            'volume': 0.1
        }
        
        # Stop loss ve take profit seviyeleri
        self.risk_reward_ratio = 2.0  # Risk/Ödül oranı
        
    def calculate_indicators(self, df):
        """Teknik indikatörleri hesapla"""
        df = df.copy()
        
        try:
            # Trend İndikatörleri
            df['EMA_short'] = ta.trend.ema_indicator(df['close'], 
                                                   self.indicators['EMA']['short'])
            df['EMA_medium'] = ta.trend.ema_indicator(df['close'], 
                                                    self.indicators['EMA']['medium'])
            df['EMA_long'] = ta.trend.ema_indicator(df['close'], 
                                                  self.indicators['EMA']['long'])
            
            # MACD
            df['MACD'] = ta.trend.macd_diff(df['close'],
                                          self.indicators['MACD']['fast'],
                                          self.indicators['MACD']['slow'],
                                          self.indicators['MACD']['signal'])
            
            # Momentum İndikatörleri
            df['RSI'] = ta.momentum.rsi(df['close'], 
                                      self.indicators['RSI']['timeperiod'])
            
            df['Stoch_K'] = ta.momentum.stoch(df['high'], df['low'], df['close'])
            df['Stoch_D'] = ta.momentum.stoch_signal(df['high'], df['low'], df['close'])
            
            # Volatilite İndikatörleri
            bb = ta.volatility.BollingerBands(df['close'],
                                            self.indicators['BB']['timeperiod'],
                                            self.indicators['BB']['stddev'])
            df['BB_upper'] = bb.bollinger_hband()
            df['BB_middle'] = bb.bollinger_mavg()
            df['BB_lower'] = bb.bollinger_lband()
            
            df['ATR'] = ta.volatility.average_true_range(df['high'], df['low'], df['close'],
                                                       self.indicators['ATR']['timeperiod'])
            
            # Hacim İndikatörleri
            df['OBV'] = ta.volume.on_balance_volume(df['close'], df['volume'])
            df['ADI'] = ta.volume.acc_dist_index(df['high'], df['low'], 
                                               df['close'], df['volume'])
            
            # Özel İndikatörler
            df['Volatility'] = df['close'].pct_change().rolling(window=20).std()
            df['Volume_MA'] = df['volume'].rolling(window=20).mean()
            df['Price_ROC'] = ta.momentum.roc(df['close'], 10)
            
            return df
            
        except Exception as e:
            logging.error(f"İndikatör hesaplama hatası: {e}")
            return None
            
    def generate_signals(self, df):
        """Trading sinyalleri oluştur"""
        if df is None or df.empty:
            return None
            
        signals = pd.DataFrame(index=df.index)
        
        try:
            # Trend Sinyalleri
            signals['trend_signal'] = 0
            signals.loc[(df['EMA_short'] > df['EMA_medium']) & 
                       (df['EMA_medium'] > df['EMA_long']), 'trend_signal'] = 1
            signals.loc[(df['EMA_short'] < df['EMA_medium']) & 
                       (df['EMA_medium'] < df['EMA_long']), 'trend_signal'] = -1
            
            # Momentum Sinyalleri
            signals['momentum_signal'] = 0
            signals.loc[(df['RSI'] < 30) & (df['MACD'] > 0), 'momentum_signal'] = 1
            signals.loc[(df['RSI'] > 70) & (df['MACD'] < 0), 'momentum_signal'] = -1
            
            # Volatilite Sinyalleri
            signals['volatility_signal'] = 0
            signals.loc[df['close'] < df['BB_lower'], 'volatility_signal'] = 1
            signals.loc[df['close'] > df['BB_upper'], 'volatility_signal'] = -1
            
            # Hacim Sinyalleri
            signals['volume_signal'] = 0
            signals.loc[(df['volume'] > df['Volume_MA'] * 1.5) & 
                       (df['Price_ROC'] > 0), 'volume_signal'] = 1
            signals.loc[(df['volume'] > df['Volume_MA'] * 1.5) & 
                       (df['Price_ROC'] < 0), 'volume_signal'] = -1
            
            return signals
            
        except Exception as e:
            logging.error(f"Sinyal oluşturma hatası: {e}")
            return None
            
    def calculate_composite_signal(self, signals):
        """Ağırlıklı kompozit sinyal hesapla"""
        if signals is None or signals.empty:
            return 0
            
        try:
            latest = signals.iloc[-1]
            
            composite = (
                self.weights['trend'] * latest['trend_signal'] +
                self.weights['momentum'] * latest['momentum_signal'] +
                self.weights['volatility'] * latest['volatility_signal'] +
                self.weights['volume'] * latest['volume_signal']
            )
            
            return composite
            
        except Exception as e:
            logging.error(f"Kompozit sinyal hesaplama hatası: {e}")
            return 0
            
    def get_stop_loss_take_profit(self, price, atr, is_long):
        """Stop loss ve take profit seviyelerini hesapla"""
        try:
            # ATR bazlı stop loss
            stop_distance = 2 * atr
            
            if is_long:
                stop_loss = price - stop_distance
                take_profit = price + (stop_distance * self.risk_reward_ratio)
            else:
                stop_loss = price + stop_distance
                take_profit = price - (stop_distance * self.risk_reward_ratio)
                
            return stop_loss, take_profit
            
        except Exception as e:
            logging.error(f"Stop loss/take profit hesaplama hatası: {e}")
            return None, None
            
    def optimize_parameters(self, historical_data, performance_metrics):
        """Strateji parametrelerini optimize et"""
        try:
            if performance_metrics['win_rate'] < 0.5:
                # Risk/ödül oranını artır
                self.risk_reward_ratio = min(3.0, self.risk_reward_ratio * 1.1)
                
                # İndikatör periodlarını ayarla
                self.indicators['RSI']['timeperiod'] = min(21, 
                    self.indicators['RSI']['timeperiod'] + 1)
                    
                # Bollinger bant genişliğini artır
                self.indicators['BB']['stddev'] = min(3.0, 
                    self.indicators['BB']['stddev'] + 0.1)
                    
            else:
                # Başarılı stratejide küçük optimizasyonlar
                if performance_metrics['profit_factor'] > 2.0:
                    self.risk_reward_ratio = max(1.5, self.risk_reward_ratio * 0.95)
                    
            # Ağırlıkları performansa göre optimize et
            self._optimize_weights(performance_metrics)
            
            logging.info("Strateji parametreleri optimize edildi")
            
        except Exception as e:
            logging.error(f"Parametre optimizasyon hatası: {e}")
            
    def _optimize_weights(self, metrics):
        """İndikatör ağırlıklarını optimize et"""
        try:
            # Her sinyalin başarı oranını hesapla
            signal_performance = {
                'trend': metrics.get('trend_accuracy', 0.5),
                'momentum': metrics.get('momentum_accuracy', 0.5),
                'volatility': metrics.get('volatility_accuracy', 0.5),
                'volume': metrics.get('volume_accuracy', 0.5)
            }
            
            # Toplam performansı hesapla
            total_performance = sum(signal_performance.values())
            
            if total_performance > 0:
                # Ağırlıkları normalize et
                for signal in self.weights:
                    self.weights[signal] = signal_performance[signal] / total_performance
                    
        except Exception as e:
            logging.error(f"Ağırlık optimizasyon hatası: {e}")
            
    def analyze_market_conditions(self, df):
        """Piyasa koşullarını analiz et"""
        try:
            latest = df.iloc[-1]
            
            conditions = {
                'trend': self._determine_trend(df),
                'volatility': self._analyze_volatility(df),
                'momentum': self._analyze_momentum(df),
                'volume': self._analyze_volume(df),
                'support_resistance': self._find_support_resistance(df)
            }
            
            return conditions
            
        except Exception as e:
            logging.error(f"Piyasa analizi hatası: {e}")
            return None
            
    def _determine_trend(self, df):
        """Trend durumunu belirle"""
        try:
            last_row = df.iloc[-1]
            
            if last_row['EMA_short'] > last_row['EMA_medium'] > last_row['EMA_long']:
                return 'UPTREND'
            elif last_row['EMA_short'] < last_row['EMA_medium'] < last_row['EMA_long']:
                return 'DOWNTREND'
            else:
                return 'SIDEWAYS'
                
        except Exception as e:
            logging.error(f"Trend belirleme hatası: {e}")
            return 'UNKNOWN'
            
    def _analyze_volatility(self, df):
        """Volatilite analizi"""
        try:
            current_volatility = df['Volatility'].iloc[-1]
            avg_volatility = df['Volatility'].mean()
            
            if current_volatility > avg_volatility * 1.5:
                return 'HIGH'
            elif current_volatility < avg_volatility * 0.5:
                return 'LOW'
            else:
                return 'NORMAL'
                
        except Exception as e:
            logging.error(f"Volatilite analizi hatası: {e}")
            return 'UNKNOWN'
            
    def _analyze_momentum(self, df):
        """Momentum analizi"""
        try:
            last_row = df.iloc[-1]
            
            if last_row['RSI'] > 70 and last_row['MACD'] > 0:
                return 'STRONG_BULLISH'
            elif last_row['RSI'] < 30 and last_row['MACD'] < 0:
                return 'STRONG_BEARISH'
            elif last_row['RSI'] > 50 and last_row['MACD'] > 0:
                return 'BULLISH'
            elif last_row['RSI'] < 50 and last_row['MACD'] < 0:
                return 'BEARISH'
            else:
                return 'NEUTRAL'
                
        except Exception as e:
            logging.error(f"Momentum analizi hatası: {e}")
            return 'UNKNOWN'
            
    def _analyze_volume(self, df):
        """Hacim analizi"""
        try:
            last_row = df.iloc[-1]
            volume_sma = df['volume'].rolling(window=20).mean().iloc[-1]
            
            if last_row['volume'] > volume_sma * 2:
                return 'VERY_HIGH'
            elif last_row['volume'] > volume_sma * 1.5:
                return 'HIGH'
            elif last_row['volume'] < volume_sma * 0.5:
                return 'LOW'
            else:
                return 'NORMAL'
                
        except Exception as e:
            logging.error(f"Hacim analizi hatası: {e}")
            return 'UNKNOWN'
            
    def _find_support_resistance(self, df, window=20):
        """Destek ve direnç seviyeleri"""
        try:
            levels = []
            
            for i in range(window, len(df) - window):
                if self._is_support(df, i, window):
                    levels.append(('SUPPORT', df['low'].iloc[i]))
                elif self._is_resistance(df, i, window):
                    levels.append(('RESISTANCE', df['high'].iloc[i]))
                    
            # En yakın 3 seviyeyi döndür
            current_price = df['close'].iloc[-1]
            levels.sort(key=lambda x: abs(x[1] - current_price))
            
            return levels[:3]
            
        except Exception as e:
            logging.error(f"Destek/direnç belirleme hatası: {e}")
            return []
            
    def _is_support(self, df, idx, window):
        """Destek seviyesi kontrolü"""
        try:
            current_low = df['low'].iloc[idx]
            
            for i in range(idx - window, idx + window):
                if i != idx and df['low'].iloc[i] < current_low:
                    return False
            return True
            
        except Exception as e:
            logging.error(f"Destek kontrolü hatası: {e}")
            return False
            
    def _is_resistance(self, df, idx, window):
        """Direnç seviyesi kontrolü"""
        try:
            current_high = df['high'].iloc[idx]
            
            for i in range(idx - window, idx + window):
                if i != idx and df['high'].iloc[i] > current_high:
                    return False
            return True
            
        except Exception as e:
            logging.error(f"Direnç kontrolü hatası: {e}")
            return False