import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input
from tensorflow.keras.optimizers import Adam
import numpy as np
import os
import logging

class ModelInitializer:
    def __init__(self, models_dir):
        self.models_dir = models_dir
        os.makedirs(models_dir, exist_ok=True)
        
    def initialize_models(self):
        """Tüm modelleri başlat"""
        models = {
            'price_predictor': self._create_price_predictor(),
            'risk_analyzer': self._create_risk_analyzer(),
            'trend_classifier': self._create_trend_classifier()
        }
        
        self._save_models(models)
        return models
        
    def _create_price_predictor(self):
        """Fiyat tahmin modeli oluştur ve başlangıç eğitimi yap"""
        print("Fiyat tahmin modeli oluşturuluyor...")
        
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=(60, 5)),
            Dropout(0.2),
            LSTM(64, return_sequences=False),
            Dropout(0.2),
            Dense(32, activation='relu'),
            Dense(1)
        ])
        
        model.compile(optimizer=Adam(0.001), loss='mse')
        return model
        
    def _create_risk_analyzer(self):
        """Risk analiz modeli oluştur"""
        print("Risk analiz modeli oluşturuluyor...")
        
        model = Sequential([
            Dense(64, activation='relu', input_shape=(10,)),
            Dropout(0.2),
            Dense(32, activation='relu'),
            Dense(16, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(optimizer='adam', loss='binary_crossentropy',
                     metrics=['accuracy'])
        return model
        
    def _create_trend_classifier(self):
        """Trend sınıflandırma modeli oluştur"""
        print("Trend sınıflandırma modeli oluşturuluyor...")
        
        model = Sequential([
            Dense(32, activation='relu', input_shape=(15,)),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(3, activation='softmax')  # UP, DOWN, SIDEWAYS
        ])
        
        model.compile(optimizer='adam', loss='categorical_crossentropy',
                     metrics=['accuracy'])
        return model
        
    def _save_models(self, models):
        """Modelleri kaydet"""
        try:
            for name, model in models.items():
                model_path = os.path.join(self.models_dir, f"{name}.h5")
                model.save(model_path)
                print(f"{name} modeli kaydedildi: {model_path}")
                
        except Exception as e:
            print(f"Model kaydetme hatası: {e}")
            logging.error(f"Model kaydetme hatası: {e}")
            
    def train_initial_models(self, training_data):
        """Modelleri başlangıç verisiyle eğit"""
        try:
            models = self.initialize_models()
            
            if training_data is None:
                print("Eğitim verisi bulunamadı!")
                return models
                
            X_train, y_train = training_data['X'], training_data['y']
            
            # Fiyat tahmin modelini eğit
            print("Fiyat tahmin modeli eğitiliyor...")
            models['price_predictor'].fit(
                X_train, y_train,
                epochs=10,
                batch_size=32,
                verbose=1
            )
            
            # Risk ve trend modellerini eğit
            # Bu modeller için ek özellikler hazırlanmalı
            
            self._save_models(models)
            print("Başlangıç eğitimi tamamlandı.")
            
            return models
            
        except Exception as e:
            print(f"Model eğitim hatası: {e}")
            logging.error(f"Model eğitim hatası: {e}")
            return None