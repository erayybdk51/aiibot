import os
import sys
from datetime import datetime
import time
from collections import deque
import threading
import logging

class TerminalHandler:
    def __init__(self):
        self.status_messages = deque(maxlen=4)  # Son 4 durum mesajı
        self.start_time = datetime.now()
        self.system_status = "🟢 Aktif"
        self.api_status = "🟢 Aktif"
        self.server_load = 20
        self.data_delay = 110
        
    def clear_screen(self):
        """Terminal ekranını temizle"""
        os.system('cls' if os.name == 'nt' else 'clear')
        
    def add_status_message(self, message):
        """Yeni durum mesajı ekle"""
        timestamp = datetime.now().strftime("%H:%M:%S")
        self.status_messages.append(f"🕒 [{timestamp}] {message}")
        
    def format_duration(self, duration):
        """Süreyi formatla"""
        hours = duration.seconds // 3600
        minutes = (duration.seconds % 3600) // 60
        seconds = duration.seconds % 60
        return f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        
    def render_header(self):
        """Üst başlık bölümünü oluştur"""
        runtime = self.format_duration(datetime.now() - self.start_time)
        return f"""╔════════════════════════════════════════════════════════════════════════════════════════════╗
║                                🟢 GELİŞMİŞ TRADER TERMİNALİ 🟢                              ║
╟────────────────────────────────────────────────────────────────────────────────────────────╢
║ Durum: {self.system_status}            │ Çalışma Süresi: {runtime}                                      ║
║ API Bağlantısı: {self.api_status}    │ Sunucu Yükü: %{self.server_load} | Veri Gecikmesi: {self.data_delay}ms                     ║
╚════════════════════════════════════════════════════════════════════════════════════════════╝"""

    def render_status_section(self):
        """Durum bölümünü oluştur"""
        status_text = """╔═════════════════════════════════════════════════🔄 MEVCUT DURUM: YAPAY ZEKA NE YAPIYOR? 🔄═════════════════════════════════╗"""
        
        for message in self.status_messages:
            status_text += f"\n║ {message:<119} ║"
            
        # Boş satırları doldur
        empty_lines = 4 - len(self.status_messages)
        for _ in range(empty_lines):
            status_text += "\n║                                                                                                                        ║"
            
        status_text += "\n╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
        return status_text

    def render_signals(self, signals):
        """Sinyal tablosunu oluştur"""
        text = """╔═════════════════════════════════════════════════🔔 GERÇEK ZAMANLI SİNYALLER 🔔════════════════════════════════════════════╗
║ Pair        │ Zaman Dilimi │ Sinyal       │ Sinyal Gücü │ Önerilen Aksiyon │ ATR        │ RSI        │ MACD (Fark)       ║
╟─────────────┼──────────────┼──────────────┼─────────────┼──────────────────┼────────────┼────────────┼──────────────────╢"""
        
        for signal in signals:
            text += f"""
║ {signal['pair']:<10} │ {signal['timeframe']:<11} │ {signal['signal']:<11} │ {signal['strength']:>10} │ {signal['action']:<15} │ {signal['atr']:>9} │ {signal['rsi']:>9} │ {signal['macd']:>15} ║"""
            
        text += "\n╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
        return text

    def render_open_positions(self, positions):
        """Açık pozisyonlar tablosunu oluştur"""
        text = """╔═════════════════════════════════════════════════📉 GÜNCEL AÇIK İŞLEMLER 📉════════════════════════════════════════════════╗
║ İşlem ID   │ Çift     │ İşlem Türü │ Giriş Fiyatı │ Güncel Fiyat │ P/L ($)  │ P/L (%)  │ Stop Loss  │ Take Profit │ Süre ║
╟────────────┼──────────┼────────────┼──────────────┼──────────────┼──────────┼──────────┼────────────┼─────────────┼──────╢"""
        
        for pos in positions:
            text += f"""
║ {pos['id']:<9} │ {pos['pair']:<8} │ {pos['type']:<10} │ {pos['entry']:>11} │ {pos['current']:>11} │ {pos['pl_usd']:>8} │ {pos['pl_pct']:>7} │ {pos['sl']:>9} │ {pos['tp']:>10} │ {pos['duration']:<4} ║"""
            
        text += "\n╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"
        return text

    def render_performance(self, daily_perf, monthly_perf):
        """Performans bölümünü oluştur"""
        return f"""╔═════════════════════════════════════════════📅 GÜNLÜK VE AYLIK PERFORMANS 📅═════════════════════════════════════════════╗
║ 📊 **Günlük Performans Özeti:**                                                                                         ║
{self._format_daily_performance(daily_perf)}
║ ----------------------------------------------------------------------------------------------------                    ║
║ ✅ Toplam Kar: {daily_perf['total_profit']} ({daily_perf['total_profit_pct']}%)                                                               ║
║                                                                                                                        ║
║ 📊 **Aylık Performans Özeti:**                                                                                         ║
{self._format_monthly_performance(monthly_perf)}
║ ----------------------------------------------------------------------------------------------------                    ║
║ ✅ Aylık Toplam Kar: {monthly_perf['total_profit']}                                                                     ║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"""

    def render_controls(self):
        """Kontrol menüsünü oluştur"""
        return """╔═══════════════════════════════════════════════🔧 SİSTEM KONTROLLERİ (Bir Komut Giriniz) 🔧════════════════════════════════╗
║ [1] İşlemleri Durdur      │ [2] Açık İşlemleri Görüntüle    │ [3] Performans Raporu Oluştur                              ║
║ [4] Modelleri Güncelle    │ [5] Sistemi Kapat               │ [6] Stratejileri Backtest Et                              ║
║ [7] Risk Parametrelerini Görüntüle   │ [8] Gelişmiş Ayarlar │ [9] Yardım                                              ║
╚═══════════════════════════════════════════════════════════════════════════════════════════════════════════════════════════╝"""

    def _format_daily_performance(self, perf):
        """Günlük performans formatı"""
        text = ""
        for pair in perf['pairs']:
            text += f"║ | {pair['pair']:<10} | {pair['pl']:>9} | {pair['pl_pct']:>7} |                                                                   ║\n"
        return text

    def _format_monthly_performance(self, perf):
        """Aylık performans formatı"""
        text = ""
        for pair in perf['pairs']:
            text += f"║ | {pair['pair']:<10} | {pair['total_pl']:>15} | {pair['avg_daily']:>22} | {pair['trades']:>11} | {pair['win_rate']:>17} |                         ║\n"
        return text

    def update_display(self, data):
        """Tüm terminal görüntüsünü güncelle"""
        self.clear_screen()
        
        # Tüm bölümleri oluştur
        sections = [
            self.render_header(),
            self.render_status_section(),
            self.render_signals(data['signals']),
            self.render_open_positions(data['positions']),
            self.render_performance(data['daily_performance'], data['monthly_performance']),
            self.render_controls()
        ]
        
        # Ekrana yazdır
        print("\n".join(sections))
        sys.stdout.flush()