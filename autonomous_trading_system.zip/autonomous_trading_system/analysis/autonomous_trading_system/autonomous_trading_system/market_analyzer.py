# Market Analyzer devamı
            if analysis_results['market_state']['volume_profile'] == 'DECREASING':
                return False, "Düşük hacim"
            
        # Piyasa sağlığı kontrolü
        health = analysis_results['market_health']
        if health['overbought_oversold'] == 'OVERBOUGHT' and analysis_results['market_state']['trend'] == 'UP':
            return False, "Aşırı alım bölgesi"
        if health['overbought_oversold'] == 'OVERSOLD' and analysis_results['market_state']['trend'] == 'DOWN':
            return False, "Aşırı satım bölgesi"
            
        return True, "İşlem koşulları uygun"
        
    def calculate_entry_points(self, current_price, analysis_results):
        """Giriş noktalarını hesapla"""
        support_levels = self.current_market_state['support_levels']
        resistance_levels = self.current_market_state['resistance_levels']
        
        entry_points = {
            'long': [],
            'short': []
        }
        
        # Long giriş noktaları
        if analysis_results['market_state']['trend'] == 'UP':
            for support in support_levels:
                if support < current_price * 1.02:  # %2 tolerans
                    entry_points['long'].append(support)
                    
        # Short giriş noktaları
        elif analysis_results['market_state']['trend'] == 'DOWN':
            for resistance in resistance_levels:
                if resistance > current_price * 0.98:  # %2 tolerans
                    entry_points['short'].append(resistance)
                    
        return entry_points
        
    def identify_key_levels(self, df):
        """Önemli fiyat seviyelerini belirle"""
        pivot = self._calculate_pivot_points(df)
        fib_levels = self._calculate_fibonacci_levels(df)
        
        return {
            'pivot_points': pivot,
            'fibonacci_levels': fib_levels
        }
        
    def _calculate_pivot_points(self, df):
        """Pivot noktalarını hesapla"""
        last_day = df.iloc[-1]
        
        pivot = (last_day['high'] + last_day['low'] + last_day['close']) / 3
        r1 = 2 * pivot - last_day['low']
        r2 = pivot + (last_day['high'] - last_day['low'])
        s1 = 2 * pivot - last_day['high']
        s2 = pivot - (last_day['high'] - last_day['low'])
        
        return {
            'pivot': pivot,
            'r1': r1,
            'r2': r2,
            's1': s1,
            's2': s2
        }
        
    def _calculate_fibonacci_levels(self, df, period=20):
        """Fibonacci seviyelerini hesapla"""
        high = df['high'].rolling(window=period).max().iloc[-1]
        low = df['low'].rolling(window=period).min().iloc[-1]
        diff = high - low
        
        levels = {
            '0.236': low + diff * 0.236,
            '0.382': low + diff * 0.382,
            '0.5': low + diff * 0.5,
            '0.618': low + diff * 0.618,
            '0.786': low + diff * 0.786
        }
        
        return levels
        
    def detect_pattern(self, df):
        """Teknik analiz paternlerini tespit et"""
        patterns = {}
        
        # Mum formasyonları
        patterns['doji'] = talib.CDLDOJI(df['open'], df['high'], df['low'], df['close'])
        patterns['engulfing'] = talib.CDLENGULFING(df['open'], df['high'], df['low'], df['close'])
        patterns['hammer'] = talib.CDLHAMMER(df['open'], df['high'], df['low'], df['close'])
        patterns['shooting_star'] = talib.CDLSHOOTINGSTAR(df['open'], df['high'], df['low'], df['close'])
        
        # Pattern sonuçlarını analiz et
        active_patterns = {}
        for pattern_name, pattern_values in patterns.items():
            last_value = pattern_values.iloc[-1]
            if last_value != 0:
                active_patterns[pattern_name] = 'BULLISH' if last_value > 0 else 'BEARISH'
                
        return active_patterns

    def analyze_volume_profile(self, df, price_levels=10):
        """Hacim profili analizi"""
        price_range = df['high'].max() - df['low'].min()
        price_step = price_range / price_levels
        
        volume_profile = {}
        for i in range(price_levels):
            price_low = df['low'].min() + i * price_step
            price_high = price_low + price_step
            
            mask = (df['close'] >= price_low) & (df['close'] < price_high)
            volume = df.loc[mask, 'volume'].sum()
            
            volume_profile[f"Level_{i}"] = {
                'price_range': (price_low, price_high),
                'volume': volume
            }
            
        return volume_profile