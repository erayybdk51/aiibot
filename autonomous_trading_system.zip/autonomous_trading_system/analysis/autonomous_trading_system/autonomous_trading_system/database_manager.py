import sqlite3
import pandas as pd
import json
import os
import logging
from datetime import datetime

class DatabaseManager:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.db_path = os.path.join(base_dir, 'data', 'trading.db')
        os.makedirs(os.path.dirname(self.db_path), exist_ok=True)
        
        self.create_tables()
        
    def create_tables(self):
        """Veritabanı tablolarını oluştur"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # Market verileri tablosu
                conn.execute('''
                    CREATE TABLE IF NOT EXISTS market_data (
                        timestamp INTEGER,
                        symbol TEXT,
                        open REAL,
                        high REAL,
                        low REAL,
                        close REAL,
                        volume REAL,
                        quote_volume REAL,
                        trades INTEGER,
                        timeframe TEXT,
                        PRIMARY KEY (timestamp, symbol, timeframe)
                    )
                ''')
                
                # İşlemler tablosu
                conn.execute('''
                    CREATE TABLE IF NOT EXISTS trades (
                        trade_id INTEGER PRIMARY KEY AUTOINCREMENT,
                        symbol TEXT,
                        entry_time TIMESTAMP,
                        exit_time TIMESTAMP,
                        entry_price REAL,
                        exit_price REAL,
                        amount REAL,
                        side TEXT,
                        profit_loss REAL,
                        status TEXT,
                        strategy TEXT,
                        indicators TEXT,
                        stop_loss REAL,
                        take_profit REAL,
                        commission REAL
                    )
                ''')
                
                # Model durumları tablosu
                conn.execute('''
                    CREATE TABLE IF NOT EXISTS model_states (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        model_name TEXT,
                        timestamp TIMESTAMP,
                        state BLOB,
                        metrics TEXT
                    )
                ''')
                
                # Performans metrikleri tablosu
                conn.execute('''
                    CREATE TABLE IF NOT EXISTS performance_metrics (
                        timestamp TIMESTAMP PRIMARY KEY,
                        metrics TEXT
                    )
                ''')
                
                logging.info("Veritabanı tabloları oluşturuldu")
                
        except Exception as e:
            logging.error(f"Tablo oluşturma hatası: {e}")
            
    def save_market_data(self, df, symbol, timeframe):
        """Market verilerini kaydet"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                df['symbol'] = symbol
                df['timeframe'] = timeframe
                
                df.to_sql('market_data', conn, if_exists='append', index=False)
                logging.info(f"Market verileri kaydedildi: {symbol} {timeframe}")
                
        except sqlite3.IntegrityError:
            logging.warning(f"Tekrarlanan veriler atlandı: {symbol} {timeframe}")
        except Exception as e:
            logging.error(f"Market verisi kaydetme hatası: {e}")
            
    def load_market_data(self, symbol, timeframe, start_time=None, end_time=None):
        """Market verilerini yükle"""
        try:
            query = """
                SELECT * FROM market_data 
                WHERE symbol = ? AND timeframe = ?
            """
            params = [symbol, timeframe]
            
            if start_time:
                query += " AND timestamp >= ?"
                params.append(start_time)
            if end_time:
                query += " AND timestamp <= ?"
                params.append(end_time)
                
            query += " ORDER BY timestamp"
            
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=params)
                return df
                
        except Exception as e:
            logging.error(f"Market verisi yükleme hatası: {e}")
            return None
            
    def save_trade(self, trade_data):
        """İşlem verilerini kaydet"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                # İndikatör verilerini JSON'a çevir
                if 'indicators' in trade_data:
                    trade_data['indicators'] = json.dumps(trade_data['indicators'])
                    
                columns = ', '.join(trade_data.keys())
                placeholders = ', '.join('?' * len(trade_data))
                
                query = f"""
                    INSERT INTO trades ({columns})
                    VALUES ({placeholders})
                """
                
                conn.execute(query, list(trade_data.values()))
                logging.info(f"İşlem kaydedildi: {trade_data}")
                
        except Exception as e:
            logging.error(f"İşlem kaydetme hatası: {e}")
            
    def get_trade_history(self, symbol=None, start_time=None, end_time=None):
        """İşlem geçmişini getir"""
        try:
            query = "SELECT * FROM trades WHERE 1=1"
            params = []
            
            if symbol:
                query += " AND symbol = ?"
                params.append(symbol)
            if start_time:
                query += " AND entry_time >= ?"
                params.append(start_time)
            if end_time:
                query += " AND entry_time <= ?"
                params.append(end_time)
                
            query += " ORDER BY entry_time DESC"
            
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=params)
                
                # JSON sütunlarını parse et
                if 'indicators' in df.columns:
                    df['indicators'] = df['indicators'].apply(
                        lambda x: json.loads(x) if x else None
                    )
                    
                return df
                
        except Exception as e:
            logging.error(f"İşlem geçmişi alma hatası: {e}")
            return None
            
    def save_model_state(self, model_name, state, metrics):
        """Model durumunu kaydet"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO model_states (model_name, timestamp, state, metrics)
                    VALUES (?, ?, ?, ?)
                """, (model_name, datetime.now(), state, json.dumps(metrics)))
                
                logging.info(f"Model durumu kaydedildi: {model_name}")
                
        except Exception as e:
            logging.error(f"Model durumu kaydetme hatası: {e}")
            
    def load_latest_model_state(self, model_name):
        """En son model durumunu yükle"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                result = conn.execute("""
                    SELECT state, metrics FROM model_states
                    WHERE model_name = ?
                    ORDER BY timestamp DESC
                    LIMIT 1
                """, (model_name,)).fetchone()
                
                if result:
                    return {
                        'state': result[0],
                        'metrics': json.loads(result[1])
                    }
                return None
                
        except Exception as e:
            logging.error(f"Model durumu yükleme hatası: {e}")
            return None
            
    def save_performance_metrics(self, metrics):
        """Performans metriklerini kaydet"""
        try:
            with sqlite3.connect(self.db_path) as conn:
                conn.execute("""
                    INSERT INTO performance_metrics (timestamp, metrics)
                    VALUES (?, ?)
                """, (datetime.now(), json.dumps(metrics)))
                
                logging.info("Performans metrikleri kaydedildi")
                
        except Exception as e:
            logging.error(f"Performans metrikleri kaydetme hatası: {e}")
            
    def get_performance_history(self, start_time=None, end_time=None):
        """Performans geçmişini getir"""
        try:
            query = "SELECT * FROM performance_metrics WHERE 1=1"
            params = []
            
            if start_time:
                query += " AND timestamp >= ?"
                params.append(start_time)
            if end_time:
                query += " AND timestamp <= ?"
                params.append(end_time)
                
            query += " ORDER BY timestamp DESC"
            
            with sqlite3.connect(self.db_path) as conn:
                df = pd.read_sql(query, conn, params=params)
                df['metrics'] = df['metrics'].apply(json.loads)
                return df
                
        except Exception as e:
            logging.error(f"Performans geçmişi alma hatası: {e}")
            return None
            
    def cleanup_old_data(self, days=30):
        """Eski verileri temizle"""
        try:
            cutoff_date = datetime.now() - timedelta(days=days)
            
            with sqlite3.connect(self.db_path) as conn:
                # Eski market verilerini sil
                conn.execute("""
                    DELETE FROM market_data
                    WHERE timestamp < ?
                """, (cutoff_date.timestamp(),))
                
                # Eski model durumlarını sil
                conn.execute("""
                    DELETE FROM model_states
                    WHERE timestamp < ?
                """, (cutoff_date,))
                
                logging.info(f"Eski veriler temizlendi ({days} gün)")
                
        except Exception as e:
            logging.error(f"Veri temizleme hatası: {e}")
            
    def get_database_stats(self):
        """Veritabanı istatistiklerini getir"""
        try:
            stats = {}
            
            with sqlite3.connect(self.db_path) as conn:
                # Tablo büyüklükleri
                tables = ['market_data', 'trades', 'model_states', 'performance_metrics']
                for table in tables:
                    count = conn.execute(f"SELECT COUNT(*) FROM {table}").fetchone()[0]
                    stats[f'{table}_count'] = count
                    
                # Son kayıtlar
                stats['last_market_data'] = conn.execute(
                    "SELECT MAX(timestamp) FROM market_data"
                ).fetchone()[0]
                
                stats['last_trade'] = conn.execute(
                    "SELECT MAX(entry_time) FROM trades"
                ).fetchone()[0]
                
                # Veritabanı boyutu
                stats['database_size'] = os.path.getsize(self.db_path)
                
            return stats
            
        except Exception as e:
            logging.error(f"İstatistik alma hatası: {e}")
            return None