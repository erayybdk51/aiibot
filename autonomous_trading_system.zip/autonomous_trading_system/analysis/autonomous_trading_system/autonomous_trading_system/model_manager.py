import tensorflow as tf
from tensorflow.keras.models import Sequential, load_model, Model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input
from tensorflow.keras.optimizers import Adam
import numpy as np
import os
import logging
from datetime import datetime
import pickle
from sklearn.preprocessing import MinMaxScaler

class ModelManager:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.models_dir = os.path.join(base_dir, 'models')
        os.makedirs(self.models_dir, exist_ok=True)
        
        self.models = {
            'price_predictor': self._create_price_predictor(),
            'risk_analyzer': self._create_risk_analyzer(),
            'trend_classifier': self._create_trend_classifier()
        }
        
        self.scalers = {}
        self._load_existing_models()
        
    def _load_existing_models(self):
        """Mevcut modelleri yükle"""
        for model_name in self.models.keys():
            model_path = os.path.join(self.models_dir, f"{model_name}.h5")
            if os.path.exists(model_path):
                try:
                    self.models[model_name] = load_model(model_path)
                    logging.info(f"Model yüklendi: {model_name}")
                except Exception as e:
                    logging.error(f"Model yükleme hatası ({model_name}): {e}")
        
    def _create_price_predictor(self):
        """LSTM tabanlı fiyat tahmin modeli"""
        model = Sequential([
            LSTM(128, return_sequences=True, input_shape=(60, 5)),
            Dropout(0.2),
            LSTM(64, return_sequences=False),
            Dropout(0.2),
            Dense(32, activation='relu'),
            Dense(1)
        ])
        
        model.compile(optimizer=Adam(0.001), loss='mse')
        return model
        
    def _create_risk_analyzer(self):
        """Risk analiz modeli"""
        model = Sequential([
            Dense(64, activation='relu', input_shape=(10,)),
            Dropout(0.2),
            Dense(32, activation='relu'),
            Dense(16, activation='relu'),
            Dense(1, activation='sigmoid')
        ])
        
        model.compile(optimizer=Adam(0.001), loss='binary_crossentropy',
                     metrics=['accuracy'])
        return model
        
    def _create_trend_classifier(self):
        """Trend sınıflandırma modeli"""
        model = Sequential([
            Dense(32, activation='relu', input_shape=(15,)),
            Dropout(0.2),
            Dense(16, activation='relu'),
            Dense(3, activation='softmax')  # UP, DOWN, SIDEWAYS
        ])
        
        model.compile(optimizer=Adam(0.001), loss='categorical_crossentropy',
                     metrics=['accuracy'])
        return model
        
    def prepare_training_data(self, data, sequence_length=60):
        """Eğitim verisi hazırla"""
        X, y = [], []
        
        for i in range(sequence_length, len(data)):
            X.append(data[i-sequence_length:i])
            y.append(data[i])
            
        return np.array(X), np.array(y)
        
    def update_models(self, training_data):
        """Tüm modelleri güncelle"""
        if training_data is None or training_data['raw_data'].empty:
            logging.warning("Eğitim verisi bulunamadı")
            return
            
        try:
            # Fiyat tahmin modelini güncelle
            self._update_price_predictor(training_data)
            
            # Risk analiz modelini güncelle
            self._update_risk_analyzer(training_data)
            
            # Trend sınıflandırma modelini güncelle
            self._update_trend_classifier(training_data)
            
            # Modelleri kaydet
            self.save_models()
            
            logging.info("Model güncellemesi tamamlandı")
            
        except Exception as e:
            logging.error(f"Model güncelleme hatası: {e}")
            
    def _update_price_predictor(self, training_data):
        """Fiyat tahmin modelini güncelle"""
        df = training_data['processed_data']
        X, y = self.prepare_training_data(df.values)
        
        if len(X) > 0:
            history = self.models['price_predictor'].fit(
                X, y,
                epochs=10,
                batch_size=32,
                verbose=0,
                validation_split=0.2
            )
            self._log_training_metrics('price_predictor', history)
            
    def _update_risk_analyzer(self, training_data):
        """Risk analiz modelini güncelle"""
        df = training_data['raw_data']
        
        features = self._prepare_risk_features(df)
        labels = self._prepare_risk_labels(df)
        
        if len(features) > 0:
            history = self.models['risk_analyzer'].fit(
                features, labels,
                epochs=10,
                batch_size=32,
                verbose=0,
                validation_split=0.2
            )
            self._log_training_metrics('risk_analyzer', history)
            
    def _prepare_risk_features(self, df):
        """Risk özellikleri hazırla"""
        return np.column_stack([
            df['close'].pct_change(),
            df['volume'].pct_change(),
            df['close'].rolling(window=20).std(),
            df['volume'].rolling(window=20).std(),
            df['high'].rolling(window=20).max() / df['low'].rolling(window=20).min() - 1,
            df['close'] / df['close'].rolling(window=20).mean() - 1,
            df['volume'] / df['volume'].rolling(window=20).mean() - 1,
            df['close'].rolling(window=20).skew(),
            df['volume'].rolling(window=20).skew(),
            df['close'].rolling(window=20).kurt()
        ])
        
    def _prepare_risk_labels(self, df):
        """Risk etiketleri hazırla"""
        volatility = df['close'].pct_change().rolling(window=20).std()
        volume_change = df['volume'].pct_change().rolling(window=20).std()
        
        # Yüksek risk: Yüksek volatilite VE yüksek hacim değişimi
        high_risk = ((volatility > volatility.mean() + volatility.std()) & 
                    (volume_change > volume_change.mean() + volume_change.std()))
                    
        return high_risk.astype(int)
        
    def _update_trend_classifier(self, training_data):
        """Trend sınıflandırma modelini güncelle"""
        df = training_data['raw_data']
        
        features = self._prepare_trend_features(df)
        labels = self._prepare_trend_labels(df)
        
        if len(features) > 0:
            history = self.models['trend_classifier'].fit(
                features, labels,
                epochs=10,
                batch_size=32,
                verbose=0,
                validation_split=0.2
            )
            self._log_training_metrics('trend_classifier', history)
            
    def _prepare_trend_features(self, df):
        """Trend özellikleri hazırla"""
        sma_20 = df['close'].rolling(window=20).mean()
        sma_50 = df['close'].rolling(window=50).mean()
        
        return np.column_stack([
            df['close'].pct_change(),
            df['volume'].pct_change(),
            df['close'] / sma_20 - 1,
            df['close'] / sma_50 - 1,
            df['high'].rolling(window=20).max() / df['close'] - 1,
            df['close'] / df['low'].rolling(window=20).min() - 1,
            sma_20.pct_change(),
            sma_50.pct_change(),
            df['close'].rolling(window=20).std() / df['close'],
            df['volume'].rolling(window=20).std() / df['volume'],
            df['close'].rolling(window=20).skew(),
            df['volume'].rolling(window=20).skew(),
            df['close'].rolling(window=20).kurt(),
            df['volume'].rolling(window=20).kurt(),
            (df['high'] - df['low']) / df['close']
        ])
        
    def _prepare_trend_labels(self, df):
        """Trend etiketleri hazırla"""
        returns = df['close'].pct_change()
        sma_cross = df['close'].rolling(window=20).mean().pct_change()
        
        labels = np.zeros(len(df))
        
        # Yukarı trend
        labels[(returns > returns.std()) & (sma_cross > 0)] = 2
        
        # Yatay trend
        labels[(returns >= -returns.std()) & (returns <= returns.std())] = 1
        
        # Aşağı trend
        labels[(returns < -returns.std()) & (sma_cross < 0)] = 0
        
        return tf.keras.utils.to_categorical(labels, 3)
        
    def predict_price(self, data):
        """Fiyat tahmini yap"""
        try:
            prediction = self.models['price_predictor'].predict(data)
            return prediction[0][0]
        except Exception as e:
            logging.error(f"Fiyat tahmin hatası: {e}")
            return None
            
    def analyze_risk(self, features):
        """Risk analizi yap"""
        try:
            risk_score = self.models['risk_analyzer'].predict(features)
            return risk_score[0][0]
        except Exception as e:
            logging.error(f"Risk analiz hatası: {e}")
            return None
            
    def classify_trend(self, features):
        """Trend sınıflandırması yap"""
        try:
            probabilities = self.models['trend_classifier'].predict(features)
            return {
                'UP': float(probabilities[0][2]),
                'SIDEWAYS': float(probabilities[0][1]),
                'DOWN': float(probabilities[0][0])
            }
        except Exception as e:
            logging.error(f"Trend sınıflandırma hatası: {e}")
            return None
            
    def save_models(self):
        """Tüm modelleri kaydet"""
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        
        for name, model in self.models.items():
            try:
                # Ana model dosyası
                model_path = os.path.join(self.models_dir, f"{name}.h5")
                model.save(model_path)
                
                # Yedek dosya
                backup_path = os.path.join(self.models_dir, f"{name}_{timestamp}.h5")
                model.save(backup_path)
                
                logging.info(f"Model kaydedildi: {name}")
                
            except Exception as e:
                logging.error(f"Model kaydetme hatası ({name}): {e}")
                
    def _log_training_metrics(self, model_name, history):
        """Eğitim metriklerini logla"""
        metrics = history.history
        final_loss = metrics['loss'][-1]
        
        if 'accuracy' in metrics:
            final_accuracy = metrics['accuracy'][-1]
            logging.info(f"{model_name} eğitim sonuçları - "
                       f"Loss: {final_loss:.4f}, Accuracy: {final_accuracy:.4f}")
        else:
            logging.info(f"{model_name} eğitim sonuçları - Loss: {final_loss:.4f}")

    def cleanup_old_models(self, keep_days=30):
        """Eski model dosyalarını temizle"""
        cutoff_date = datetime.now() - timedelta(days=keep_days)
        
        for file in os.listdir(self.models_dir):
            if not file.endswith('.h5'):
                continue
                
            try:
                # Tarih bilgisini dosya adından çıkar
                date_str = re.search(r'\d{8}_\d{6}', file)
                if date_str:
                    file_date = datetime.strptime(date_str.group(), '%Y%m%d_%H%M%S')
                    if file_date < cutoff_date:
                        file_path = os.path.join(self.models_dir, file)
                        os.remove(file_path)
                        logging.info(f"Eski model dosyası silindi: {file}")
                        
            except Exception as e:
                logging.error(f"Model temizleme hatası: {e}")
