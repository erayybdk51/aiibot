import numpy as np
import pandas as pd
from datetime import datetime, timedelta
import logging

class RiskManager:
    def __init__(self, initial_balance=1000):
        self.initial_balance = initial_balance
        self.current_balance = initial_balance
        self.max_position_ratio = 0.1  # Maksimum pozisyon büyüklüğü (bakiyenin %10'u)
        self.max_daily_loss = 0.05    # Maksimum günlük zarar (bakiyenin %5'i)
        self.max_single_loss = 0.02   # Tek işlemde maksimum zarar (bakiyenin %2'si)
        
        self.position_sizes = {}      # Açık pozisyon büyüklükleri
        self.daily_pnl = 0           # Günlük kar/zarar
        self.last_reset = datetime.now().date()
        
        # Trailing stop seviyeleri
        self.trailing_stop_levels = {
            0.01: 0.005,  # %1 karda trailing stop %0.5'e
            0.02: 0.01,   # %2 karda trailing stop %1'e
            0.03: 0.02,   # %3 karda trailing stop %2'ye
            0.05: 0.03    # %5 karda trailing stop %3'e
        }
        
        # Risk metrikleri
        self.metrics = {
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'total_profit': 0,
            'total_loss': 0,
            'max_drawdown': 0,
            'current_drawdown': 0,
            'peak_balance': initial_balance
        }
        
    def update_balance(self, pnl):
        """Bakiyeyi güncelle ve risk metriklerini yenile"""
        # Günlük reset kontrolü
        current_date = datetime.now().date()
        if current_date > self.last_reset:
            self.daily_pnl = 0
            self.last_reset = current_date
        
        # Bakiye ve günlük P/L güncelle
        self.current_balance += pnl
        self.daily_pnl += pnl
        
        # Metrikleri güncelle
        self.metrics['total_trades'] += 1
        if pnl > 0:
            self.metrics['winning_trades'] += 1
            self.metrics['total_profit'] += pnl
        else:
            self.metrics['losing_trades'] += 1
            self.metrics['total_loss'] += abs(pnl)
            
        # Peak balance ve drawdown güncelle
        if self.current_balance > self.metrics['peak_balance']:
            self.metrics['peak_balance'] = self.current_balance
        
        current_drawdown = (self.metrics['peak_balance'] - self.current_balance) / self.metrics['peak_balance']
        self.metrics['current_drawdown'] = current_drawdown
        
        if current_drawdown > self.metrics['max_drawdown']:
            self.metrics['max_drawdown'] = current_drawdown
            
        logging.info(f"Bakiye güncellendi - Yeni bakiye: ${self.current_balance:.2f}, Günlük P/L: ${self.daily_pnl:.2f}")
        
    def calculate_position_size(self, current_price, risk_score=0.5):
        """Pozisyon büyüklüğünü hesapla"""
        # Günlük zarar limitini kontrol et
        if self.daily_pnl < -self.initial_balance * self.max_daily_loss:
            logging.warning("Günlük zarar limitine ulaşıldı")
            return 0
            
        # Temel pozisyon büyüklüğü (bakiyenin maksimum %10'u)
        base_size = self.current_balance * self.max_position_ratio
        
        # Risk skoruna göre ayarla (0-1 arası)
        adjusted_size = base_size * risk_score
        
        # Mevcut pozisyonları kontrol et
        total_exposure = sum(self.position_sizes.values())
        if total_exposure + adjusted_size > self.current_balance * 0.5:  # Maksimum %50 toplam pozisyon
            logging.warning("Maksimum pozisyon limitine ulaşıldı")
            return 0
            
        # Minimum işlem büyüklüğü kontrolü
        min_trade_size = 10  # $10 minimum
        if adjusted_size < min_trade_size:
            return 0
            
        return adjusted_size
        
    def calculate_stop_loss(self, entry_price, position_size, side='BUY', atr=None):
        """Stop loss seviyesini hesapla"""
        # ATR bazlı stop loss
        if atr:
            sl_distance = 2 * atr
        else:
            # Fiyat bazlı sabit yüzde
            sl_distance = entry_price * 0.02  # %2
            
        # Maksimum zarar kontrolü
        max_loss_amount = self.current_balance * self.max_single_loss
        price_distance = max_loss_amount / position_size
        
        # En küçük stop loss mesafesini kullan
        sl_distance = min(sl_distance, price_distance)
        
        if side == 'BUY':
            stop_loss = entry_price - sl_distance
        else:
            stop_loss = entry_price + sl_distance
            
        return stop_loss
        
    def calculate_take_profit(self, entry_price, stop_loss, min_risk_reward=2):
        """Take profit seviyesini hesapla"""
        sl_distance = abs(entry_price - stop_loss)
        tp_distance = sl_distance * min_risk_reward
        
        if stop_loss < entry_price:  # Long pozisyon
            take_profit = entry_price + tp_distance
        else:  # Short pozisyon
            take_profit = entry_price - tp_distance
            
        return take_profit
        
    def update_trailing_stop(self, position):
        """Trailing stop seviyesini güncelle"""
        entry_price = position['entry_price']
        current_price = position['current_price']
        current_stop = position['stop_loss']
        
        # Kar yüzdesini hesapla
        if position['side'] == 'BUY':
            profit_pct = (current_price - entry_price) / entry_price
        else:
            profit_pct = (entry_price - current_price) / entry_price
            
        # Trailing stop seviyelerini kontrol et
        for profit_target, stop_level in sorted(self.trailing_stop_levels.items()):
            if profit_pct >= profit_target:
                if position['side'] == 'BUY':
                    new_stop = entry_price * (1 + stop_level)
                    if new_stop > current_stop:
                        return new_stop
                else:
                    new_stop = entry_price * (1 - stop_level)
                    if new_stop < current_stop:
                        return new_stop
                        
        return current_stop
        
    def should_close_position(self, position):
        """Pozisyon kapatma kontrolü"""
        current_price = position['current_price']
        
        # Stop loss kontrolü
        if position['side'] == 'BUY' and current_price <= position['stop_loss']:
            return True, 'stop_loss'
        elif position['side'] == 'SELL' and current_price >= position['stop_loss']:
            return True, 'stop_loss'
            
        # Take profit kontrolü
        if position['side'] == 'BUY' and current_price >= position['take_profit']:
            return True, 'take_profit'
        elif position['side'] == 'SELL' and current_price <= position['take_profit']:
            return True, 'take_profit'
            
        # Günlük zarar limiti kontrolü
        if self.daily_pnl < -self.initial_balance * self.max_daily_loss:
            return True, 'daily_loss_limit'
            
        return False, None
        
    def can_open_new_position(self, symbol):
        """Yeni pozisyon açılabilir mi kontrolü"""
        # Günlük zarar limiti kontrolü
        if self.daily_pnl < -self.initial_balance * self.max_daily_loss:
            return False
            
        # Toplam pozisyon büyüklüğü kontrolü
        total_exposure = sum(self.position_sizes.values())
        if total_exposure >= self.current_balance * 0.5:
            return False
            
        # Sembol bazlı pozisyon limiti
        if symbol in self.position_sizes:
            current_size = self.position_sizes[symbol]
            if current_size >= self.current_balance * 0.2:  # Maksimum %20 tek sembol
                return False
                
        return True
        
    def get_risk_metrics(self):
        """Risk metriklerini getir"""
        metrics = self.metrics.copy()
        
        # Ek metrikler hesapla
        if metrics['total_trades'] > 0:
            metrics['win_rate'] = metrics['winning_trades'] / metrics['total_trades']
            metrics['profit_factor'] = metrics['total_profit'] / max(1, metrics['total_loss'])
            metrics['average_win'] = metrics['total_profit'] / max(1, metrics['winning_trades'])
            metrics['average_loss'] = metrics['total_loss'] / max(1, metrics['losing_trades'])
            
        return metrics
        
    def calculate_risk_parameters(self, symbol, signal_strength):
        """İşlem risk parametrelerini hesapla"""
        params = {
            'position_size': self.calculate_position_size(0, signal_strength),
            'risk_level': min(signal_strength, 0.8),  # Maksimum %80 risk
            'max_loss_pct': self.max_single_loss,
            'can_trade': self.can_open_new_position(symbol)
        }
        
        return params
