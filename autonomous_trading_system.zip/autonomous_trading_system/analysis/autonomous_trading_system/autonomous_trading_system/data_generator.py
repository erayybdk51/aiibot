from binance.client import Client
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import logging
from sklearn.preprocessing import MinMaxScaler

class DataGenerator:
    def __init__(self, api_key, api_secret):
        self.client = Client(api_key, api_secret)
        
    def download_initial_data(self, symbol, interval='1m', lookback_days=30):
        """Başlangıç verilerini Binance'den çek"""
        try:
            # Başlangıç ve bitiş zamanlarını hesapla
            end_time = datetime.now()
            start_time = end_time - timedelta(days=lookback_days)
            
            print(f"Başlangıç verisi indiriliyor: {symbol} - Son {lookback_days} gün...")
            
            # Veriyi çek
            klines = self.client.get_historical_klines(
                symbol=symbol,
                interval=interval,
                start_str=start_time.strftime("%Y-%m-%d %H:%M:%S"),
                end_str=end_time.strftime("%Y-%m-%d %H:%M:%S")
            )
            
            # DataFrame'e dönüştür
            df = pd.DataFrame(klines, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume',
                'close_time', 'quote_volume', 'trades', 'taker_base',
                'taker_quote', 'ignore'
            ])
            
            # Veriyi temizle ve formatla
            df['timestamp'] = pd.to_datetime(df['timestamp'], unit='ms')
            for col in ['open', 'high', 'low', 'close', 'volume']:
                df[col] = pd.to_numeric(df[col], errors='coerce')
                
            print(f"Veri başarıyla indirildi. Toplam kayıt: {len(df)}")
            
            return df
            
        except Exception as e:
            print(f"Veri indirme hatası: {e}")
            logging.error(f"Veri indirme hatası: {e}")
            return None
            
    def generate_training_data(self, df, sequence_length=60):
        """Model eğitimi için veri hazırla"""
        try:
            # Özellik sütunları
            feature_columns = ['open', 'high', 'low', 'close', 'volume']
            
            # MinMax normalizasyon
            scaler = MinMaxScaler()
            scaled_data = scaler.fit_transform(df[feature_columns])
            
            X, y = [], []
            for i in range(sequence_length, len(scaled_data)):
                X.append(scaled_data[i-sequence_length:i])
                # Bir sonraki kapanış fiyatını tahmin et
                y.append(scaled_data[i, 3])  # 3 = close price index
                
            return np.array(X), np.array(y), scaler
            
        except Exception as e:
            print(f"Eğitim verisi hazırlama hatası: {e}")
            logging.error(f"Eğitim verisi hazırlama hatası: {e}")
            return None, None, None
            
    def download_multi_timeframe_data(self, symbol, timeframes=['1m', '5m', '15m']):
        """Farklı zaman dilimleri için veri indir"""
        data = {}
        for timeframe in timeframes:
            print(f"{timeframe} verisi indiriliyor...")
            df = self.download_initial_data(symbol, timeframe)
            if df is not None:
                data[timeframe] = df
                
        return data