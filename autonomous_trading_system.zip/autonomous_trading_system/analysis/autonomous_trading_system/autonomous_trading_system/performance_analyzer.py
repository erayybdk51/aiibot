import pandas as pd
import numpy as np
from datetime import datetime, timedelta
import json
import os
import logging
import matplotlib.pyplot as plt
import seaborn as sns

class PerformanceAnalyzer:
    def __init__(self, base_dir):
        self.base_dir = base_dir
        self.reports_dir = os.path.join(base_dir, 'reports')
        os.makedirs(self.reports_dir, exist_ok=True)
        
        self.metrics = {
            'trades': [],
            'daily_returns': [],
            'signal_accuracy': {
                'trend': 0,
                'momentum': 0,
                'volatility': 0,
                'volume': 0
            },
            'total_trades': 0,
            'winning_trades': 0,
            'losing_trades': 0,
            'total_profit': 0,
            'total_loss': 0,
            'max_drawdown': 0
        }
        
        self.current_drawdown = 0
        self.peak_balance = 1000
        
    def update_metrics(self, trade_result):
        try:
            self.metrics['trades'].append(trade_result)
            self.metrics['total_trades'] += 1
            
            pnl = trade_result['profit_loss']
            if pnl > 0:
                self.metrics['winning_trades'] += 1
                self.metrics['total_profit'] += pnl
            else:
                self.metrics['losing_trades'] += 1
                self.metrics['total_loss'] += abs(pnl)
                
            daily_return = {
                'date': trade_result['exit_time'].date(),
                'return': pnl / trade_result['investment_amount']
            }
            self.metrics['daily_returns'].append(daily_return)
            
            self._calculate_drawdown(trade_result['exit_balance'])
            
        except Exception as e:
            logging.error(f"Metrik güncelleme hatası: {e}")
            
    def _calculate_drawdown(self, current_balance):
        try:
            if current_balance > self.peak_balance:
                self.peak_balance = current_balance
                self.current_drawdown = 0
            else:
                self.current_drawdown = (self.peak_balance - current_balance) / self.peak_balance
                
            if self.current_drawdown > self.metrics['max_drawdown']:
                self.metrics['max_drawdown'] = self.current_drawdown
                
        except Exception as e:
            logging.error(f"Drawdown hesaplama hatası: {e}")
            
    def generate_report(self):
        try:
            report = {
                'timestamp': datetime.now().strftime('%Y-%m-%d %H:%M:%S'),
                'summary': self._calculate_summary_metrics(),
                'risk_metrics': self._calculate_risk_metrics(),
                'signal_analysis': self._analyze_signals(),
                'hourly_analysis': self._analyze_hourly_performance()
            }
            
            filename = f"performance_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
            filepath = os.path.join(self.reports_dir, filename)
            
            with open(filepath, 'w') as f:
                json.dump(report, f, indent=4)
                
            self._generate_visualizations(report)
            
            return report
            
        except Exception as e:
            logging.error(f"Rapor oluşturma hatası: {e}")
            return None
            
    def _calculate_summary_metrics(self):
        try:
            total_trades = self.metrics['total_trades']
            if total_trades == 0:
                return {}
                
            return {
                'total_trades': total_trades,
                'winning_trades': self.metrics['winning_trades'],
                'losing_trades': self.metrics['losing_trades'],
                'win_rate': self.metrics['winning_trades'] / total_trades * 100,
                'total_profit': self.metrics['total_profit'],
                'total_loss': self.metrics['total_loss'],
                'net_profit': self.metrics['total_profit'] - self.metrics['total_loss'],
                'profit_factor': self.metrics['total_profit'] / max(1, self.metrics['total_loss']),
                'average_win': self.metrics['total_profit'] / max(1, self.metrics['winning_trades']),
                'average_loss': self.metrics['total_loss'] / max(1, self.metrics['losing_trades']),
                'max_drawdown': self.metrics['max_drawdown'] * 100
            }
            
        except Exception as e:
            logging.error(f"Özet metrik hesaplama hatası: {e}")
            return {}
            
    def _calculate_risk_metrics(self):
        try:
            if not self.metrics['daily_returns']:
                return {}
                
            returns = pd.Series([r['return'] for r in self.metrics['daily_returns']])
            
            risk_metrics = {
                'volatility': returns.std() * np.sqrt(252),
                'sharpe_ratio': self._calculate_sharpe_ratio(returns),
                'sortino_ratio': self._calculate_sortino_ratio(returns),
                'max_drawdown': self.metrics['max_drawdown'],
                'value_at_risk': self._calculate_var(returns)
            }
            
            return risk_metrics
            
        except Exception as e:
            logging.error(f"Risk metrikleri hesaplama hatası: {e}")
            return {}
            
    def _calculate_sharpe_ratio(self, returns, risk_free_rate=0.02):
        try:
            excess_returns = returns - risk_free_rate/252
            if excess_returns.std() == 0:
                return 0
            return np.sqrt(252) * excess_returns.mean() / excess_returns.std()
        except Exception as e:
            logging.error(f"Sharpe oranı hesaplama hatası: {e}")
            return 0
            
    def _calculate_sortino_ratio(self, returns, risk_free_rate=0.02):
        try:
            excess_returns = returns - risk_free_rate/252
            downside_returns = excess_returns[excess_returns < 0]
            if len(downside_returns) == 0:
                return float('inf')
            downside_std = np.sqrt(np.mean(downside_returns**2))
            if downside_std == 0:
                return 0
            return np.sqrt(252) * excess_returns.mean() / downside_std
        except Exception as e:
            logging.error(f"Sortino oranı hesaplama hatası: {e}")
            return 0
            
    def _calculate_var(self, returns, confidence_level=0.95):
        try:
            return np.percentile(returns, (1 - confidence_level) * 100)
        except Exception as e:
            logging.error(f"VaR hesaplama hatası: {e}")
            return 0
            
    def _analyze_signals(self):
        try:
            total_trades = self.metrics['total_trades']
            if total_trades == 0:
                return {}
                
            signal_analysis = {}
            for signal_type, correct_count in self.metrics['signal_accuracy'].items():
                signal_analysis[signal_type] = {
                    'accuracy': correct_count / total_trades * 100,
                    'total_signals': total_trades,
                    'correct_signals': correct_count
                }
                
            return signal_analysis
            
        except Exception as e:
            logging.error(f"Sinyal analizi hatası: {e}")
            return {}
            
    def _analyze_hourly_performance(self):
        try:
            trades = pd.DataFrame(self.metrics['trades'])
            if trades.empty:
                return {}
                
            trades['hour'] = pd.to_datetime(trades['entry_time']).dt.hour
            
            hourly_analysis = trades.groupby('hour').agg({
                'profit_loss': ['count', 'sum', 'mean']
            }).round(4)
            
            return hourly_analysis.to_dict()
            
        except Exception as e:
            logging.error(f"Saatlik analiz hatası: {e}")
            return {}
            
    def get_optimization_metrics(self):
        try:
            metrics = {
                'win_rate': self.metrics['winning_trades'] / max(1, self.metrics['total_trades']),
                'profit_factor': self.metrics['total_profit'] / max(1, self.metrics['total_loss']),
                'max_drawdown': self.metrics['max_drawdown'],
                'signal_accuracy': self.metrics['signal_accuracy']
            }
            
            return metrics
            
        except Exception as e:
            logging.error(f"Optimizasyon metrikleri alma hatası: {e}")
            return {}