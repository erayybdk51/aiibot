from binance.client import Client
from binance.exceptions import BinanceAPIException
import logging
from datetime import datetime
import time
import threading
import queue

class TradeExecutor:
    def __init__(self, client, risk_manager):
        self.client = client
        self.risk_manager = risk_manager
        self.active_trades = {}
        self.trade_queue = queue.Queue()
        self.execution_thread = None
        self.running = True
        
    def start(self):
        """Başlat execution thread"""
        self.execution_thread = threading.Thread(target=self._execution_loop)
        self.execution_thread.daemon = True
        self.execution_thread.start()
        
    def stop(self):
        """Durdur execution thread"""
        self.running = False
        if self.execution_thread:
            self.execution_thread.join()
            
    def _execution_loop(self):
        """Ana execution döngüsü"""
        while self.running:
            try:
                if not self.trade_queue.empty():
                    trade = self.trade_queue.get()
                    self._execute_trade(trade)
                    
                self._manage_active_trades()
                time.sleep(1)
                
            except Exception as e:
                logging.error(f"Execution loop hatası: {e}")
                time.sleep(5)
                
    def submit_trade(self, trade_params):
        """Yeni trade ekle execution kuyruğuna"""
        self.trade_queue.put(trade_params)
        
    def _execute_trade(self, trade):
        """Trade'i gerçekleştir"""
        try:
            symbol = trade['symbol']
            side = trade['side']
            quantity = trade['quantity']
            
            # Market fiyatından işlem
            order = self.client.create_order(
                symbol=symbol,
                side=side,
                type=Client.ORDER_TYPE_MARKET,
                quantity=quantity
            )
            
            # İşlem detaylarını kaydet
            trade_id = order['orderId']
            self.active_trades[trade_id] = {
                'symbol': symbol,
                'side': side,
                'quantity': quantity,
                'entry_price': float(order['fills'][0]['price']),
                'entry_time': datetime.now(),
                'stop_loss': trade['stop_loss'],
                'take_profit': trade['take_profit']
            }
            
            logging.info(f"İşlem gerçekleşti: {order}")
            return trade_id
            
        except BinanceAPIException as e:
            logging.error(f"Binance API hatası: {e}")
            return None
            
        except Exception as e:
            logging.error(f"İşlem hatası: {e}")
            return None
            
    def _manage_active_trades(self):
        """Aktif trade'leri yönet"""
        for trade_id, trade in list(self.active_trades.items()):
            try:
                current_price = float(self.client.get_symbol_ticker(
                    symbol=trade['symbol']
                )['price'])
                
                # Stop loss veya take profit kontrol
                should_close, reason = self.risk_manager.should_close_position(trade, current_price)
                
                if should_close:
                    self._close_position(trade_id, current_price, reason)
                else:
                    # Trailing stop güncelle
                    new_stop = self.risk_manager.update_trailing_stop(
                        trade['entry_price'],
                        current_price,
                        trade['stop_loss']
                    )
                    if new_stop != trade['stop_loss']:
                        self.active_trades[trade_id]['stop_loss'] = new_stop
                        logging.info(f"Trailing stop güncellendi: {trade_id} - Yeni stop: {new_stop}")
                        
            except Exception as e:
                logging.error(f"Trade yönetim hatası: {e}")
                
    def _close_position(self, trade_id, current_price, reason):
        """Pozisyonu kapat"""
        trade = self.active_trades[trade_id]
        try:
            # Ters işlem ile pozisyonu kapat
            close_side = Client.SIDE_SELL if trade['side'] == Client.SIDE_BUY else Client.SIDE_BUY
            
            order = self.client.create_order(
                symbol=trade['symbol'],
                side=close_side,
                type=Client.ORDER_TYPE_MARKET,
                quantity=trade['quantity']
            )
            
            # Kar/zarar hesapla
            if trade['side'] == Client.SIDE_BUY:
                profit_loss = (current_price - trade['entry_price']) * trade['quantity']
            else:
                profit_loss = (trade['entry_price'] - current_price) * trade['quantity']
                
            # Risk yöneticisini güncelle
            self.risk_manager.update_balance(profit_loss)
            
            # Trade sonucu logla
            logging.info(f"""
            Pozisyon kapatıldı:
            Trade ID: {trade_id}
            Sebep: {reason}
            Giriş Fiyatı: {trade['entry_price']}
            Çıkış Fiyatı: {current_price}
            Kar/Zarar: {profit_loss}
            """)
            
            # Aktif trade'lerden kaldır
            del self.active_trades[trade_id]
            
            return order
            
        except Exception as e:
            logging.error(f"Pozisyon kapatma hatası: {e}")
            return None
            
    def get_active_trades(self):
        """Aktif trade'leri getir"""
        return self.active_trades
        
    def get_position_size(self, symbol):
        """Belirli bir sembol için toplam pozisyon büyüklüğünü hesapla"""
        total_size = 0
        for trade in self.active_trades.values():
            if trade['symbol'] == symbol:
                if trade['side'] == Client.SIDE_BUY:
                    total_size += trade['quantity']
                else:
                    total_size -= trade['quantity']
        return total_size
        
    def calculate_realized_pnl(self, trades):
        """Gerçekleşen kar/zararı hesapla"""
        total_pnl = 0
        for trade in trades:
            if trade['side'] == Client.SIDE_BUY:
                pnl = (trade['exit_price'] - trade['entry_price']) * trade['quantity']
            else:
                pnl = (trade['entry_price'] - trade['exit_price']) * trade['quantity']
            total_pnl += pnl
        return total_pnl

    def cancel_all_orders(self, symbol):
        """Tüm bekleyen emirleri iptal et"""
        try:
            return self.client.cancel_all_orders(symbol=symbol)
        except Exception as e:
            logging.error(f"Emir iptal hatası: {e}")
            return None