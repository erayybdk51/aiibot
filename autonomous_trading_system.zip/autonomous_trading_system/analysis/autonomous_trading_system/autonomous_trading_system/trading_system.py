import numpy as np
import pandas as pd
import tensorflow as tf
from sklearn.preprocessing import MinMaxScaler
from binance.client import Client
import sqlite3
import logging
import json
import os
from datetime import datetime, timedelta
from tensorflow.keras.models import Sequential, load_model, Model
from tensorflow.keras.layers import LSTM, Dense, Dropout, Input, Concatenate
import pickle
import time

class AutonomousTradingSystem:
    def __init__(self, initial_balance=1000):
        self.API_KEY = "Hmdo1ZpfIazZ8m48Kj3tpk29RRUeNLtW0EaO6XYJF1jukPljiz3enAU44ovgNhJl"
        self.API_SECRET = "pNrqNvwyHbTtADcjmCdYe0pGLjjjZjndqy7CxnAuUIvhgY5iqV5ntF6UZfpjDkNQ"
        
        # Base paths
        self.base_dir = os.path.dirname(os.path.abspath(__file__))
        self.setup_directories()
        self.setup_logging()
        
        # Initialize components
        self.data_manager = DataManager(self.base_dir)
        self.model_manager = ModelManager(self.base_dir)
        self.risk_manager = RiskManager(initial_balance)
        
        # Connect to Binance
        self.client = Client(self.API_KEY, self.API_SECRET)
        
    def setup_directories(self):
        """Initialize directory structure"""
        directories = [
            'data',
            'models',
            'logs',
            'analysis',
            'backtest',
            'reports',
        ]
        
        for directory in directories:
            path = os.path.join(self.base_dir, directory)
            os.makedirs(path, exist_ok=True)
            setattr(self, f"{directory}_dir", path)

    def setup_logging(self):
        """Configure logging system"""
        log_file = os.path.join(self.logs_dir, 'system.log')
        logging.basicConfig(
            filename=log_file,
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )

if __name__ == "__main__":
    system = AutonomousTradingSystem()
    system.start()